import { pgTable, text, uuid, timestamp, integer, real, boolean, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const languagesTable = pgTable("languages", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  nativeName: text("native_name").notNull(),
  flag: text("flag").notNull(),
  dialects: integer("dialects").notNull().default(1),
  region: text("region", { enum: ["indian", "global"] }).notNull().default("global"),
  priceUsd: real("price_usd").notNull().default(9.99),
  isDefault: boolean("is_default").notNull().default(false),
  enabled: boolean("enabled").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const userLanguagesTable = pgTable("user_languages", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  languageId: uuid("language_id").notNull().references(() => languagesTable.id, { onDelete: "cascade" }),
  purchasedAt: timestamp("purchased_at", { withTimezone: true }).notNull().defaultNow(),
  paymentRef: text("payment_ref"),
}, (t) => [
  unique("uq_user_language").on(t.userId, t.languageId),
]);

export const insertLanguageSchema = createInsertSchema(languagesTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertUserLanguageSchema = createInsertSchema(userLanguagesTable).omit({ id: true, purchasedAt: true });

export type Language = typeof languagesTable.$inferSelect;
export type InsertLanguage = z.infer<typeof insertLanguageSchema>;
export type UserLanguage = typeof userLanguagesTable.$inferSelect;
