import { pgTable, uuid, text, timestamp, integer, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { videosTable } from "./videos";
import { usersTable } from "./users";

export const marketingAssetTypeValues = ["trailer", "poster", "thumbnail"] as const;
export type MarketingAssetType = (typeof marketingAssetTypeValues)[number];

export const marketingAssetStatusValues = ["pending", "generating", "completed", "failed"] as const;
export type MarketingAssetStatus = (typeof marketingAssetStatusValues)[number];

export const marketingAssetsTable = pgTable("marketing_assets", {
  id: uuid("id").primaryKey().defaultRandom(),
  videoId: uuid("video_id")
    .notNull()
    .references(() => videosTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id").references(() => usersTable.id, { onDelete: "set null" }),
  assetType: text("asset_type").notNull().$type<MarketingAssetType>(),
  status: text("status").notNull().default("pending").$type<MarketingAssetStatus>(),
  language: text("language").notNull().default("en"),
  title: text("title"),
  tagline: text("tagline"),
  imageData: text("image_data"),
  trailerContent: jsonb("trailer_content").default(null),
  assetMetadata: jsonb("asset_metadata").notNull().default({}),
  errorMessage: text("error_message"),
  generationPrompt: text("generation_prompt"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertMarketingAssetSchema = createInsertSchema(marketingAssetsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const selectMarketingAssetSchema = createSelectSchema(marketingAssetsTable);

export type MarketingAsset = typeof marketingAssetsTable.$inferSelect;
export type InsertMarketingAsset = typeof marketingAssetsTable.$inferInsert;
