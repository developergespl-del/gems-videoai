import { pgTable, uuid, text, integer, timestamp, real } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const apiClientsTable = pgTable("api_clients", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  company: text("company"),
  status: text("status", { enum: ["active", "blocked", "suspended"] }).notNull().default("active"),
  notes: text("notes"),
  createdByUserId: uuid("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const apiKeysTable = pgTable("api_keys", {
  id: uuid("id").primaryKey().defaultRandom(),
  clientId: uuid("client_id").notNull().references(() => apiClientsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  keyHash: text("key_hash").notNull().unique(),
  keyPrefix: text("key_prefix").notNull(),
  status: text("status", { enum: ["active", "blocked", "suspended", "expired"] }).notNull().default("active"),
  validFrom: timestamp("valid_from", { withTimezone: true }).notNull().defaultNow(),
  validUntil: timestamp("valid_until", { withTimezone: true }).notNull(),
  pricingTier: text("pricing_tier").notNull().default("standard"),
  priceUsd: real("price_usd").notNull().default(99),
  requestCount: integer("request_count").notNull().default(0),
  requestLimitPerDay: integer("request_limit_per_day").notNull().default(1000),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const apiRequestLogsTable = pgTable("api_request_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  apiKeyId: uuid("api_key_id").notNull().references(() => apiKeysTable.id, { onDelete: "cascade" }),
  ip: text("ip").notNull().default(""),
  endpoint: text("endpoint").notNull().default(""),
  method: text("method").notNull().default("GET"),
  statusCode: integer("status_code").notNull().default(200),
  responseTimeMs: integer("response_time_ms"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const apiClientUsersTable = pgTable("api_client_users", {
  id: uuid("id").primaryKey().defaultRandom(),
  apiClientId: uuid("api_client_id").notNull().references(() => apiClientsTable.id, { onDelete: "cascade" }),
  externalId: text("external_id"),
  name: text("name").notNull(),
  email: text("email").notNull(),
  status: text("status", { enum: ["active", "blocked", "pending_transfer", "transferred"] }).notNull().default("active"),
  transferredToUserId: uuid("transferred_to_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  transferredAt: timestamp("transferred_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type ApiClient = typeof apiClientsTable.$inferSelect;
export type ApiKey = typeof apiKeysTable.$inferSelect;
export type ApiClientUser = typeof apiClientUsersTable.$inferSelect;
export type ApiRequestLog = typeof apiRequestLogsTable.$inferSelect;
