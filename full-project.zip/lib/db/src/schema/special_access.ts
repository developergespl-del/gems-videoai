import { pgTable, uuid, text, timestamp, boolean, integer, uniqueIndex, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const specialAccessTable = pgTable("special_access", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  canGenerateVideos: boolean("can_generate_videos").notNull().default(false),
  canCinemaMode: boolean("can_cinema_mode").notNull().default(false),
  freeVideoGeneration: boolean("free_video_generation").notNull().default(false),
  unlimitedUsage: boolean("unlimited_usage").notNull().default(false),
  allLanguagesAccess: boolean("all_languages_access").notNull().default(false),
  premiumFeaturesUnlock: boolean("premium_features_unlock").notNull().default(false),
  canUseCharacterIdentity: boolean("can_use_character_identity").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  reason: text("reason", { enum: ["influencer", "testing", "promotion", "vip", "other"] }).notNull().default("vip"),
  notes: text("notes"),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  grantedByUserId: uuid("granted_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  grantedAt: timestamp("granted_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => ({
  userUnique: uniqueIndex("special_access_user_unique").on(t.userId),
  isActiveIdx: index("special_access_is_active_idx").on(t.isActive),
}));

export const specialAccessUsageTable = pgTable("special_access_usage", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  action: text("action").notNull(),
  metadataJson: text("metadata_json"),
  estimatedValueCents: integer("estimated_value_cents").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  userIdx: index("special_access_usage_user_idx").on(t.userId),
  createdIdx: index("special_access_usage_created_idx").on(t.createdAt),
}));

export type SpecialAccess = typeof specialAccessTable.$inferSelect;
export type SpecialAccessUsage = typeof specialAccessUsageTable.$inferSelect;
