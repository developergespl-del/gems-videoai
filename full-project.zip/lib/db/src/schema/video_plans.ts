import { pgTable, uuid, text, real, integer, boolean, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const videoPlansTable = pgTable("video_plans", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  description: text("description"),
  priceUsd: real("price_usd").notNull().default(0),
  maxLengthSeconds: integer("max_length_seconds").notNull().default(60),
  monthlyQuota: integer("monthly_quota").notNull().default(5),
  isDefault: boolean("is_default").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const userVideoPlansTable = pgTable("user_video_plans", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  planId: uuid("plan_id").notNull().references(() => videoPlansTable.id, { onDelete: "cascade" }),
  status: text("status", { enum: ["active", "expired", "cancelled"] }).notNull().default("active"),
  paidAt: timestamp("paid_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  grantedByAdminId: uuid("granted_by_admin_id").references(() => usersTable.id, { onDelete: "set null" }),
  paymentRef: text("payment_ref"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => ({
  userIdx: index("user_video_plans_user_idx").on(t.userId),
  statusIdx: index("user_video_plans_status_idx").on(t.status),
}));

export type VideoPlan = typeof videoPlansTable.$inferSelect;
export type UserVideoPlan = typeof userVideoPlansTable.$inferSelect;
