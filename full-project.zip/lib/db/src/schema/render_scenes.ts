import { pgTable, uuid, integer, text, timestamp } from "drizzle-orm/pg-core";
import { videosTable } from "./videos";

export const renderScenesTable = pgTable("render_scenes", {
  id: uuid("id").primaryKey().defaultRandom(),
  videoId: uuid("video_id").notNull().references(() => videosTable.id, { onDelete: "cascade" }),
  sceneIndex: integer("scene_index").notNull(),
  sceneTitle: text("scene_title").notNull(),
  status: text("status", {
    enum: ["pending", "queued", "rendering", "completed", "failed"],
  }).notNull().default("pending"),
  progress: integer("progress").notNull().default(0),
  workerId: text("worker_id"),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type RenderScene = typeof renderScenesTable.$inferSelect;
