import { pgTable, text, uuid, timestamp, unique } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const ADMIN_PERMISSIONS = [
  "users.view",
  "users.create",
  "users.status",
  "users.role",
  "users.delete",
  "videos.view",
  "videos.delete",
  "pricing.view",
  "pricing.manage",
  "ads.view",
  "ads.manage",
  "analytics.view",
  "api_platform.view",
  "api_platform.manage",
  "pronunciation.view",
  "pronunciation.manage",
  "settings.view",
  "settings.manage",
  "audit.view",
] as const;

export type AdminPermission = (typeof ADMIN_PERMISSIONS)[number];

export const adminPermissionsTable = pgTable("admin_permissions", {
  id: uuid("id").primaryKey().defaultRandom(),
  adminUserId: uuid("admin_user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  permission: text("permission").notNull(),
  grantedBy: uuid("granted_by").references(() => usersTable.id, { onDelete: "set null" }),
  grantedAt: timestamp("granted_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("uniq_admin_perm").on(t.adminUserId, t.permission),
]);
