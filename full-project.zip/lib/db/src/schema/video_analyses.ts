import { pgTable, text, uuid, timestamp, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { videosTable } from "./videos";

export const videoAnalysesTable = pgTable("video_analyses", {
  id: uuid("id").primaryKey().defaultRandom(),
  videoId: uuid("video_id").notNull().references(() => videosTable.id, { onDelete: "cascade" }).unique(),
  status: text("status", { enum: ["pending", "analyzing", "completed", "failed"] }).notNull().default("pending"),

  // Raw AI analysis sections stored as JSON
  contextAnalysis: jsonb("context_analysis"),
  emotionalProfile: jsonb("emotional_profile"),
  characterProfiles: jsonb("character_profiles"),
  culturalContext: jsonb("cultural_context"),
  sceneBreakdown: jsonb("scene_breakdown"),
  dialogueStyle: jsonb("dialogue_style"),
  productionPlan: jsonb("production_plan"),
  voiceDirections: jsonb("voice_directions"),

  // Summary fields for quick access
  primaryEmotion: text("primary_emotion"),
  culturalSetting: text("cultural_setting"),
  regionLanguage: text("region_language"),
  narrativeTone: text("narrative_tone"),
  estimatedSceneCount: integer("estimated_scene_count"),

  rawAnalysisText: text("raw_analysis_text"),

  // Step 2 — Screenplay
  screenplayStatus: text("screenplay_status", {
    enum: ["pending", "generating", "completed", "failed"]
  }).notNull().default("pending"),
  screenplay: jsonb("screenplay"),

  // Audio + Realism System (auto-triggers after screenplay)
  audioStatus: text("audio_status", {
    enum: ["pending", "generating", "completed", "failed"]
  }).notNull().default("pending"),
  audioProfile: jsonb("audio_profile"),
  realismProfile: jsonb("realism_profile"),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertVideoAnalysisSchema = createInsertSchema(videoAnalysesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertVideoAnalysis = z.infer<typeof insertVideoAnalysisSchema>;
export type VideoAnalysis = typeof videoAnalysesTable.$inferSelect;
