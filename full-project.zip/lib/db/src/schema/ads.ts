import { pgTable, uuid, text, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const adsTable = pgTable("ads", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type", { enum: ["image", "video", "banner"] }).notNull(),
  mediaUrl: text("media_url").notNull(),
  targetUrl: text("target_url").notNull(),
  ctaText: text("cta_text").notNull().default("Learn More"),
  placement: text("placement", { enum: ["sidebar", "gallery", "dashboard", "top_banner"] }).notNull(),
  status: text("status", {
    enum: ["draft", "active", "scheduled", "paused", "expired"],
  }).notNull().default("draft"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  impressions: integer("impressions").notNull().default(0),
  clicks: integer("clicks").notNull().default(0),
  createdByUserId: uuid("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const adEventsTable = pgTable("ad_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  adId: uuid("ad_id").notNull().references(() => adsTable.id, { onDelete: "cascade" }),
  eventType: text("event_type", { enum: ["impression", "click"] }).notNull(),
  userId: uuid("user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Ad = typeof adsTable.$inferSelect;
export type AdEvent = typeof adEventsTable.$inferSelect;
