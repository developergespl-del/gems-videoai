import { pgTable, uuid, text, integer, timestamp, boolean, jsonb, uniqueIndex, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const offersTable = pgTable("offers", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code"),
  name: text("name").notNull(),
  description: text("description"),
  discountType: text("discount_type", { enum: ["percentage", "fixed"] }).notNull(),
  discountValue: integer("discount_value").notNull(),
  applicablePlans: jsonb("applicable_plans").$type<string[]>().notNull().default([]),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  maxUses: integer("max_uses"),
  usedCount: integer("used_count").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdByUserId: uuid("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => ({
  codeUnique: uniqueIndex("offers_code_unique").on(t.code),
  isActiveIdx: index("offers_is_active_idx").on(t.isActive),
}));

export const offerRedemptionsTable = pgTable("offer_redemptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  offerId: uuid("offer_id").notNull().references(() => offersTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  planApplied: text("plan_applied"),
  redeemedAt: timestamp("redeemed_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  offerUserUnique: uniqueIndex("offer_redemptions_offer_user_unique").on(t.offerId, t.userId),
}));

export type Offer = typeof offersTable.$inferSelect;
export type OfferRedemption = typeof offerRedemptionsTable.$inferSelect;
