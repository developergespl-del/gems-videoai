import { pgTable, uuid, text, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { videosTable } from "./videos";

export interface CharacterAbility {
  characterName: string;
  abilityType: string;
  powerLevel: "dormant" | "weak" | "medium" | "strong" | "god-tier";
  evolutionArc: string;
  vfxKeywords: string[];
  physicsNotes: string;
}

export interface VfxRequirement {
  elementType: string;
  technique: string;
  colorGrading: string;
  referenceMood: string;
  avoidList: string[];
}

export interface AtmosphereProfile {
  lighting: string;
  colorPalette: string[];
  soundDesign: string;
  environmentNotes: string;
}

export interface PhysicsRule {
  element: string;
  rule: string;
  avoidList: string[];
}

export interface StyleDirectives {
  cinematicStyle: string;
  cameraRules: string;
  paceNotes: string;
  heroMoments: string[];
  signatureShots: string[];
}

export interface CulturalBlend {
  indianElements: string[];
  globalInfluences: string[];
  languageNotes: string;
}

export interface SceneVfxEntry {
  sceneIndex: number;
  vfxElements: string[];
  atmosphereIntensity: "none" | "low" | "medium" | "high" | "extreme";
  powerActivations: string[];
  directorNote: string;
}

export const paranormalProfilesTable = pgTable("paranormal_profiles", {
  id: uuid("id").primaryKey().defaultRandom(),
  videoId: uuid("video_id")
    .notNull()
    .references(() => videosTable.id, { onDelete: "cascade" })
    .unique(),
  userId: uuid("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  status: text("status", {
    enum: ["pending", "analyzing", "completed", "failed"],
  })
    .notNull()
    .default("pending"),
  contentTypes: jsonb("content_types")
    .$type<string[]>()
    .notNull()
    .default([]),
  hasParanormalElements: text("has_paranormal_elements", {
    enum: ["yes", "no", "partial"],
  })
    .notNull()
    .default("no"),
  characterAbilities: jsonb("character_abilities")
    .$type<CharacterAbility[]>()
    .notNull()
    .default([]),
  vfxRequirements: jsonb("vfx_requirements")
    .$type<VfxRequirement[]>()
    .notNull()
    .default([]),
  atmosphereProfile: jsonb("atmosphere_profile")
    .$type<AtmosphereProfile | null>()
    .default(null),
  physicsRules: jsonb("physics_rules")
    .$type<PhysicsRule[]>()
    .notNull()
    .default([]),
  styleDirectives: jsonb("style_directives")
    .$type<StyleDirectives | null>()
    .default(null),
  culturalBlend: jsonb("cultural_blend")
    .$type<CulturalBlend | null>()
    .default(null),
  realismDirectives: text("realism_directives"),
  sceneVfxMap: jsonb("scene_vfx_map")
    .$type<SceneVfxEntry[]>()
    .notNull()
    .default([]),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
}, (t) => ({
  videoIdIdx: index("paranormal_profiles_video_id_idx").on(t.videoId),
  userIdIdx: index("paranormal_profiles_user_id_idx").on(t.userId),
  statusIdx: index("paranormal_profiles_status_idx").on(t.status),
}));

export type ParanormalProfile = typeof paranormalProfilesTable.$inferSelect;
