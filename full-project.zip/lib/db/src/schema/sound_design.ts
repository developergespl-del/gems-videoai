import { pgTable, uuid, text, timestamp, boolean, integer, jsonb, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { videosTable } from "./videos";

export const soundLibraryTable = pgTable("sound_library", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  emotions: jsonb("emotions").$type<string[]>().notNull().default([]),
  environments: jsonb("environments").$type<string[]>().notNull().default([]),
  intensity: text("intensity", { enum: ["low", "medium", "high"] }).notNull().default("medium"),
  audioUrl: text("audio_url").notNull(),
  previewUrl: text("preview_url"),
  durationMs: integer("duration_ms").notNull().default(0),
  isCopyrightFree: boolean("is_copyright_free").notNull().default(true),
  license: text("license").notNull().default("CC0"),
  attribution: text("attribution"),
  isActive: boolean("is_active").notNull().default(true),
  createdByUserId: uuid("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => ({
  categoryIdx: index("sound_library_category_idx").on(t.category),
  isActiveIdx: index("sound_library_is_active_idx").on(t.isActive),
}));

export const soundAnalysesTable = pgTable("sound_analyses", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  videoId: uuid("video_id").references(() => videosTable.id, { onDelete: "set null" }),
  scriptText: text("script_text").notNull(),
  totalDetected: integer("total_detected").notNull().default(0),
  totalKept: integer("total_kept").notNull().default(0),
  totalReplaced: integer("total_replaced").notNull().default(0),
  totalAdded: integer("total_added").notNull().default(0),
  summary: text("summary"),
  status: text("status", { enum: ["completed", "failed"] }).notNull().default("completed"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  userIdx: index("sound_analyses_user_idx").on(t.userId),
  createdIdx: index("sound_analyses_created_idx").on(t.createdAt),
}));

export const soundDecisionsTable = pgTable("sound_decisions", {
  id: uuid("id").primaryKey().defaultRandom(),
  analysisId: uuid("analysis_id").notNull().references(() => soundAnalysesTable.id, { onDelete: "cascade" }),
  originalPrompt: text("original_prompt"),
  detectedCategory: text("detected_category"),
  sceneIndex: integer("scene_index").notNull().default(0),
  sceneEmotion: text("scene_emotion"),
  sceneEnvironment: text("scene_environment"),
  sceneIntensity: text("scene_intensity", { enum: ["low", "medium", "high"] }),
  decision: text("decision", { enum: ["kept", "replaced", "added"] }).notNull(),
  reason: text("reason").notNull(),
  replacementSoundId: uuid("replacement_sound_id").references(() => soundLibraryTable.id, { onDelete: "set null" }),
  suggestedDescription: text("suggested_description"),
  confidence: integer("confidence").notNull().default(80),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  analysisIdx: index("sound_decisions_analysis_idx").on(t.analysisId),
}));

export type SoundLibraryEntry = typeof soundLibraryTable.$inferSelect;
export type SoundAnalysis = typeof soundAnalysesTable.$inferSelect;
export type SoundDecision = typeof soundDecisionsTable.$inferSelect;
