import { pgTable, uuid, text, integer, timestamp } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { videosTable } from "./videos";

export const pronunciationDictionaryTable = pgTable("pronunciation_dictionary", {
  id: uuid("id").primaryKey().defaultRandom(),
  languageCode: text("language_code").notNull(),
  word: text("word").notNull(),
  phonetic: text("phonetic").notNull(),
  context: text("context"),
  region: text("region"),
  audioUrl: text("audio_url"),
  source: text("source", { enum: ["ai_seed", "admin_curated", "user_contributed"] }).notNull().default("admin_curated"),
  confidence: integer("confidence").notNull().default(100),
  createdByUserId: uuid("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const voiceCorrectionsTable = pgTable("voice_corrections", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  videoId: uuid("video_id").references(() => videosTable.id, { onDelete: "set null" }),
  word: text("word").notNull(),
  languageCode: text("language_code").notNull(),
  audioUrl: text("audio_url").notNull(),
  notes: text("notes"),
  status: text("status", { enum: ["pending", "approved", "applied", "rejected"] }).notNull().default("pending"),
  reviewedByUserId: uuid("reviewed_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type PronunciationDictionaryEntry = typeof pronunciationDictionaryTable.$inferSelect;
export type VoiceCorrection = typeof voiceCorrectionsTable.$inferSelect;
