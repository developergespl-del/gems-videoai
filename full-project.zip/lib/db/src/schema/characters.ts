import { pgTable, uuid, text, timestamp, index, boolean } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const charactersTable = pgTable("characters", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),

  frontFaceUrl: text("front_face_url"),
  leftFaceUrl: text("left_face_url"),
  rightFaceUrl: text("right_face_url"),
  backFaceUrl: text("back_face_url"),
  extraFace1Url: text("extra_face_1_url"),
  extraFace2Url: text("extra_face_2_url"),
  extraFace3Url: text("extra_face_3_url"),

  voiceSampleUrl: text("voice_sample_url"),
  voiceModelStatus: text("voice_model_status", {
    enum: ["none", "processing", "ready", "failed"],
  }).notNull().default("none"),

  status: text("status", {
    enum: ["draft", "processing", "ready"],
  }).notNull().default("draft"),

  ageGroup: text("age_group", {
    enum: ["child", "young", "adult", "elderly"],
  }).notNull().default("adult"),

  gender: text("gender", {
    enum: ["male", "female", "neutral"],
  }).notNull().default("neutral"),

  isPublic: boolean("is_public").notNull().default(false),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => ({
  userIdx: index("characters_user_idx").on(t.userId),
  statusIdx: index("characters_status_idx").on(t.status),
}));

export type Character = typeof charactersTable.$inferSelect;
