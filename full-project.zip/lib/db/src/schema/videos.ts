import { pgTable, text, uuid, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { projectsTable } from "./projects";

export const videosTable = pgTable("videos", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  projectId: uuid("project_id").references(() => projectsTable.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description"),
  inputType: text("input_type", { enum: ["story", "script", "image"] }).notNull(),
  inputContent: text("input_content").notNull(),
  style: text("style", { enum: ["cinematic", "documentary", "dramatic", "action", "romantic", "horror", "comedy"] }).notNull(),
  durationSeconds: integer("duration_seconds").notNull(),
  status: text("status", { enum: ["pending", "processing", "completed", "failed"] }).notNull().default("pending"),
  progress: integer("progress").notNull().default(0),

  // 3-step generation workflow stage
  generationStage: text("generation_stage", {
    enum: ["analyzing", "analyzed", "screenwrote", "rendering", "completed", "failed"]
  }).notNull().default("analyzing"),

  // High-speed rendering system
  priority: text("priority", { enum: ["enterprise", "paid", "free"] }).notNull().default("free"),
  workerType: text("worker_type", { enum: ["gpu", "cpu"] }).notNull().default("gpu"),
  sceneCount: integer("scene_count").notNull().default(5),
  scenesCompleted: integer("scenes_completed").notNull().default(0),
  estimatedSeconds: integer("estimated_seconds"),
  queuePosition: integer("queue_position"),
  processingStartedAt: timestamp("processing_started_at", { withTimezone: true }),

  outputUrl: text("output_url"),
  thumbnailUrl: text("thumbnail_url"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  completedAt: timestamp("completed_at", { withTimezone: true }),

  // Long-video split + intermission system
  hasIntermission: boolean("has_intermission").notNull().default(false),
  intermissionAtSecond: integer("intermission_at_second"),
  intermissionLabel: text("intermission_label"),      // "INTERMISSION" translated to video language
  isSplit: boolean("is_split").notNull().default(false),
  splitAtSecond: integer("split_at_second"),
  part1Title: text("part1_title"),
  part2Title: text("part2_title"),

  // Cinema-grade output settings
  aspectRatio: text("aspect_ratio", { enum: ["16:9", "9:16", "21:9", "2.39:1"] }).notNull().default("16:9"),
  resolution: text("resolution", { enum: ["1080p", "2K", "4K", "8K"] }).notNull().default("1080p"),
  cinemaMode: boolean("cinema_mode").notNull().default(false),
  colorGrade: text("color_grade", {
    enum: ["natural", "warm", "cold", "noir", "vibrant", "indian-vivid"],
  }).notNull().default("natural"),
  filmGrain: boolean("film_grain").notNull().default(false),
  depthOfField: boolean("depth_of_field").notNull().default(true),
  audioMastering: text("audio_mastering", { enum: ["stereo", "surround-ready"] }).notNull().default("stereo"),
  exportFormats: jsonb("export_formats").$type<string[]>().notNull().default(["youtube"]),
  characterMappings: jsonb("character_mappings").$type<{ scriptName: string; characterId: string }[]>().notNull().default([]),
  // Language this video is generated in (language code, e.g. "hi", "en")
  language: text("language"),
  // Bulk generation batch ID — links videos created together from one script
  bulkBatchId: text("bulk_batch_id"),
});

export const insertVideoSchema = createInsertSchema(videosTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Video = typeof videosTable.$inferSelect;
