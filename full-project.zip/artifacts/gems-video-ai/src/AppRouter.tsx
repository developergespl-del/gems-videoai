import { Switch, Route, Redirect } from "wouter";
import { AppLayout } from "@/components/layout/app-layout";
import { LandingPage } from "@/pages/landing";
import { LoginPage } from "@/pages/auth/login";
import { RegisterPage } from "@/pages/auth/register";
import { Dashboard } from "@/pages/dashboard";
import { VideosPage } from "@/pages/videos";
import { NewVideoPage } from "@/pages/videos/new";
import { VideoDetailPage } from "@/pages/videos/detail";
import { ProjectsPage } from "@/pages/projects";
import { ProjectDetailPage } from "@/pages/projects/detail";
import { SettingsPage } from "@/pages/settings";
import { AdminPage } from "@/pages/admin";
import { PronunciationPage } from "@/pages/pronunciation";
import { SoundDesignPage } from "@/pages/sound-design";
import ProfilePage from "@/pages/profile";
import { CharactersPage } from "@/pages/characters";
import { StorePage } from "@/pages/store";
import { SupportPage } from "@/pages/support";
import { BulkGeneratePage } from "@/pages/bulk-generate";
import NotFound from "@/pages/not-found";

import { useAuth } from "@/hooks/use-auth";
import { useGetPlatformSettings, getGetPlatformSettingsQueryKey } from "@workspace/api-client-react";
import { Loader2, Wrench } from "lucide-react";

function MaintenanceScreen({ message }: { message: string }) {
  return (
    <div className="flex h-screen w-full flex-col items-center justify-center bg-background gap-6 text-center px-4">
      <div className="w-20 h-20 rounded-2xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center">
        <Wrench className="w-10 h-10 text-yellow-400" />
      </div>
      <div>
        <h1 className="text-3xl font-display font-bold text-white mb-2">Under Maintenance</h1>
        <p className="text-muted-foreground max-w-md text-sm leading-relaxed">
          {message || "The system is currently under maintenance. Please check back soon."}
        </p>
      </div>
      <div className="flex items-center gap-2 text-xs text-white/30">
        <div className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse" />
        GEMS Video AI · Maintenance Mode
      </div>
    </div>
  );
}

function ProtectedRoute({ component: Component, adminOnly = false }: { component: any, adminOnly?: boolean }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/login" />;
  }

  if (adminOnly && user.role !== "admin" && user.role !== "super_admin") {
    return <Redirect to="/dashboard" />;
  }

  return (
    <AppLayout>
      <Component />
    </AppLayout>
  );
}

export function AppRouter() {
  const { user, isLoading } = useAuth();

  const { data: platformSettings } = useGetPlatformSettings({
    query: { queryKey: getGetPlatformSettingsQueryKey(), refetchInterval: 30000, staleTime: 10000 }
  });

  const isMaintenanceMode = platformSettings?.maintenanceMode === true;
  const isSuperAdmin = user?.role === "super_admin";

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Show maintenance screen to non-super-admin users when maintenance mode is active
  if (isMaintenanceMode && !isSuperAdmin) {
    return <MaintenanceScreen message={platformSettings?.maintenanceMessage ?? ""} />;
  }

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/">
        {user ? <Redirect to="/dashboard" /> : <LandingPage />}
      </Route>
      <Route path="/login">
        {user ? <Redirect to="/dashboard" /> : <LoginPage />}
      </Route>
      <Route path="/register">
        {user ? <Redirect to="/dashboard" /> : <RegisterPage />}
      </Route>

      {/* Protected routes */}
      <Route path="/dashboard">
        <ProtectedRoute component={Dashboard} />
      </Route>
      <Route path="/videos">
        <ProtectedRoute component={VideosPage} />
      </Route>
      <Route path="/videos/new">
        <ProtectedRoute component={NewVideoPage} />
      </Route>
      <Route path="/videos/:id">
        <ProtectedRoute component={VideoDetailPage} />
      </Route>
      <Route path="/projects">
        <ProtectedRoute component={ProjectsPage} />
      </Route>
      <Route path="/projects/:id">
        <ProtectedRoute component={ProjectDetailPage} />
      </Route>
      <Route path="/settings">
        <ProtectedRoute component={SettingsPage} />
      </Route>
      <Route path="/admin">
        <ProtectedRoute component={AdminPage} adminOnly />
      </Route>
      <Route path="/pronunciation">
        <ProtectedRoute component={PronunciationPage} />
      </Route>
      <Route path="/sound-design">
        <ProtectedRoute component={SoundDesignPage} />
      </Route>
      <Route path="/profile">
        <ProtectedRoute component={ProfilePage} />
      </Route>
      <Route path="/characters">
        <ProtectedRoute component={CharactersPage} />
      </Route>
      <Route path="/store">
        <ProtectedRoute component={StorePage} />
      </Route>
      <Route path="/support">
        <ProtectedRoute component={SupportPage} />
      </Route>
      <Route path="/bulk-generate">
        <ProtectedRoute component={BulkGeneratePage} adminOnly />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}
