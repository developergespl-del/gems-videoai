import { useEffect, useRef } from "react";
import { useRecordAdImpression, useRecordAdClick } from "@workspace/api-client-react";
import { ExternalLink } from "lucide-react";
import type { Ad } from "@workspace/api-client-react";

interface AdUnitProps {
  ad: Ad;
  compact?: boolean;
}

export function AdUnit({ ad, compact = false }: AdUnitProps) {
  const impressionMutation = useRecordAdImpression();
  const clickMutation = useRecordAdClick();
  const trackedAds = useRef(new Set<string>());

  useEffect(() => {
    if (!trackedAds.current.has(ad.id)) {
      trackedAds.current.add(ad.id);
      impressionMutation.mutate({ id: ad.id });
    }
  }, [ad.id]);

  const handleClick = () => {
    clickMutation.mutate({ id: ad.id });
    window.open(ad.targetUrl, "_blank", "noopener,noreferrer");
  };

  if (compact) {
    return (
      <div className="group relative rounded-lg overflow-hidden border border-white/10 bg-white/5 hover:bg-white/10 transition-all cursor-pointer" onClick={handleClick}>
        {ad.mediaUrl && (
          <img
            src={ad.mediaUrl}
            alt={ad.title}
            className="w-full h-24 object-cover"
            onError={(e) => { e.currentTarget.style.display = "none"; }}
          />
        )}
        <div className="p-3">
          <p className="text-xs font-medium text-white truncate">{ad.title}</p>
          {ad.description && (
            <p className="text-xs text-white/50 mt-0.5 line-clamp-1">{ad.description}</p>
          )}
          <button className="mt-2 text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors">
            {ad.ctaText} <ExternalLink className="w-3 h-3" />
          </button>
        </div>
        <span className="absolute top-1 right-1 text-[9px] text-white/30 bg-black/40 px-1 rounded">Ad</span>
      </div>
    );
  }

  return (
    <div className="group relative rounded-xl overflow-hidden border border-white/10 bg-gradient-to-br from-white/5 to-white/[0.02] hover:border-purple-500/30 transition-all cursor-pointer shadow-lg" onClick={handleClick}>
      {ad.mediaUrl && (
        <div className="relative h-40 overflow-hidden">
          {ad.type === "video" ? (
            <video
              src={ad.mediaUrl}
              className="w-full h-full object-cover"
              autoPlay
              muted
              loop
              playsInline
            />
          ) : (
            <img
              src={ad.mediaUrl}
              alt={ad.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              onError={(e) => { e.currentTarget.style.display = "none"; }}
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        </div>
      )}
      <div className="p-4">
        <h4 className="text-sm font-semibold text-white">{ad.title}</h4>
        {ad.description && (
          <p className="text-xs text-white/60 mt-1 line-clamp-2">{ad.description}</p>
        )}
        <button className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium text-white bg-purple-600 hover:bg-purple-500 px-3 py-1.5 rounded-lg transition-colors">
          {ad.ctaText} <ExternalLink className="w-3 h-3" />
        </button>
      </div>
      <span className="absolute top-2 right-2 text-[9px] text-white/40 bg-black/50 px-1.5 py-0.5 rounded-full">Sponsored</span>
    </div>
  );
}
