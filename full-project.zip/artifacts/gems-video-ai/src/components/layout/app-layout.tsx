import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  Film, 
  LayoutDashboard, 
  FolderKanban, 
  Settings, 
  LogOut, 
  ShieldAlert,
  Loader2,
  UserCircle,
  AudioLines,
  Volume2,
  Menu,
  X,
  Users,
  ShoppingBag,
  LifeBuoy,
  Languages,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useListAds } from "@workspace/api-client-react";
import { AdUnit } from "@/components/ad-unit";

function TopBannerAd() {
  const { data: bannerAds } = useListAds({ placement: "top_banner" });
  if (!bannerAds || bannerAds.length === 0) return null;
  return (
    <div className="w-full border-b border-border bg-sidebar/50 px-4 py-1.5 flex items-center justify-center">
      <AdUnit ad={bannerAds[0]} compact />
    </div>
  );
}

interface AppLayoutProps {
  children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const { user, isLoading, logout } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { data: sidebarAds } = useListAds({ placement: "sidebar" });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!user) {
    // Should be handled by router protection, but just in case
    return null;
  }

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/videos", label: "My Videos", icon: Film },
    { href: "/projects", label: "Projects", icon: FolderKanban },
    { href: "/store", label: "Store", icon: ShoppingBag },
    { href: "/characters", label: "Characters", icon: Users },
    { href: "/pronunciation", label: "Pronunciation", icon: AudioLines },
    { href: "/sound-design", label: "Sound Design", icon: Volume2 },
    { href: "/profile", label: "Profile", icon: UserCircle },
    { href: "/settings", label: "Settings", icon: Settings },
    { href: "/support", label: "Support", icon: LifeBuoy },
  ];

  if (user.role === "super_admin") {
    navItems.push({ href: "/bulk-generate", label: "Bulk Generator", icon: Languages });
  }

  if (user.role === "admin" || user.role === "super_admin") {
    navItems.push({ href: "/admin", label: "Admin Panel", icon: ShieldAlert });
  }

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-sidebar hidden md:flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <Link href="/dashboard" className="flex items-center gap-2 text-primary font-display font-bold text-xl tracking-tight">
            <Film className="w-6 h-6" />
            <span>GEMS</span>
          </Link>
        </div>
        
        <nav className="flex-1 py-6 px-4 space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.href || location.startsWith(`${item.href}/`);
            return (
              <Link key={item.href} href={item.href} className="block">
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className={`w-full justify-start gap-3 ${isActive ? 'text-primary border-r-2 border-primary rounded-none rounded-l' : 'text-muted-foreground hover:text-foreground'}`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Button>
              </Link>
            );
          })}
        </nav>

        {/* Sidebar Ad Slot — only visible when ads are enabled and user is eligible */}
        {sidebarAds && sidebarAds.length > 0 && (
          <div className="px-3 pb-2">
            <AdUnit ad={sidebarAds[0]} compact />
          </div>
        )}

        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 px-2 mb-4">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 overflow-hidden">
              <div className="text-sm font-medium truncate">{user.name}</div>
              <div className="text-xs text-muted-foreground truncate">{user.email}</div>
            </div>
          </div>
          <Button variant="ghost" className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground hover:bg-destructive/10" onClick={() => logout()}>
            <LogOut className="w-4 h-4" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Mobile Nav Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-72 bg-sidebar border-r border-border flex flex-col">
            <div className="h-16 flex items-center justify-between px-6 border-b border-border">
              <Link href="/dashboard" className="flex items-center gap-2 text-primary font-display font-bold text-xl tracking-tight" onClick={() => setMobileMenuOpen(false)}>
                <Film className="w-6 h-6" />
                <span>GEMS</span>
              </Link>
              <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(false)}>
                <X className="w-5 h-5" />
              </Button>
            </div>
            <nav className="flex-1 py-6 px-4 space-y-2">
              {navItems.map((item) => {
                const isActive = location === item.href || location.startsWith(`${item.href}/`);
                return (
                  <Link key={item.href} href={item.href} className="block" onClick={() => setMobileMenuOpen(false)}>
                    <Button
                      variant={isActive ? "secondary" : "ghost"}
                      className={`w-full justify-start gap-3 ${isActive ? 'text-primary border-r-2 border-primary rounded-none rounded-l' : 'text-muted-foreground hover:text-foreground'}`}
                    >
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
            </nav>
            <div className="p-4 border-t border-border">
              <div className="flex items-center gap-3 px-2 mb-4">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
                  {(user.name || "U").charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 overflow-hidden">
                  <div className="text-sm font-medium truncate">{user.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{user.email}</div>
                </div>
              </div>
              <Button variant="ghost" className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground hover:bg-destructive/10" onClick={() => { setMobileMenuOpen(false); logout(); }}>
                <LogOut className="w-4 h-4" />
                Sign Out
              </Button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-h-screen overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden h-16 border-b border-border flex items-center justify-between px-4 bg-sidebar">
          <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(true)}>
            <Menu className="w-5 h-5" />
          </Button>
          <Link href="/dashboard" className="flex items-center gap-2 text-primary font-display font-bold text-xl tracking-tight">
            <Film className="w-6 h-6" />
            <span>GEMS</span>
          </Link>
          <div className="w-10" />
        </header>

        {/* Top Banner Ad Slot */}
        <TopBannerAd />

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
