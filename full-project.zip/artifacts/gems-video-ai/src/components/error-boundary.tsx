import { Component, type ReactNode, type ErrorInfo } from "react";
import { AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidMount() {
    // In development, auto-reset after Vite HMR updates so transient context
    // invalidations don't permanently block the UI.
    if (typeof window !== "undefined" && (import.meta as any).hot) {
      (import.meta as any).hot.on("vite:afterUpdate", () => {
        if (this.state.hasError) {
          this.setState({ hasError: false, error: null });
        }
      });
    }
  }

  componentDidCatch(_error: Error, _info: ErrorInfo) {
    // Errors are surfaced in the render() fallback UI.
    // In production, wire up to an error tracking service here.
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-background flex flex-col items-center justify-center p-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-destructive/10 border border-destructive/20 flex items-center justify-center mb-6">
            <AlertCircle className="w-8 h-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-display font-bold mb-2">Something went wrong</h1>
          <p className="text-muted-foreground text-sm max-w-md mb-2">
            An unexpected error occurred. Try refreshing the page.
          </p>
          {this.state.error?.message && (
            <p className="text-xs text-muted-foreground/60 font-mono bg-white/5 px-3 py-1.5 rounded mb-6 max-w-sm truncate">
              {this.state.error.message}
            </p>
          )}
          <Button onClick={() => window.location.reload()} className="gap-2">
            <RefreshCw className="w-4 h-4" /> Refresh Page
          </Button>
        </div>
      );
    }

    return this.props.children;
  }
}
