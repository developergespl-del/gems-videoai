/**
 * GEMS Generation Workflow — 4-Step Pipeline
 *
 * Step 1 — ANALYZE:       Deep story breakdown, emotion timeline, character mapping
 * Step 2 — SCREENPLAY:    Scene breakdown, camera angles, dialogue placement
 * Step 3 — AUDIO+REALISM: Voice profiles, music, no-artifact enforcement (auto)
 * Step 4 — GENERATE:      Final rendering, voice + lip sync, emotion accuracy
 *
 * Each step is locked until the previous completes.
 * Step 3 is fully automatic — auto-fires after screenplay.
 */
import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Brain,
  FileText,
  Video,
  CheckCircle2,
  Lock,
  ChevronDown,
  ChevronUp,
  Loader2,
  Users,
  Heart,
  Globe,
  Film,
  Mic,
  Sparkles,
  Eye,
  Camera,
  Zap,
  RefreshCw,
  Play,
  AlertCircle,
  Music,
  Volume2,
  Wand2,
  Headphones,
  SunMedium,
  PersonStanding,
  Gauge,
  ShieldCheck,
  Radio,
  Waves,
  Languages,
  SlidersHorizontal,
  Upload,
  AlertTriangle,
  CheckCheck,
  BookOpen,
  Cpu,
  Server,
  Clock,
  Layers,
  Rocket,
  Timer,
  Wifi,
  WifiOff,
  Activity,
  Clapperboard,
} from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { customFetch, ApiError, useGetVideo, useGetVideoScenes, useListLanguages, usePurchaseLanguage, getListLanguagesQueryKey, getGetVideoQueryKey, getGetVideoScenesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type GenerationStage =
  | "analyzing"
  | "analyzed"
  | "screenwrote"
  | "rendering"
  | "completed"
  | "failed";

type AudioStatus = "pending" | "generating" | "completed" | "failed";

interface VideoWithStage {
  id: string;
  title: string;
  inputType: string;
  style: string;
  durationSeconds: number;
  generationStage: GenerationStage;
  status: string;
  progress: number;
  priority?: string;
  workerType?: string;
  sceneCount?: number;
  scenesCompleted?: number;
  estimatedSeconds?: number | null;
  queuePosition?: number | null;
  processingStartedAt?: string | null;
}

interface CharacterProfile {
  name: string; age: number; gender: string; role: string;
  occupation: string; dress: string; physicalDescription: string;
  personality: string[]; emotionalState: string; voiceStyle: string;
  accent: string; dialect: string; ageProgressionNeeded: boolean;
  ageProgressionFrom?: number; ageProgressionTo?: number; voiceChangeWithAge: string;
}

interface EmotionalArcPoint { moment: string; emotion: string; intensity: number; }

interface EmotionalProfile {
  primaryEmotion: string; secondaryEmotions: string[];
  emotionalArc: EmotionalArcPoint[]; overallTone: string;
  audienceImpact: string; indianEmotionMapping: string;
}

interface CulturalContext {
  isCulturallyIndian: boolean; region: string; language: string;
  dialect: string; traditions: string[]; festivals: string[];
  horrorArchetypes: string[]; familyDynamics: string;
  socialContext: string; regionalFlavour: string; musicalStyle: string; clothingEra: string;
}

interface ContextAnalysis {
  coreStory: string; theme: string; setting: string; timePeriod: string;
  pointOfView: string; conflictType: string; underlyingMessage: string;
  targetAudience: string; culturalResonance: string; symbolism: string[]; humanTruth: string;
}

// Audio types
interface EmotionBeat {
  sceneNumber: number; emotion: string; intensity: number;
  colorTemperature: string; audioMood: string; description: string;
}

interface VoiceProfile {
  character: string; age: number; gender: string; language: string;
  baseVoiceTone: string; breathingPattern: string; speakingPace: string;
  naturalPauses: string[]; emotionModulation: Record<string, string>;
  ageVoiceEffect: string; copyrightNote: string;
}

interface MusicSceneMap {
  sceneNumber: number; trackMood: string; volumeDynamics: string; instrument: string;
}

interface BackgroundMusic {
  primaryGenre: string; mood: string; bpm: number; musicalKey: string;
  instruments: string[]; dynamicRange: string; licenseType: string;
  referenceStyle: string; sceneMapping: MusicSceneMap[]; noList: string[];
}

interface AudioProfile {
  emotionTimeline: EmotionBeat[];
  voiceProfiles: VoiceProfile[];
  backgroundMusic: BackgroundMusic;
  mixingDirections: string;
  silenceUsage: string;
  audioMasteringNote: string;
}

// Realism types
interface ArtifactPrevention {
  morphingZeroTolerance: boolean; handRendering: string;
  eyeRealism: string; teethVisibility: string; hairPhysics: string;
  earLobeAndNeckDetail: string;
}

interface FacialExpressionSystem {
  microExpressionCapture: string; emotionBlending: string;
  muscleTension: string; skinDeformation: string;
  eyeContactBehavior: string; blinkRate: string;
}

interface LightingSpec {
  type: string; colorTemperature: string; shadowSoftness: string;
  practicalLights: string; goldenHourUsage: string;
  avoidList: string[]; skintoneRendering: string;
}

interface MovementRealism {
  bodyWeight: string; breathingVisible: string;
  cameraMotion: string; clothingPhysics: string; microTremorsAndFidget: string;
}

interface RealismProfile {
  artifactPrevention: ArtifactPrevention;
  facialExpressions: FacialExpressionSystem;
  lighting: LightingSpec;
  movementRealism: MovementRealism;
  skinTextureDetail: string;
  environmentalism: string;
  humanTruthStatement: string;
}

interface AnalysisData {
  status: string;
  screenplayStatus?: string;
  audioStatus?: AudioStatus;
  screenplay?: ScreenplayData;
  audioProfile?: AudioProfile;
  realismProfile?: RealismProfile;
  generationStage: GenerationStage;
  contextAnalysis?: ContextAnalysis;
  emotionalProfile?: EmotionalProfile;
  characterProfiles?: CharacterProfile[];
  culturalContext?: CulturalContext;
  primaryEmotion?: string;
  regionLanguage?: string;
  narrativeTone?: string;
  estimatedSceneCount?: number;
}

interface DialogueLine {
  character: string; parenthetical: string; line: string;
  languageNote: string; deliveryNote: string;
}

interface EmotionAccuracyBeat {
  timecode: string; character: string; microExpression: string;
  intensity: number; muscleGroups: string; eyeDirection: string; lipPosition: string;
}

interface ScreenplayScene {
  number: number; slugLine: string; interiorExterior: string;
  location: string; timeOfDay: string; action: string;
  cameraDirection: string; lensBehavior: string; colorGradingNote: string;
  lightingInstruction: string; soundDirection: string; ambientSoundscape: string;
  musicCue: string; characters: string[]; dialogue: DialogueLine[];
  transition: string; emotionTarget: string; voiceNote: string;
  lipSyncNote: string; emotionAccuracy: EmotionAccuracyBeat[]; duration: number; culturalElement: string;
}

interface ScreenplayData {
  title: string; logline: string; genre: string; style: string;
  totalDuration: number; writtenBy: string; basedOn: string;
  scenes: ScreenplayScene[];
  openingSlate: string; closingSlate: string; productionNotes: string;
  voiceActingDirections: string; lipSyncGuidance: string;
  overallEmotionArc: string; culturalAuthenticityNotes: string; renderingDirections: string;
}

// ---------------------------------------------------------------------------
// Step definitions (4-step pipeline)
// ---------------------------------------------------------------------------

const STEPS = [
  {
    num: 1,
    id: "analyze",
    icon: Brain,
    label: "Analyze",
    subtitle: "Story · Emotions · Characters",
    color: "text-amber-400",
    glow: "rgba(251,191,36,0.3)",
    activeStages: ["analyzing"] as GenerationStage[],
    doneStages: ["analyzed", "screenwrote", "rendering", "completed"] as GenerationStage[],
    auto: false,
  },
  {
    num: 2,
    id: "screenplay",
    icon: FileText,
    label: "Screenplay",
    subtitle: "Scenes · Cameras · Dialogue",
    color: "text-blue-400",
    glow: "rgba(96,165,250,0.3)",
    activeStages: [] as GenerationStage[],
    doneStages: ["screenwrote", "rendering", "completed"] as GenerationStage[],
    auto: false,
  },
  {
    num: 3,
    id: "audio",
    icon: Headphones,
    label: "Audio & Realism",
    subtitle: "Voice · Music · No-Artifact",
    color: "text-purple-400",
    glow: "rgba(192,132,252,0.3)",
    activeStages: [] as GenerationStage[],
    doneStages: ["rendering", "completed"] as GenerationStage[],
    auto: true,  // auto-generates, no user action
  },
  {
    num: 4,
    id: "generate",
    icon: Video,
    label: "Generate Video",
    subtitle: "Render · Lip Sync · Emotion",
    color: "text-green-400",
    glow: "rgba(74,222,128,0.3)",
    activeStages: ["rendering"] as GenerationStage[],
    doneStages: ["completed"] as GenerationStage[],
    auto: false,
  },
];

const THINKING = [
  "Reading your story with full attention...",
  "Identifying every character and their soul...",
  "Mapping the emotional architecture...",
  "Detecting cultural resonance and Indian roots...",
  "Building the cinematic intelligence map...",
  "Feeling each scene through a director's eyes...",
];

const SCREENPLAY_THINKING = [
  "Translating analysis into cinematic language...",
  "Writing slug lines and action beats...",
  "Crafting authentic dialogue with regional voice...",
  "Mapping lip sync phonemes for precision...",
  "Generating emotion accuracy beat-by-beat...",
  "Directing camera angles and lens behavior...",
  "Finalizing the production-ready screenplay...",
];

const AUDIO_THINKING = [
  "Listening to the emotional heartbeat of the story...",
  "Designing voice profiles for each character...",
  "Calibrating age-based vocal frequencies...",
  "Mapping breathing patterns to emotional beats...",
  "Selecting copyright-free cinematic music...",
  "Engineering realism rules against AI artifacts...",
  "Finalizing the audio-visual truth specification...",
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function IntensityBar({ value, color = "bg-amber-400" }: { value: number; color?: string }) {
  return (
    <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
      <motion.div className={`h-full ${color} rounded-full`}
        initial={{ width: 0 }} animate={{ width: `${Math.min(value * 100, 100)}%` }}
        transition={{ duration: 0.6, ease: "easeOut" }} />
    </div>
  );
}

function Collapsible({ title, icon, badge, children, defaultOpen = false, accent = "text-amber-400" }: {
  title: string; icon: React.ReactNode; badge?: string;
  children: React.ReactNode; defaultOpen?: boolean; accent?: string;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-white/5 rounded-xl overflow-hidden">
      <button onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-5 py-3.5 hover:bg-white/5 transition-colors">
        <div className="flex items-center gap-2.5">
          <span className={accent}>{icon}</span>
          <span className="text-xs font-semibold uppercase tracking-widest text-white/50">{title}</span>
          {badge && <Badge variant="outline" className={`text-xs border-current/30 ${accent}`}>{badge}</Badge>}
        </div>
        {open ? <ChevronUp className="w-3.5 h-3.5 text-white/30" /> : <ChevronDown className="w-3.5 h-3.5 text-white/30" />}
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.22 }}
            style={{ overflow: "hidden" }}>
            <div className="px-5 pb-5 pt-1 bg-black/20">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Thinking animation
// ---------------------------------------------------------------------------
function ThinkingAnimation({ messages, icon: Icon = Brain, color = "text-amber-400", glow = "rgba(251,191,36,0.3)" }: {
  messages: string[];
  icon?: React.ComponentType<any>;
  color?: string;
  glow?: string;
}) {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx(i => (i + 1) % messages.length), 2200);
    return () => clearInterval(t);
  }, [messages]);
  return (
    <div className="flex flex-col items-center py-8 space-y-5">
      <div className="relative">
        <div className={`w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center ${color}`}
          style={{ boxShadow: `0 0 30px ${glow}` }}>
          <Icon className="w-8 h-8" />
        </div>
        <div className="absolute inset-0 rounded-full animate-ping bg-white/5 opacity-40" />
      </div>
      <div className="min-h-[1.5rem]">
        <AnimatePresence mode="wait">
          <motion.p key={idx} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.3 }}
            className="text-white/40 text-sm italic text-center">{messages[idx]}</motion.p>
        </AnimatePresence>
      </div>
      <div className="flex gap-2">
        {[0, 1, 2].map(i => (
          <motion.div key={i} className={`w-1.5 h-1.5 rounded-full ${color.replace("text-", "bg-")}`}
            animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 1.2, delay: i * 0.4, repeat: Infinity }} />
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Step 1 — Analysis results panel
// ---------------------------------------------------------------------------
function AnalysisResults({ data }: { data: AnalysisData }) {
  const ctx = data.contextAnalysis;
  const ep = data.emotionalProfile;
  const chars = data.characterProfiles;
  const cc = data.culturalContext;

  return (
    <div className="space-y-3 mt-4">
      {/* Quick stats */}
      <div className="flex flex-wrap gap-3 px-1">
        {data.primaryEmotion && (
          <div className="flex items-center gap-1.5 text-xs">
            <Heart className="w-3.5 h-3.5 text-rose-400" />
            <span className="text-white/40">Emotion:</span>
            <span className="text-white/80">{data.primaryEmotion}</span>
          </div>
        )}
        {data.regionLanguage && (
          <div className="flex items-center gap-1.5 text-xs">
            <Globe className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-white/40">Region:</span>
            <span className="text-white/80">{data.regionLanguage}</span>
          </div>
        )}
        {data.estimatedSceneCount != null && (
          <div className="flex items-center gap-1.5 text-xs">
            <Eye className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-white/40">Scenes:</span>
            <span className="text-white/80">{data.estimatedSceneCount}</span>
          </div>
        )}
        {data.narrativeTone && (
          <div className="flex items-center gap-1.5 text-xs">
            <Film className="w-3.5 h-3.5 text-purple-400" />
            <span className="text-white/40">Tone:</span>
            <span className="text-white/80">{data.narrativeTone}</span>
          </div>
        )}
      </div>

      {ctx && (
        <Collapsible title="Story Intelligence" icon={<Sparkles className="w-3.5 h-3.5" />} defaultOpen>
          <div className="space-y-3 text-sm">
            <p className="text-white/70 leading-relaxed">{ctx.coreStory}</p>
            <div className="grid grid-cols-2 gap-3">
              {[["Theme", ctx.theme], ["Conflict", ctx.conflictType], ["Setting", ctx.setting], ["Era", ctx.timePeriod]].map(([k, v]) => (
                <div key={k}>
                  <div className="text-white/30 text-xs uppercase tracking-wide mb-0.5">{k}</div>
                  <div className="text-white/70 text-xs">{v}</div>
                </div>
              ))}
            </div>
            <div className="border-t border-white/5 pt-3">
              <div className="text-white/30 text-xs uppercase tracking-wide mb-1">Human Truth</div>
              <p className="italic text-amber-400/80 text-xs leading-relaxed">"{ctx.humanTruth}"</p>
            </div>
            {ctx.symbolism?.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {ctx.symbolism.map((s, i) => (
                  <span key={i} className="text-xs bg-white/5 border border-white/10 rounded px-2 py-0.5 text-white/60">{s}</span>
                ))}
              </div>
            )}
          </div>
        </Collapsible>
      )}

      {ep && (
        <Collapsible title="Emotion Timeline" icon={<Heart className="w-3.5 h-3.5" />} defaultOpen>
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2 items-center">
              <Badge className="bg-rose-500/10 text-rose-400 border-rose-500/20 text-xs capitalize">{ep.primaryEmotion}</Badge>
              {ep.secondaryEmotions?.slice(0, 3).map((e, i) => (
                <Badge key={i} variant="outline" className="text-xs border-white/10 text-white/50 capitalize">{e}</Badge>
              ))}
            </div>
            <div className="text-xs text-amber-400/70 italic">{ep.indianEmotionMapping}</div>
            <div className="space-y-2 mt-1">
              {ep.emotionalArc?.map((pt, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs text-white/30 w-36 shrink-0 truncate">{pt.moment}</span>
                  <IntensityBar value={pt.intensity} />
                  <span className="text-xs text-white/50 w-24 text-right capitalize shrink-0">{pt.emotion}</span>
                </div>
              ))}
            </div>
          </div>
        </Collapsible>
      )}

      {chars && chars.length > 0 && (
        <Collapsible title="Character Map" icon={<Users className="w-3.5 h-3.5" />} badge={`${chars.length}`}>
          <div className="space-y-3">
            {chars.map((c, i) => (
              <div key={i} className="border border-white/5 rounded-lg p-3 bg-black/20 space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-sm text-white">{c.name}</span>
                  <Badge variant="outline" className="text-xs border-white/10 text-white/40 capitalize">{c.role}</Badge>
                  {c.age > 0 && <span className="text-white/30 text-xs">Age {c.age}</span>}
                  {c.ageProgressionNeeded && c.ageProgressionFrom != null && (
                    <span className="text-xs text-amber-400/70">→ Age {c.ageProgressionTo} progression</span>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-white/50">
                  <div><span className="text-white/25">Voice:</span> {c.voiceStyle}</div>
                  <div><span className="text-white/25">Accent:</span> {c.accent}</div>
                  <div className="col-span-2"><span className="text-white/25">Dress:</span> {c.dress}</div>
                </div>
                {c.personality?.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {c.personality.slice(0, 4).map((p, j) => (
                      <span key={j} className="text-xs bg-white/5 rounded px-1.5 py-0.5 text-white/40">{p}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </Collapsible>
      )}

      {cc && cc.isCulturallyIndian && (
        <Collapsible title="Indian Cultural Intelligence" icon={<Globe className="w-3.5 h-3.5" />}>
          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-3 gap-2">
              <div><div className="text-white/25 uppercase tracking-wide mb-0.5">Region</div><div className="text-white/60">{cc.region}</div></div>
              <div><div className="text-white/25 uppercase tracking-wide mb-0.5">Language</div><div className="text-white/60">{cc.language}</div></div>
              <div><div className="text-white/25 uppercase tracking-wide mb-0.5">Music</div><div className="text-white/60">{cc.musicalStyle}</div></div>
            </div>
            {cc.horrorArchetypes?.length > 0 && (
              <div>
                <div className="text-rose-400/60 uppercase tracking-wide mb-1.5 text-xs font-medium">Horror Archetypes</div>
                <div className="flex flex-wrap gap-1.5">
                  {cc.horrorArchetypes.map((h, i) => (
                    <Badge key={i} className="text-xs bg-rose-500/10 text-rose-400 border-rose-500/20">{h}</Badge>
                  ))}
                </div>
              </div>
            )}
            <p className="text-white/40 leading-relaxed">{cc.regionalFlavour}</p>
          </div>
        </Collapsible>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Step 2 — Screenplay display
// ---------------------------------------------------------------------------
function ScreenplayDisplay({ screenplay }: { screenplay: ScreenplayData }) {
  return (
    <div className="space-y-4 mt-4">
      <div className="bg-black border border-white/10 rounded-xl p-5 font-mono text-center space-y-1">
        <div className="text-white font-bold text-lg tracking-widest uppercase">{screenplay.title}</div>
        {screenplay.writtenBy && <div className="text-white/30 text-xs">Written by {screenplay.writtenBy}</div>}
        {screenplay.logline && (
          <div className="mt-3 text-white/50 text-xs italic max-w-lg mx-auto leading-relaxed">"{screenplay.logline}"</div>
        )}
        <div className="flex justify-center gap-4 mt-3">
          <span className="text-xs text-amber-400 border border-amber-400/20 rounded px-2 py-0.5">{screenplay.genre}</span>
          <span className="text-xs text-white/30">{screenplay.totalDuration}s</span>
        </div>
      </div>

      {screenplay.productionNotes && (
        <div className="text-xs text-white/40 italic px-1 leading-relaxed">{screenplay.productionNotes}</div>
      )}

      <div className="space-y-4">
        {screenplay.scenes?.map((scene, i) => (
          <div key={i} className="border border-white/5 rounded-xl overflow-hidden">
            <div className="bg-white/5 px-4 py-2.5 flex items-center justify-between">
              <div className="font-mono text-xs font-bold text-white tracking-wider">{scene.slugLine}</div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs border-white/10 text-white/40">{scene.emotionTarget}</Badge>
                <span className="text-xs text-white/25 font-mono">{scene.duration}s</span>
              </div>
            </div>
            <div className="p-4 space-y-4">
              <p className="text-sm text-white/60 leading-relaxed">{scene.action}</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {scene.cameraDirection && (
                  <div className="flex items-start gap-1.5">
                    <Camera className="w-3 h-3 text-blue-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="text-white/25 uppercase tracking-wide text-xs mb-0.5">Camera</div>
                      <div className="text-white/55 font-mono">{scene.cameraDirection}</div>
                    </div>
                  </div>
                )}
                {scene.soundDirection && (
                  <div className="flex items-start gap-1.5">
                    <Music className="w-3 h-3 text-purple-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="text-white/25 uppercase tracking-wide text-xs mb-0.5">Sound</div>
                      <div className="text-white/55">{scene.soundDirection}</div>
                    </div>
                  </div>
                )}
                {scene.lightingInstruction && (
                  <div className="flex items-start gap-1.5">
                    <Sparkles className="w-3 h-3 text-amber-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="text-white/25 uppercase tracking-wide text-xs mb-0.5">Light</div>
                      <div className="text-white/55">{scene.lightingInstruction}</div>
                    </div>
                  </div>
                )}
              </div>
              {scene.dialogue?.length > 0 && (
                <div className="space-y-3">
                  {scene.dialogue.map((d, j) => (
                    <div key={j} className="bg-black/30 border border-white/5 rounded-lg p-3 font-mono space-y-1">
                      <div className="text-amber-400 text-xs font-bold tracking-widest uppercase">{d.character}</div>
                      {d.parenthetical && <div className="text-white/30 text-xs italic">({d.parenthetical})</div>}
                      <div className="text-white/70 text-sm leading-relaxed">"{d.line}"</div>
                      {d.languageNote && <div className="text-blue-400/50 text-xs">[{d.languageNote}]</div>}
                      {d.deliveryNote && <div className="text-purple-400/50 text-xs italic">{d.deliveryNote}</div>}
                    </div>
                  ))}
                </div>
              )}
              {(scene.lipSyncNote || scene.voiceNote) && (
                <div className="border-t border-white/5 pt-3 space-y-1.5">
                  {scene.lipSyncNote && (
                    <div className="text-xs"><span className="text-green-400/60 font-semibold">LIP SYNC: </span><span className="text-white/40">{scene.lipSyncNote}</span></div>
                  )}
                  {scene.voiceNote && (
                    <div className="text-xs"><span className="text-blue-400/60 font-semibold">VOICE: </span><span className="text-white/40">{scene.voiceNote}</span></div>
                  )}
                </div>
              )}
              {scene.culturalElement && (
                <div className="text-xs text-blue-400/50 italic">🏺 {scene.culturalElement}</div>
              )}
              {scene.transition && (
                <div className="text-right font-mono text-xs text-white/20 uppercase tracking-widest">{scene.transition}</div>
              )}
            </div>
          </div>
        ))}
      </div>
      {screenplay.voiceActingDirections && (
        <div className="border border-white/5 rounded-xl p-4 space-y-2">
          <div className="text-white/25 text-xs uppercase tracking-wide font-semibold flex items-center gap-2">
            <Mic className="w-3 h-3" /> Voice Acting Directions
          </div>
          <p className="text-xs text-white/45 leading-relaxed">{screenplay.voiceActingDirections}</p>
        </div>
      )}
      {screenplay.lipSyncGuidance && (
        <div className="border border-green-500/10 rounded-xl p-4 space-y-2">
          <div className="text-green-400/60 text-xs uppercase tracking-wide font-semibold">Lip Sync Guidance</div>
          <p className="text-xs text-white/45 leading-relaxed">{screenplay.lipSyncGuidance}</p>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Step 3 — Audio Profile Panel
// ---------------------------------------------------------------------------
// Flexible value renderer: handles string, array, object
function FlexValue({ v, depth = 0 }: { v: unknown; depth?: number }) {
  if (v === null || v === undefined) return null;
  if (typeof v === "boolean") return <span className={v ? "text-green-400" : "text-red-400"}>{v ? "Yes" : "No"}</span>;
  if (typeof v === "number") return <span className="text-purple-300 font-mono">{v}</span>;
  if (typeof v === "string") return <span className="text-white/55 leading-relaxed">{v}</span>;
  if (Array.isArray(v)) {
    return (
      <ul className="space-y-1 mt-0.5">
        {v.map((item, i) => (
          <li key={i} className="flex items-start gap-1.5 text-xs">
            <span className="text-purple-400/40 mt-0.5 shrink-0">•</span>
            <FlexValue v={item} depth={depth + 1} />
          </li>
        ))}
      </ul>
    );
  }
  if (typeof v === "object") {
    const entries = Object.entries(v as Record<string, unknown>).filter(([, val]) => val !== null && val !== undefined);
    if (depth >= 2) {
      // Deep nesting: just show as a block
      return (
        <div className="space-y-1">
          {entries.map(([k, val]) => (
            <div key={k} className="text-xs">
              <span className="text-white/25 uppercase tracking-wide mr-1">{k.replace(/_/g, " ")}:</span>
              {typeof val === "string" ? <span className="text-white/50">{val}</span>
                : Array.isArray(val) ? <span className="text-white/40">{(val as string[]).join(", ")}</span>
                : <span className="text-white/40">{String(val)}</span>}
            </div>
          ))}
        </div>
      );
    }
    return (
      <div className="space-y-2">
        {entries.map(([k, val]) => (
          <div key={k}>
            <div className="text-white/25 uppercase tracking-wide text-xs mb-0.5">{k.replace(/_/g, " ")}</div>
            <FlexValue v={val} depth={depth + 1} />
          </div>
        ))}
      </div>
    );
  }
  return null;
}

// Renders a rule-based section with optional rule + implementation/checks/details
function RuleBlock({ label, data }: { label: string; data: unknown }) {
  if (!data || typeof data !== "object") return null;
  const d = data as Record<string, unknown>;
  const rule = d.rule as string | undefined;
  const items: string[] = [
    ...(Array.isArray(d.implementation) ? d.implementation : []),
    ...(Array.isArray(d.checks) ? d.checks : []),
    ...(Array.isArray(d.details) ? d.details : []),
    ...(Array.isArray(d.mitigation) ? d.mitigation : []),
    ...(Array.isArray(d.continuityNotes) ? d.continuityNotes : []),
  ] as string[];
  const avoidList: string[] = Array.isArray(d.avoid) ? d.avoid as string[] : [];
  const highRiskShots: string[] = Array.isArray(d.highRiskShots) ? d.highRiskShots as string[] : [];

  return (
    <div className="border border-white/5 rounded-xl p-4 space-y-2.5">
      <div className="text-xs font-semibold uppercase tracking-widest text-white/40">{label}</div>
      {rule && <p className="text-xs text-white/55 leading-relaxed border-l-2 border-red-400/30 pl-3">{rule}</p>}
      {items.length > 0 && (
        <ul className="space-y-1">
          {items.map((item, i) => (
            <li key={i} className="flex items-start gap-1.5 text-xs text-white/40">
              <CheckCircle2 className="w-3 h-3 text-purple-400/50 mt-0.5 shrink-0" />
              {String(item)}
            </li>
          ))}
        </ul>
      )}
      {avoidList.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {avoidList.map((a, i) => (
            <span key={i} className="text-xs bg-red-500/5 border border-red-500/15 text-red-400/50 rounded px-1.5 py-0.5">✕ {String(a)}</span>
          ))}
        </div>
      )}
      {highRiskShots.length > 0 && (
        <div>
          <div className="text-xs text-amber-400/40 uppercase tracking-wide mb-1">High-Risk Shots</div>
          <ul className="space-y-0.5">
            {highRiskShots.map((s, i) => (
              <li key={i} className="text-xs text-amber-400/50">⚠ {String(s)}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Render Engine Panel — GPU-accelerated parallel scene progress
// ---------------------------------------------------------------------------
type VideoForRender = {
  id: string;
  priority?: string;
  workerType?: string;
  sceneCount?: number;
  scenesCompleted?: number;
  estimatedSeconds?: number | null;
  queuePosition?: number | null;
  progress: number;
  processingStartedAt?: string | null;
};

const PRIORITY_META = {
  enterprise: { label: "Enterprise", color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/25", icon: Rocket, workerLabel: "GPU Cluster · 5 Parallel Streams" },
  paid:       { label: "Paid",       color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/25", icon: Zap,    workerLabel: "GPU Pool · 3 Parallel Streams" },
  free:       { label: "Free",       color: "text-white/50",   bg: "bg-white/5 border-white/10",             icon: Cpu,   workerLabel: "CPU Shared · Sequential" },
};

function RenderEnginePanel({ video }: { video: VideoForRender }) {
  const priorityKey = (video.priority as keyof typeof PRIORITY_META) in PRIORITY_META
    ? (video.priority as keyof typeof PRIORITY_META) : "free";
  const meta = PRIORITY_META[priorityKey];
  const PriorityIcon = meta.icon;
  const isGpu = video.workerType === "gpu";

  // Scene polling: only while rendering
  const { data: scenes = [] } = useGetVideoScenes(video.id, {
    query: {
      queryKey: getGetVideoScenesQueryKey(video.id),
      refetchInterval: video.progress < 100 ? 1500 : false,
      enabled: (video.sceneCount ?? 0) > 0,
    },
  });

  // ETA countdown
  const [eta, setEta] = useState<number | null>(null);
  useEffect(() => {
    if (!video.processingStartedAt || video.progress >= 100) { setEta(null); return; }
    const startMs = new Date(video.processingStartedAt).getTime();
    const elapsed = (Date.now() - startMs) / 1000;
    const estimated = video.estimatedSeconds ?? 30;
    const remaining = Math.max(0, estimated - elapsed);
    setEta(Math.round(remaining));
    const tick = setInterval(() => {
      const el2 = (Date.now() - startMs) / 1000;
      const rem = Math.max(0, estimated - el2);
      setEta(Math.round(rem));
      if (rem <= 0) clearInterval(tick);
    }, 1000);
    return () => clearInterval(tick);
  }, [video.processingStartedAt, video.estimatedSeconds, video.progress]);

  // Active workers (scenes currently rendering)
  const activeScenes = scenes.filter(s => s.status === "rendering");
  const completedScenes = scenes.filter(s => s.status === "completed");

  const inQueue = (video.queuePosition ?? 0) > 0;

  return (
    <div className="space-y-3">
      {/* Header row: priority + worker type */}
      <div className="flex items-center gap-2 flex-wrap">
        <Badge className={`${meta.bg} ${meta.color} border text-xs gap-1.5 px-2.5 py-1`}>
          <PriorityIcon className="w-3 h-3" />
          {meta.label}
        </Badge>
        <Badge className={`border text-xs gap-1.5 px-2.5 py-1 ${isGpu ? "bg-emerald-500/10 border-emerald-500/25 text-emerald-400" : "bg-white/5 border-white/10 text-white/40"}`}>
          {isGpu ? <Activity className="w-3 h-3" /> : <Cpu className="w-3 h-3" />}
          {isGpu ? video.workerType?.toUpperCase() : "CPU"}
        </Badge>
        {!inQueue && eta !== null && eta > 0 && (
          <Badge className="bg-blue-500/10 border-blue-500/20 text-blue-400 border text-xs gap-1.5 px-2.5 py-1">
            <Timer className="w-3 h-3" />~{eta}s remaining
          </Badge>
        )}
        <span className="text-xs text-white/25 ml-auto">{meta.workerLabel}</span>
      </div>

      {/* Queue position banner (free/paid tier waiting) */}
      {inQueue && (
        <div className="flex items-center gap-3 bg-amber-500/5 border border-amber-500/15 rounded-xl px-4 py-3">
          <Clock className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
          <div>
            <div className="text-sm font-medium text-amber-400">In Queue · Position #{video.queuePosition}</div>
            <div className="text-xs text-white/35 mt-0.5">Your render will start shortly. Enterprise jobs are processed first.</div>
          </div>
        </div>
      )}

      {/* Scene grid */}
      {scenes.length > 0 && (
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs text-white/30 mb-2">
            <Layers className="w-3 h-3" />
            <span>Scene-wise Parallel Rendering</span>
            <span className="ml-auto font-mono">{completedScenes.length}/{scenes.length} scenes</span>
          </div>
          {scenes.map((scene) => {
            const isRendering = scene.status === "rendering";
            const isDone = scene.status === "completed";
            const isWaiting = scene.status === "pending" || scene.status === "queued";
            return (
              <div key={scene.id} className={`rounded-lg border px-3 py-2 transition-all ${
                isDone ? "bg-emerald-500/5 border-emerald-500/15"
                  : isRendering ? "bg-blue-500/5 border-blue-500/20"
                  : "bg-white/[0.02] border-white/5"
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  {isDone ? <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                    : isRendering ? <Loader2 className="w-3 h-3 text-blue-400 animate-spin shrink-0" />
                    : <div className="w-3 h-3 rounded-full border border-white/15 shrink-0" />}
                  <span className={`text-xs font-medium flex-1 ${isDone ? "text-emerald-300" : isRendering ? "text-blue-300" : "text-white/30"}`}>
                    {scene.sceneTitle}
                  </span>
                  {scene.workerId && (
                    <span className="text-xs font-mono text-white/20">{scene.workerId}</span>
                  )}
                  <span className={`text-xs font-mono ${isDone ? "text-emerald-400" : isRendering ? "text-blue-400" : "text-white/20"}`}>
                    {scene.progress}%
                  </span>
                </div>
                <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full rounded-full ${isDone ? "bg-emerald-400" : isRendering ? "bg-blue-400" : "bg-white/10"}`}
                    animate={{ width: `${scene.progress}%` }}
                    transition={{ duration: 0.4, ease: "linear" }}
                    style={isRendering ? { boxShadow: "0 0 8px rgba(96,165,250,0.5)" } : {}}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Overall progress bar */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-xs text-white/30">
          <span>Overall Render Progress</span>
          <span className="font-mono text-amber-400">{video.progress}%</span>
        </div>
        <div className="h-2.5 bg-white/5 rounded-full overflow-hidden">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-500"
            animate={{ width: `${video.progress}%` }}
            transition={{ duration: 0.5, ease: "linear" }}
            style={{ boxShadow: "0 0 12px rgba(251,191,36,0.5)" }}
          />
        </div>
      </div>

      {/* Active workers visualization */}
      {activeScenes.length > 0 && (
        <div className="flex items-center gap-2 text-xs text-white/25">
          <Server className="w-3 h-3" />
          <span>{activeScenes.length} worker{activeScenes.length > 1 ? "s" : ""} active</span>
          <div className="flex gap-1 ml-1">
            {activeScenes.map((s) => (
              <div key={s.id} className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Language Card — defined at top level to prevent unmount/remount on re-renders
// ---------------------------------------------------------------------------
type LangItem = {
  id: string; code: string; name: string; nativeName: string; flag: string;
  dialects: number; region: string; priceUsd: number; isDefault: boolean;
  enabled: boolean; purchased?: boolean;
};

function LanguageCard({
  lang, isOwned, isPurchasing, onUnlock,
}: {
  lang: LangItem;
  isOwned: boolean;
  isPurchasing: boolean;
  onUnlock: (id: string, name: string) => void;
}) {
  return (
    <div className={[
      "border rounded-xl p-3 flex flex-col gap-2 transition-all",
      lang.isDefault
        ? "bg-amber-500/5 border-amber-500/20"
        : isOwned
        ? "bg-emerald-500/5 border-emerald-500/15"
        : lang.enabled
        ? "bg-white/[0.03] border-white/5 hover:border-purple-500/20"
        : "bg-white/[0.02] border-white/5 opacity-50",
    ].join(" ")}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-sm">{lang.flag}</span>
            <span className="text-xs font-semibold text-white/80">{lang.name}</span>
          </div>
          <div className="text-xs text-white/30 mt-0.5 truncate">{lang.nativeName}</div>
        </div>
        <Badge className={[
          "text-xs px-1.5 py-0 shrink-0 border-0",
          lang.isDefault ? "bg-amber-500/15 text-amber-400"
            : isOwned ? "bg-emerald-500/15 text-emerald-400"
            : !lang.enabled ? "bg-white/5 text-white/20"
            : "bg-purple-500/10 text-purple-400",
        ].join(" ")}>
          {lang.isDefault ? "Free" : isOwned ? "Active" : !lang.enabled ? "N/A" : `$${lang.priceUsd.toFixed(0)}`}
        </Badge>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-xs text-white/20">{lang.dialects} dialect{lang.dialects > 1 ? "s" : ""}</span>
        {!isOwned && lang.enabled && (
          <button
            aria-label={`Unlock ${lang.name}`}
            onClick={() => onUnlock(lang.id, lang.name)}
            disabled={isPurchasing}
            className="flex items-center gap-1 text-xs bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/20 text-purple-300 rounded-lg px-2.5 py-1 transition-all disabled:opacity-50"
          >
            {isPurchasing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
            {isPurchasing ? "…" : "Unlock"}
          </button>
        )}
        {isOwned && (
          <CheckCircle2 className={`w-3.5 h-3.5 ${lang.isDefault ? "text-amber-400" : "text-emerald-400"}`} />
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Language Engine Tab (live data, purchase system)
// ---------------------------------------------------------------------------
function LanguageEngineTab() {
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";
  const queryClient = useQueryClient();
  const { data: languages, isLoading, error } = useListLanguages();
  const { mutate: purchase, isPending: purchasing, variables: purchasingVars } = usePurchaseLanguage({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListLanguagesQueryKey() });
      },
    },
  });

  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2800);
    return () => clearTimeout(t);
  }, [toast]);

  const handlePurchase = (id: string, name: string) => {
    purchase({ id }, {
      onSuccess: () => setToast({ msg: `${name} unlocked! ✓`, ok: true }),
      onError: () => setToast({ msg: "Purchase failed. Try again.", ok: false }),
    });
  };

  const indianLangs = (languages ?? []).filter(l => l.region === "indian");
  const globalLangs = (languages ?? []).filter(l => l.region === "global");
  const purchasedLangs = (languages ?? []).filter(l => l.purchased !== false);
  const purchasedCount = isSuperAdmin ? (languages?.length ?? 0) : purchasedLangs.length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-5 h-5 text-white/30 animate-spin mr-2" />
        <span className="text-white/30 text-sm">Loading languages…</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-10 text-red-400/60 text-sm">
        <AlertCircle className="w-5 h-5 mx-auto mb-2" />
        Failed to load languages
      </div>
    );
  }


  return (
    <div className="space-y-4">

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium ${toast.ok ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20" : "bg-red-500/15 text-red-400 border border-red-500/20"}`}>
            {toast.ok ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            {toast.msg}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stats bar */}
      <div className="grid grid-cols-3 gap-2 text-center">
        {[
          { label: "Languages", value: `${languages?.length ?? 0}`, color: "text-amber-400" },
          { label: "Unlocked", value: `${purchasedCount}`, color: "text-emerald-400" },
          { label: "Available", value: `${languages?.filter(l => l.enabled).length ?? 0}`, color: "text-purple-400" },
        ].map(s => (
          <div key={s.label} className="bg-black/30 border border-white/5 rounded-xl py-2">
            <div className={`text-base font-bold ${s.color}`}>{s.value}</div>
            <div className="text-xs text-white/25">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Super Admin — all languages banner */}
      {isSuperAdmin && (
        <div className="flex items-center gap-3 bg-amber-500/5 border border-amber-500/20 rounded-xl px-4 py-3">
          <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
          <div className="flex-1">
            <div className="text-xs font-semibold text-amber-300">Super Admin Access</div>
            <div className="text-xs text-white/30">All {languages?.length} languages available for generation</div>
          </div>
          <Badge className="bg-amber-500/15 text-amber-400 border-0 text-xs">Full Access</Badge>
        </div>
      )}

      {/* Multi-generate button */}
      {purchasedCount >= 2 && (
        <button className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/25 rounded-xl text-sm font-medium text-purple-300 hover:border-purple-500/40 hover:from-purple-600/30 hover:to-blue-600/30 transition-all">
          <Languages className="w-4 h-4" />
          {isSuperAdmin ? `Generate in All ${languages?.length} Languages` : `Generate in All ${purchasedCount} Purchased Languages`}
        </button>
      )}

      {/* Indian Languages */}
      {indianLangs.length > 0 && (
        <div className="bg-black/30 border border-white/5 rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/5">
            <span className="text-sm">🇮🇳</span>
            <span className="text-xs font-semibold text-white/60 uppercase tracking-widest">Indian Languages</span>
            <Badge className="ml-auto bg-amber-500/10 text-amber-400 border-0 text-xs">
              {indianLangs.filter(l => isSuperAdmin || l.isDefault || l.purchased).length}/{indianLangs.length} Unlocked
            </Badge>
          </div>
          <div className="p-3 grid grid-cols-2 gap-2">
            {indianLangs.map(lang => (
              <LanguageCard
                key={lang.id}
                lang={lang}
                isOwned={isSuperAdmin || !!lang.isDefault || !!lang.purchased}
                isPurchasing={purchasing && purchasingVars?.id === lang.id}
                onUnlock={handlePurchase}
              />
            ))}
          </div>
        </div>
      )}

      {/* Global Languages */}
      {globalLangs.length > 0 && (
        <div className="bg-black/30 border border-white/5 rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/5">
            <Globe className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-xs font-semibold text-white/60 uppercase tracking-widest">Global Languages</span>
            <Badge className="ml-auto bg-blue-500/10 text-blue-400 border-0 text-xs">
              {globalLangs.filter(l => isSuperAdmin || l.purchased).length}/{globalLangs.length} Unlocked
            </Badge>
          </div>
          <div className="p-3 grid grid-cols-2 gap-2">
            {globalLangs.map(lang => (
              <LanguageCard
                key={lang.id}
                lang={lang}
                isOwned={isSuperAdmin || !!lang.purchased}
                isPurchasing={purchasing && purchasingVars?.id === lang.id}
                onUnlock={handlePurchase}
              />
            ))}
          </div>
        </div>
      )}

      {/* Pronunciation Engine summary (static) */}
      <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
        <div className="flex items-center gap-2 mb-1">
          <SlidersHorizontal className="w-4 h-4 text-purple-400" />
          <span className="text-xs font-semibold text-white/70 uppercase tracking-widest">Pronunciation Engine</span>
        </div>
        <div className="flex items-center gap-3 bg-emerald-500/5 border border-emerald-500/15 rounded-xl p-3">
          <Gauge className="w-7 h-7 text-emerald-400 shrink-0" />
          <div className="flex-1">
            <div className="flex justify-between mb-1">
              <span className="text-xs text-white/50">Naturalness Score</span>
              <span className="text-xs font-bold text-emerald-400">100 / 100</span>
            </div>
            <div className="w-full bg-white/5 rounded-full h-1.5">
              <div className="bg-gradient-to-r from-emerald-500 to-emerald-400 h-1.5 rounded-full w-full" />
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {["Native Accent Simulation", "Zero Robotic Tone", "Context-Aware Pronunciation", "Phoneme Precision"].map(feat => (
            <div key={feat} className="flex items-center gap-1 bg-purple-500/10 border border-purple-500/20 rounded-full px-2.5 py-1">
              <CheckCircle2 className="w-3 h-3 text-purple-400" />
              <span className="text-xs text-purple-300">{feat}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Voice Correction upload */}
      <div className="bg-black/30 border border-white/5 rounded-xl overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/5">
          <Mic className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-xs font-semibold text-white/60 uppercase tracking-widest">Voice Correction Studio</span>
        </div>
        <div className="p-4 space-y-3">
          <div className="border-2 border-dashed border-white/10 rounded-xl p-5 text-center hover:border-purple-500/30 hover:bg-purple-500/5 transition-colors cursor-pointer group">
            <Upload className="w-7 h-7 text-white/20 group-hover:text-purple-400 mx-auto mb-2 transition-colors" />
            <div className="text-xs font-medium text-white/40 group-hover:text-white/60">Upload Voice Sample</div>
            <div className="text-xs text-white/20 mt-0.5">WAV · MP3 · M4A · FLAC</div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {[
              { icon: Waves, label: "Auto Noise Removal" },
              { icon: Sparkles, label: "Clarity Enhancement" },
              { icon: BookOpen, label: "Pronunciation Extract" },
              { icon: Wand2, label: "Natural Blending" },
            ].map(step => (
              <div key={step.label} className="flex items-center gap-2 bg-white/[0.03] border border-white/5 rounded-lg p-2.5">
                <step.icon className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="text-xs text-white/50">{step.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Realism enforcement */}
      <div className="bg-black/30 border border-red-500/10 rounded-xl overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-2.5 border-b border-red-500/10">
          <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
          <span className="text-xs font-semibold text-white/60 uppercase tracking-widest">Pronunciation Realism</span>
          <Badge className="ml-auto bg-red-500/10 text-red-400 border-0 text-xs">Strict</Badge>
        </div>
        <div className="p-3 space-y-2">
          {["Zero Robotic Pronunciation", "No Wrong Accent Tolerance", "Native Human Speaker Standard", "Context-Aware Word Meaning"].map(rule => (
            <div key={rule} className="flex items-center gap-2.5 bg-red-500/5 border border-red-500/10 rounded-lg p-2.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-red-400 shrink-0" />
              <span className="text-xs font-medium text-red-300/80">{rule}</span>
              <Badge className="ml-auto bg-red-500/10 text-red-400 border-0 text-xs py-0">Active</Badge>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}

function AudioProfilePanel({ audio, realism }: { audio: any; realism: any }) {
  const [tab, setTab] = useState<"voice" | "music" | "realism" | "language">("voice");

  // Normalize emotion timeline — GPT uses intensity_0to10 or intensity (0-1)
  const emotionTimeline: any[] = audio?.emotionTimeline ?? [];
  // Normalize voice profiles
  const voiceProfiles: any[] = audio?.voiceProfiles ?? [];
  // Background music — may be flat obj or { cues: [...] }
  const bgMusic = audio?.backgroundMusic ?? null;
  const musicCues: any[] = bgMusic?.cues ?? [];
  // Realism
  const artifactPrev = realism?.artifactPrevention ?? {};
  const artifactKeys = Object.keys(artifactPrev);

  return (
    <div className="space-y-4 mt-4">
      {/* Tab strip */}
      <div className="grid grid-cols-4 gap-1 bg-black/30 p-1 rounded-xl border border-white/5">
        {[
          { id: "voice", icon: Mic, label: "Voice Engine" },
          { id: "music", icon: Music, label: "Music Score" },
          { id: "realism", icon: ShieldCheck, label: "Realism Rules" },
          { id: "language", icon: Languages, label: "Language" },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className={[
              "flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-medium transition-all",
              tab === t.id
                ? "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                : "text-white/30 hover:text-white/60 hover:bg-white/5",
            ].join(" ")}>
            <t.icon className="w-3.5 h-3.5 shrink-0" />
            <span className="hidden sm:inline truncate">{t.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* ── VOICE TAB ── */}
        {tab === "voice" && (
          <motion.div key="voice" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }}
            className="space-y-3">

            {/* Emotion-Audio Timeline */}
            {emotionTimeline.length > 0 && (
              <Collapsible title="Emotion-Audio Timeline" icon={<Waves className="w-3.5 h-3.5" />} defaultOpen accent="text-purple-400">
                <div className="space-y-3">
                  {emotionTimeline.map((beat: any, i: number) => {
                    const rawIntensity = beat.intensity_0to10 ?? beat.intensity ?? 0;
                    // normalize to 0-1
                    const intensity = rawIntensity > 1 ? rawIntensity / 10 : rawIntensity;
                    return (
                      <div key={i} className="border border-white/5 rounded-lg p-3 bg-black/20 space-y-2">
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <div className="flex items-center gap-2">
                            {beat.timeRange && <span className="text-xs font-mono text-white/25">{beat.timeRange}s</span>}
                            {beat.sceneNumber && <span className="text-xs font-mono text-white/25">SC{beat.sceneNumber}</span>}
                            <Badge className="bg-purple-500/10 text-purple-300 border-purple-500/20 text-xs capitalize">
                              {beat.emotion}
                            </Badge>
                          </div>
                          {beat.colorTemperature && <span className="text-xs text-white/20">{beat.colorTemperature}</span>}
                        </div>
                        {intensity > 0 && (
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-white/25 shrink-0 w-14">Intensity</span>
                            <IntensityBar value={intensity} color="bg-purple-400" />
                            <span className="text-xs font-mono text-purple-400 shrink-0">{Math.round(intensity * 100)}%</span>
                          </div>
                        )}
                        {(beat.audioNotes || beat.audioMood || beat.description) && (
                          <p className="text-xs text-white/40 italic leading-relaxed">
                            {beat.audioNotes ?? beat.audioMood ?? beat.description}
                          </p>
                        )}
                        {beat.moment && <p className="text-xs text-white/30">{beat.moment}</p>}
                      </div>
                    );
                  })}
                </div>
              </Collapsible>
            )}

            {/* Character Voice Profiles */}
            {voiceProfiles.length > 0 && (
              <Collapsible title="Character Voice Profiles" icon={<Mic className="w-3.5 h-3.5" />}
                badge={`${voiceProfiles.length}`} defaultOpen accent="text-purple-400">
                <div className="space-y-4">
                  {voiceProfiles.map((vp: any, i: number) => {
                    // Normalize fields — GPT uses nested voiceScience or flat
                    const vs = vp.voiceScience ?? {};
                    const timbre = vp.baseVoiceTone ?? vs.timbre ?? vs.texture ?? "";
                    const cadence = vp.speakingPace ?? vs.cadence ?? "";
                    const breath = vp.breathingPattern ?? vs.breathPattern ?? "";
                    const freqRange: number[] = vs.fundamentalFrequency_Hz_range ?? [];
                    // Emotion modulation — flat object or performanceDirectives
                    const modulation: Record<string, string> = vp.emotionModulation ?? vp.performanceDirectives ?? {};
                    const pauses: string[] = vp.naturalPauses ?? [];
                    // Lip sync criticals
                    const lipSync = vp.lipSyncCriticals ?? null;

                    return (
                      <div key={i} className="border border-purple-500/10 rounded-xl p-4 bg-black/20 space-y-3">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white/90">{vp.character}</span>
                            {vp.age > 0 && <span className="text-xs text-purple-400/60 font-mono">Age {vp.age}</span>}
                            {vp.gender && <Badge variant="outline" className="text-xs border-white/10 text-white/40 capitalize">{vp.gender}</Badge>}
                          </div>
                          {timbre && <Badge className="text-xs bg-purple-500/10 text-purple-300 border-purple-500/20 max-w-[180px] truncate">{timbre}</Badge>}
                        </div>

                        <div className="grid grid-cols-1 gap-2 text-xs">
                          {(vp.language || vp.dialectAccent) && (
                            <div>
                              <div className="text-white/25 uppercase tracking-wide mb-0.5">Language / Accent</div>
                              <div className="text-white/55">{vp.language ?? vp.dialectAccent}</div>
                            </div>
                          )}
                          {cadence && (
                            <div>
                              <div className="text-white/25 uppercase tracking-wide mb-0.5">Cadence</div>
                              <div className="text-white/55">{cadence}</div>
                            </div>
                          )}
                          {breath && (
                            <div>
                              <div className="text-white/25 uppercase tracking-wide mb-0.5">Breathing Pattern</div>
                              <div className="text-white/55">{breath}</div>
                            </div>
                          )}
                        </div>

                        {freqRange.length === 2 && (
                          <div className="flex items-center gap-2 text-xs">
                            <Radio className="w-3 h-3 text-purple-400/50" />
                            <span className="text-white/25">Frequency:</span>
                            <span className="text-purple-300/70 font-mono">{freqRange[0]}–{freqRange[1]} Hz</span>
                          </div>
                        )}

                        {/* Emotion modulation map */}
                        {Object.keys(modulation).length > 0 && (
                          <div>
                            <div className="text-white/25 text-xs uppercase tracking-wide mb-2">Emotion Modulation</div>
                            <div className="space-y-1.5">
                              {Object.entries(modulation).slice(0, 5).map(([emotion, instruction]) => (
                                <div key={emotion} className="flex items-start gap-2 text-xs">
                                  <Badge className="shrink-0 text-xs bg-rose-500/10 text-rose-300 border-rose-500/20 capitalize">{emotion}</Badge>
                                  <span className="text-white/40 leading-tight">{String(instruction)}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Lip sync criticals */}
                        {lipSync && (
                          <div className="border-t border-white/5 pt-2">
                            <div className="text-white/25 text-xs uppercase tracking-wide mb-1.5 flex items-center gap-1">
                              <Zap className="w-3 h-3 text-green-400/50" /> Lip Sync Criticals
                            </div>
                            <FlexValue v={lipSync} depth={1} />
                          </div>
                        )}

                        {/* Natural pauses */}
                        {pauses.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {pauses.map((p: string, j: number) => (
                              <span key={j} className="text-xs bg-white/5 rounded px-1.5 py-0.5 text-white/40 border border-white/5">{p}</span>
                            ))}
                          </div>
                        )}

                        {/* Copyright note */}
                        {vp.copyrightNote && (
                          <div className="text-xs text-green-400/40 flex items-center gap-1 border-t border-white/5 pt-2">
                            <ShieldCheck className="w-3 h-3" />{vp.copyrightNote}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </Collapsible>
            )}

            {/* Mixing + Mastering */}
            {(audio?.mixingDirections || audio?.silenceUsage || audio?.audioMasteringNote) && (
              <Collapsible title="Mixing & Mastering" icon={<Gauge className="w-3.5 h-3.5" />} accent="text-purple-400">
                <div className="space-y-3 text-xs">
                  {[
                    ["Mixing Directions", audio.mixingDirections],
                    ["Silence as Tool", audio.silenceUsage],
                    ["Mastering Note", audio.audioMasteringNote],
                  ].map(([label, val]) => val && (
                    <div key={label as string}>
                      <div className="text-white/25 uppercase tracking-wide mb-1">{label}</div>
                      <p className="text-white/50 leading-relaxed">{val}</p>
                    </div>
                  ))}
                </div>
              </Collapsible>
            )}
          </motion.div>
        )}

        {/* ── MUSIC TAB ── */}
        {tab === "music" && (
          <motion.div key="music" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }}
            className="space-y-3">
            {/* Scene cues layout (cues[] format) */}
            {musicCues.length > 0 ? (
              <>
                <div className="bg-black/40 border border-purple-500/15 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Music className="w-4 h-4 text-purple-400" />
                    <span className="text-white font-semibold text-sm">Cinematic Music Cues</span>
                    <Badge className="ml-auto bg-green-500/10 text-green-300 border-green-500/20 text-xs flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />Royalty-Free
                    </Badge>
                  </div>
                  <p className="text-white/30 text-xs">All music specifications use royalty-free / original compositions only. No licensed tracks.</p>
                </div>
                {musicCues.map((cue: any, i: number) => (
                  <div key={i} className="border border-purple-500/10 rounded-xl p-4 space-y-3 bg-black/20">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        {cue.cueName && <span className="text-white/80 font-medium text-sm">{cue.cueName}</span>}
                        {cue.timeRange && <span className="text-xs font-mono text-white/25">{cue.timeRange}s</span>}
                      </div>
                      {cue.tempoBPM && (
                        <div className="flex items-center gap-1.5">
                          <span className="text-xl font-bold text-purple-400 font-mono">{cue.tempoBPM}</span>
                          <span className="text-white/25 text-xs">BPM</span>
                          {cue.key && <Badge variant="outline" className="text-xs border-purple-500/20 text-purple-300">{cue.key}</Badge>}
                        </div>
                      )}
                    </div>
                    {cue.style && <p className="text-xs text-white/50 leading-relaxed">{cue.style}</p>}
                    {cue.instrumentation?.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {cue.instrumentation.map((inst: string, j: number) => (
                          <span key={j} className="text-xs bg-purple-500/10 border border-purple-500/15 text-purple-300/70 rounded-full px-2.5 py-0.5">{inst}</span>
                        ))}
                      </div>
                    )}
                    {cue.mixNotes && (
                      <div className="text-xs text-white/30 italic border-t border-white/5 pt-2">{cue.mixNotes}</div>
                    )}
                  </div>
                ))}
              </>
            ) : bgMusic ? (
              /* Flat format */
              <div className="space-y-3">
                <div className="bg-black/40 border border-purple-500/15 rounded-xl p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="text-white font-semibold">{bgMusic.primaryGenre ?? bgMusic.genre}</div>
                      <div className="text-purple-400/60 text-xs mt-0.5">{bgMusic.mood}</div>
                    </div>
                    <Badge className="bg-green-500/10 text-green-300 border-green-500/20 text-xs flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />{bgMusic.licenseType ?? "royalty-free"}
                    </Badge>
                  </div>
                  {bgMusic.bpm && (
                    <div className="grid grid-cols-3 gap-3">
                      <div className="text-center bg-white/5 rounded-lg p-3">
                        <div className="text-2xl font-bold text-purple-400 font-mono">{bgMusic.bpm}</div>
                        <div className="text-white/30 uppercase tracking-wide text-xs mt-0.5">BPM</div>
                      </div>
                      <div className="text-center bg-white/5 rounded-lg p-3">
                        <div className="text-lg font-bold text-purple-300 font-mono">{bgMusic.musicalKey ?? bgMusic.key ?? "—"}</div>
                        <div className="text-white/30 uppercase tracking-wide text-xs mt-0.5">Key</div>
                      </div>
                      <div className="text-center bg-white/5 rounded-lg p-3">
                        <div className="text-xs font-medium text-purple-200">{bgMusic.dynamicRange ?? "—"}</div>
                        <div className="text-white/30 uppercase tracking-wide text-xs mt-0.5">Dynamic</div>
                      </div>
                    </div>
                  )}
                </div>
                {bgMusic.instruments?.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {bgMusic.instruments.map((inst: string, i: number) => (
                      <span key={i} className="text-xs bg-purple-500/10 border border-purple-500/20 text-purple-300 rounded-full px-3 py-1">{inst}</span>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-white/25 text-sm">No music data available.</div>
            )}
          </motion.div>
        )}

        {/* ── REALISM TAB ── */}
        {tab === "realism" && (
          <motion.div key="realism" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }}
            className="space-y-3">

            {/* Human Truth */}
            {realism?.humanTruthStatement && (
              <div className="bg-black/40 border border-purple-500/15 rounded-xl p-4">
                <div className="text-xs text-white/25 uppercase tracking-widest mb-2 flex items-center gap-2">
                  <Zap className="w-3.5 h-3.5 text-purple-400" />Visual Human Truth
                </div>
                <p className="italic text-purple-300/70 text-sm leading-relaxed">"{realism.humanTruthStatement}"</p>
              </div>
            )}

            {/* Artifact Prevention — iterates all sub-keys */}
            {artifactKeys.length > 0 && (
              <Collapsible title="Zero-Artifact Enforcement" icon={<ShieldCheck className="w-3.5 h-3.5" />} defaultOpen accent="text-red-400">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-2 bg-red-500/5 border border-red-500/15 rounded-lg mb-3">
                    <CheckCircle2 className="w-3.5 h-3.5 text-red-400 shrink-0" />
                    <span className="text-red-300/80 text-xs font-medium">Zero morphing tolerance — active across all {artifactKeys.length} enforcement domains</span>
                  </div>
                  {artifactKeys.map((key) => (
                    <RuleBlock key={key} label={key.replace(/([A-Z])/g, " $1").trim()} data={artifactPrev[key]} />
                  ))}
                </div>
              </Collapsible>
            )}

            {/* Facial Expressions */}
            {realism?.facialExpressions && (
              <Collapsible title="Facial Expression System" icon={<PersonStanding className="w-3.5 h-3.5" />} accent="text-purple-400">
                <FlexValue v={realism.facialExpressions} depth={0} />
              </Collapsible>
            )}

            {/* Lighting */}
            {realism?.lighting && (
              <Collapsible title="Cinematic Lighting Spec" icon={<SunMedium className="w-3.5 h-3.5" />} accent="text-amber-400">
                {realism.lighting.overall || realism.lighting.shotSpecific ? (
                  <div className="space-y-4">
                    {realism.lighting.overall && (
                      <div>
                        <div className="text-white/25 uppercase tracking-wide text-xs mb-2">Overall</div>
                        <FlexValue v={realism.lighting.overall} depth={0} />
                      </div>
                    )}
                    {realism.lighting.shotSpecific && (
                      <div className="border-t border-white/5 pt-3">
                        <div className="text-white/25 uppercase tracking-wide text-xs mb-2">Shot-Specific</div>
                        <FlexValue v={realism.lighting.shotSpecific} depth={0} />
                      </div>
                    )}
                  </div>
                ) : (
                  <FlexValue v={realism.lighting} depth={0} />
                )}
              </Collapsible>
            )}

            {/* Movement Realism */}
            {realism?.movementRealism && (
              <Collapsible title="Movement & Physics" icon={<PersonStanding className="w-3.5 h-3.5" />} accent="text-blue-400">
                {(realism.movementRealism.body || realism.movementRealism.camera || realism.movementRealism.environment) ? (
                  <div className="space-y-4">
                    {["body", "camera", "environment"].map(key => realism.movementRealism[key] && (
                      <div key={key}>
                        <div className="text-white/25 uppercase tracking-wide text-xs mb-2">{key}</div>
                        <FlexValue v={realism.movementRealism[key]} depth={0} />
                      </div>
                    ))}
                  </div>
                ) : (
                  <FlexValue v={realism.movementRealism} depth={0} />
                )}
              </Collapsible>
            )}

            {/* Skin + Environment */}
            {(realism?.skinTextureDetail || realism?.environmentalism) && (
              <div className="border border-white/5 rounded-xl p-4 space-y-3">
                {realism.skinTextureDetail && (
                  <div className="text-xs">
                    <div className="text-white/25 uppercase tracking-wide mb-1">Skin Texture</div>
                    <p className="text-white/50 leading-relaxed">{realism.skinTextureDetail}</p>
                  </div>
                )}
                {realism.environmentalism && (
                  <div className="text-xs border-t border-white/5 pt-3">
                    <div className="text-white/25 uppercase tracking-wide mb-1">Environment Authenticity</div>
                    <p className="text-white/50 leading-relaxed">{realism.environmentalism}</p>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}

        {/* ── LANGUAGE ENGINE TAB ── */}
        {tab === "language" && (
          <motion.div key="language" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }}>
            <LanguageEngineTab />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Step pill
// ---------------------------------------------------------------------------
function StepPill({
  step, active, done, locked, onClick, loading,
}: {
  step: typeof STEPS[0]; active: boolean; done: boolean; locked: boolean;
  onClick?: () => void; loading?: boolean;
}) {
  const Icon = step.icon;
  return (
    <motion.button
      onClick={!locked ? onClick : undefined}
      disabled={locked || (active && loading)}
      className={[
        "relative flex-1 flex flex-col items-center gap-2 py-4 px-2 rounded-2xl border transition-all duration-300 cursor-pointer select-none",
        done
          ? "border-emerald-500/30 bg-emerald-500/5 hover:bg-emerald-500/10"
          : active
          ? "border-amber-400/40 bg-amber-400/5"
          : locked
          ? "border-white/5 bg-white/2 opacity-40 cursor-not-allowed"
          : "border-white/10 bg-white/3 hover:bg-white/5 hover:border-white/20",
      ].join(" ")}
      whileTap={!locked ? { scale: 0.97 } : {}}
    >
      {active && (
        <motion.div
          className="absolute inset-0 rounded-2xl"
          style={{ boxShadow: `0 0 24px ${step.glow}` }}
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      )}
      {step.auto && (
        <span className="absolute top-2 right-2 text-xs bg-purple-500/20 text-purple-300 border border-purple-500/20 rounded px-1 py-0 leading-4 font-medium">auto</span>
      )}
      <div className={[
        "relative w-9 h-9 rounded-full border-2 flex items-center justify-center text-sm font-bold",
        done
          ? "border-emerald-500 bg-emerald-500/20 text-emerald-400"
          : active
          ? "border-amber-400 bg-amber-400/20 text-amber-400"
          : "border-white/15 bg-white/5 text-white/30",
      ].join(" ")}>
        {done ? (
          <CheckCircle2 className="w-4 h-4" />
        ) : active && loading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : locked ? (
          <Lock className="w-3.5 h-3.5" />
        ) : (
          <Icon className="w-4 h-4" />
        )}
      </div>
      <div className="text-center">
        <div className={[
          "text-xs font-semibold",
          done ? "text-emerald-400" : active ? "text-amber-400" : "text-white/30",
        ].join(" ")}>
          {step.label}
        </div>
        <div className="text-xs text-white/15 mt-0.5 leading-tight">{step.subtitle}</div>
      </div>
    </motion.button>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------
export function GenerationWorkflow({ video: initialVideo }: { video: VideoWithStage }) {
  // Use React Query for authoritative, cache-shared video state (same cache as detail.tsx)
  const { data: liveVideoData } = useGetVideo(initialVideo.id, {
    query: {
      queryKey: getGetVideoQueryKey(initialVideo.id),
      refetchInterval: (q) => {
        const s = (q.state.data as any)?.generationStage;
        // "screenwrote" included because worker auto-advances to "rendering" without user action
        return ["analyzing", "screenwrote", "rendering"].includes(s) ? 4000 : false;
      },
    },
  });

  // Merge live data over initialVideo so we always have the latest stage + render fields
  const liveVideo = liveVideoData as any;
  const video: VideoWithStage = {
    ...initialVideo,
    ...(liveVideo?.generationStage ? {
      generationStage: liveVideo.generationStage as GenerationStage,
      status: liveVideo.status ?? initialVideo.status,
      progress: liveVideo.progress ?? initialVideo.progress,
      priority: liveVideo.priority,
      workerType: liveVideo.workerType,
      sceneCount: liveVideo.sceneCount,
      scenesCompleted: liveVideo.scenesCompleted,
      estimatedSeconds: liveVideo.estimatedSeconds,
      queuePosition: liveVideo.queuePosition,
      processingStartedAt: liveVideo.processingStartedAt,
    } : {}),
  };

  const [analysis, setAnalysis] = useState<AnalysisData | null>(null);
  const [analysisLoading, setAnalysisLoading] = useState(true);
  const [activePanel, setActivePanel] = useState<"analyze" | "screenplay" | "audio" | "generate" | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // Cinema Mode toggle — initialized from live video's cinemaMode, defaults to false
  const [cinemaModeLocal, setCinemaModeLocal] = useState<boolean>(() => !!(liveVideo?.cinemaMode ?? (initialVideo as any).cinemaMode ?? false));
  // Cinema Mode is available for admin / super_admin; locked for regular users
  const { user: authUser } = useAuth();
  const cinemaModeAvailable = authUser?.role === "admin" || authUser?.role === "super_admin";

  // Determine panel to auto-open based on initial stage
  useEffect(() => {
    const s = initialVideo.generationStage;
    if (s === "analyzing") setActivePanel("analyze");
    else if (s === "analyzed") setActivePanel("analyze");
    else if (s === "screenwrote") setActivePanel("audio");
    else if (s === "rendering" || s === "completed") setActivePanel("audio");
  }, []);

  const videoId = initialVideo.id;

  const fetchState = async () => {
    try {
      const data = await customFetch<AnalysisData>(`/api/videos/${videoId}/analysis`);
      setAnalysis(data);
      setAnalysisLoading(false);
      const audioSettled = !data.audioStatus || ["completed", "failed"].includes(data.audioStatus);
      const liveStage = (data as any).generationStage as GenerationStage | undefined;
      const stageSettled = liveStage && ["analyzed", "screenwrote", "completed", "failed"].includes(liveStage);
      if (audioSettled && stageSettled && pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    } catch (err) {
      setAnalysisLoading(false);
      if (err instanceof ApiError && err.status === 404) return;
    }
  };

  useEffect(() => {
    fetchState();
    pollRef.current = setInterval(fetchState, 4000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [videoId]);

  const triggerScreenplay = async () => {
    setActionLoading("screenplay");
    setError(null);
    try {
      // Persist the chosen cinema mode to DB before generating screenplay
      await customFetch<unknown>(`/api/videos/${videoId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cinemaMode: cinemaModeLocal }),
      });
      await customFetch<unknown>(`/api/videos/${videoId}/screenplay`, { method: "POST" });
      setActivePanel("screenplay");
      if (!pollRef.current) pollRef.current = setInterval(fetchState, 4000);
    } catch (err: any) {
      setError(err?.data?.error || "Failed to start screenplay generation");
    } finally {
      setActionLoading(null);
    }
  };

  const triggerGenerate = async () => {
    setActionLoading("generate");
    setError(null);
    try {
      await customFetch<unknown>(`/api/videos/${videoId}/generate`, { method: "POST" });
      setActivePanel("generate");
      // React Query's refetchInterval will pick up the new generationStage automatically
      if (!pollRef.current) pollRef.current = setInterval(fetchState, 4000);
    } catch (err: any) {
      setError(err?.data?.error || "Failed to start rendering");
    } finally {
      setActionLoading(null);
    }
  };

  const retriggerAudio = async () => {
    setError(null);
    try {
      await customFetch<unknown>(`/api/videos/${videoId}/audio-profile`, { method: "POST" });
      setAnalysis(a => a ? { ...a, audioStatus: "generating" } : a);
      if (!pollRef.current) pollRef.current = setInterval(fetchState, 4000);
    } catch (err: any) {
      setError(err?.data?.error || "Failed to regenerate audio profile");
    }
  };

  const stage = video.generationStage;
  const audioStatus = analysis?.audioStatus ?? "pending";
  const audioReady = audioStatus === "completed";

  // Step state logic
  const stepState = (s: typeof STEPS[0]) => {
    if (s.id === "analyze") {
      return {
        done: s.doneStages.includes(stage),
        active: s.activeStages.includes(stage),
        locked: false,
      };
    }
    if (s.id === "screenplay") {
      return {
        done: s.doneStages.includes(stage),
        active: analysis?.screenplayStatus === "generating",
        locked: !["analyzed", "screenwrote", "rendering", "completed"].includes(stage),
      };
    }
    if (s.id === "audio") {
      return {
        done: audioReady && ["screenwrote", "rendering", "completed"].includes(stage),
        active: audioStatus === "generating",
        locked: !["screenwrote", "rendering", "completed"].includes(stage),
      };
    }
    if (s.id === "generate") {
      return {
        done: s.doneStages.includes(stage),
        active: s.activeStages.includes(stage),
        locked: !(stage === "screenwrote" || stage === "rendering" || stage === "completed"),
      };
    }
    return { done: false, active: false, locked: true };
  };

  return (
    <div className="space-y-6">
      {/* Step pills */}
      <div className="grid grid-cols-4 gap-2 sm:gap-3">
        {STEPS.map((step) => {
          const ss = stepState(step);
          return (
            <StepPill
              key={step.id}
              step={step}
              {...ss}
              loading={actionLoading === step.id || ss.active}
              onClick={() => setActivePanel(step.id as any)}
            />
          );
        })}
      </div>

      {/* Priority + GPU tier indicator — always visible */}
      {video.priority && (
        <div className="flex items-center gap-2 flex-wrap">
          {video.priority === "enterprise" && (
            <Badge className="bg-amber-500/10 border-amber-500/25 text-amber-400 border text-xs gap-1.5 px-2.5 py-1">
              <Rocket className="w-3 h-3" />Enterprise Priority
            </Badge>
          )}
          {video.priority === "paid" && (
            <Badge className="bg-purple-500/10 border-purple-500/25 text-purple-400 border text-xs gap-1.5 px-2.5 py-1">
              <Zap className="w-3 h-3" />Paid Priority
            </Badge>
          )}
          {video.priority === "free" && (
            <Badge className="bg-white/5 border-white/10 text-white/40 border text-xs gap-1.5 px-2.5 py-1">
              <Cpu className="w-3 h-3" />Free Tier
            </Badge>
          )}
          {video.workerType === "gpu" && (
            <Badge className="bg-emerald-500/10 border-emerald-500/25 text-emerald-400 border text-xs gap-1.5 px-2.5 py-1">
              <Activity className="w-3 h-3" />GPU Accelerated
            </Badge>
          )}
          {video.priority === "enterprise" && (
            <span className="text-xs text-white/25 ml-auto">5 parallel streams · GPU-H100 cluster</span>
          )}
          {video.priority === "paid" && (
            <span className="text-xs text-white/25 ml-auto">3 parallel streams · GPU-A100 pool</span>
          )}
          {video.priority === "free" && (
            <span className="text-xs text-white/25 ml-auto">Sequential · CPU shared</span>
          )}
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg px-4 py-3">
          <AlertCircle className="w-4 h-4 shrink-0" />{error}
        </div>
      )}

      {/* Mode selector + Action buttons */}
      {stage === "analyzed" && (
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          {/* Mode radio */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-widest text-white/30 px-1">Mode</span>
            <div className="flex items-stretch gap-1 p-1 bg-background/60 border border-white/10 rounded-xl">
              {/* Default option */}
              <button
                type="button"
                onClick={() => setCinemaModeLocal(false)}
                className={cn(
                  "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all",
                  !cinemaModeLocal
                    ? "bg-white/10 text-white shadow-sm"
                    : "text-white/40 hover:text-white/60"
                )}
              >
                <span className={cn(
                  "w-2 h-2 rounded-full border-2 flex-shrink-0 transition-colors",
                  !cinemaModeLocal ? "border-white bg-white" : "border-white/25"
                )} />
                <span>Default</span>
                <span className="text-[10px] font-normal text-white/30">Up to 4K</span>
              </button>

              {/* Cinema option */}
              <button
                type="button"
                onClick={() => cinemaModeAvailable && setCinemaModeLocal(true)}
                disabled={!cinemaModeAvailable}
                title={!cinemaModeAvailable ? "Upgrade to unlock Cinema Mode (4K–8K)" : undefined}
                className={cn(
                  "relative flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all",
                  cinemaModeAvailable
                    ? cinemaModeLocal
                      ? "bg-primary/20 text-primary shadow-sm"
                      : "text-white/40 hover:text-white/60 cursor-pointer"
                    : "text-white/20 cursor-not-allowed"
                )}
              >
                <span className={cn(
                  "w-2 h-2 rounded-full border-2 flex-shrink-0 transition-colors",
                  cinemaModeAvailable && cinemaModeLocal
                    ? "border-primary bg-primary"
                    : "border-white/25"
                )} />
                <Clapperboard className="w-3.5 h-3.5 flex-shrink-0" />
                <span>Cinema</span>
                <span className={cn("text-[10px] font-normal", cinemaModeAvailable ? "text-white/30" : "text-white/20")}>
                  4K–8K
                </span>
                {/* Lock / Available badge */}
                {!cinemaModeAvailable ? (
                  <span className="ml-0.5 flex items-center gap-0.5 text-[10px] font-bold text-amber-500/70 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded-full">
                    <Lock className="w-2.5 h-2.5" />
                    Locked
                  </span>
                ) : (
                  <span className="ml-0.5 flex items-center gap-0.5 text-[10px] font-bold text-emerald-400 bg-emerald-400/10 border border-emerald-500/20 px-1.5 py-0.5 rounded-full">
                    <CheckCircle2 className="w-2.5 h-2.5" />
                    Available
                  </span>
                )}
              </button>
            </div>
            {!cinemaModeAvailable && (
              <p className="text-[11px] text-amber-500/60 px-1">
                Cinema Mode (4K–8K) requires a Pro plan.
              </p>
            )}
          </div>

          <Button onClick={triggerScreenplay} disabled={actionLoading === "screenplay"}
            className={cn(
              "self-end sm:self-auto gap-2 text-white",
              cinemaModeLocal && cinemaModeAvailable
                ? "bg-primary hover:bg-primary/90 text-black shadow-[0_0_20px_rgba(234,179,8,0.35)]"
                : "bg-blue-600 hover:bg-blue-500 shadow-[0_0_20px_rgba(96,165,250,0.3)]"
            )}>
            {actionLoading === "screenplay"
              ? <><Loader2 className="w-4 h-4 animate-spin" />Writing Screenplay...</>
              : cinemaModeLocal && cinemaModeAvailable
                ? <><Clapperboard className="w-4 h-4" />Write Screenplay</>
                : <><FileText className="w-4 h-4" />Write Screenplay</>
            }
          </Button>
        </div>
      )}

      <div className="flex flex-wrap gap-3">
        {stage === "analyzed" && null /* handled above */}

        {stage === "screenwrote" && (
          <Button onClick={triggerGenerate} disabled={actionLoading === "generate"}
            className="bg-green-600 hover:bg-green-500 text-white gap-2 shadow-[0_0_20px_rgba(74,222,128,0.3)]">
            {actionLoading === "generate"
              ? <><Loader2 className="w-4 h-4 animate-spin" />Queuing Render...</>
              : <><Play className="w-4 h-4" />Generate Video</>}
          </Button>
        )}

        {/* Audio retry button */}
        {["screenwrote", "rendering", "completed"].includes(stage) && audioStatus === "failed" && (
          <Button variant="outline" size="sm" onClick={retriggerAudio}
            className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10 gap-1.5">
            <RefreshCw className="w-3.5 h-3.5" />Regenerate Audio Profile
          </Button>
        )}

        {/* Re-analyze */}
        {["analyzed", "screenwrote"].includes(stage) && (
          <Button variant="outline" size="sm"
            className="border-white/10 text-white/50 text-xs gap-1.5"
            onClick={async () => {
              await customFetch<unknown>(`/api/videos/${videoId}/analysis/trigger`, { method: "POST" });
              setAnalysis(null);
              setAnalysisLoading(true);
              setActivePanel("analyze");
              if (!pollRef.current) pollRef.current = setInterval(fetchState, 4000);
            }}>
            <RefreshCw className="w-3.5 h-3.5" />Re-analyze
          </Button>
        )}
      </div>

      {/* Render progress when generating */}
      {(stage === "rendering" || stage === "completed") && (
        <Card className={stage === "completed" ? "bg-emerald-500/5 border-emerald-500/20" : "bg-black/40 border-white/5"}>
          <CardContent className="pt-5 pb-5">
            {stage === "rendering" ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
                  <span className="font-semibold text-white/80">Rendering your cinematic vision...</span>
                </div>
                <RenderEnginePanel video={video} />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  <div>
                    <div className="font-semibold text-emerald-400">Video Ready</div>
                    <div className="text-xs text-white/40 mt-0.5">Your cinematic video has been generated successfully.</div>
                  </div>
                </div>
                <RenderEnginePanel video={video} />
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Content panels */}
      <AnimatePresence mode="wait">
        {activePanel === "analyze" && (
          <motion.div key="analyze" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
            <Card className="bg-black/30 border-amber-400/10">
              <CardHeader className="border-b border-white/5 pb-4">
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 text-amber-400" />
                  <span className="font-semibold text-sm text-white/70">Deep Story Analysis</span>
                  {analysis?.status === "completed" && (
                    <Badge className="ml-auto bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">Complete</Badge>
                  )}
                  {(stage === "analyzing" || analysis?.status === "analyzing") && (
                    <Badge className="ml-auto bg-amber-400/10 text-amber-400 border-amber-400/20 text-xs">Analyzing</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                {stage === "analyzing" || analysis?.status === "analyzing" ? (
                  <ThinkingAnimation messages={THINKING} />
                ) : analysis?.status === "completed" ? (
                  <AnalysisResults data={analysis} />
                ) : null}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {activePanel === "screenplay" && (
          <motion.div key="screenplay" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
            <Card className="bg-black/30 border-blue-400/10">
              <CardHeader className="border-b border-white/5 pb-4">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-400" />
                  <span className="font-semibold text-sm text-white/70">Cinematic Screenplay</span>
                  {analysis?.screenplayStatus === "completed" && (
                    <Badge className="ml-auto bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">Complete</Badge>
                  )}
                  {analysis?.screenplayStatus === "generating" && (
                    <Badge className="ml-auto bg-blue-400/10 text-blue-400 border-blue-400/20 text-xs animate-pulse">Writing</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                {analysis?.screenplayStatus === "generating" ? (
                  <ThinkingAnimation messages={SCREENPLAY_THINKING} icon={FileText} color="text-blue-400" glow="rgba(96,165,250,0.3)" />
                ) : analysis?.screenplay ? (
                  <ScreenplayDisplay screenplay={analysis.screenplay as ScreenplayData} />
                ) : (
                  <div className="text-center py-10 text-white/30 text-sm">Screenplay will appear here once generated.</div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {activePanel === "audio" && (
          <motion.div key="audio" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
            <Card className="bg-black/30 border-purple-400/10">
              <CardHeader className="border-b border-white/5 pb-4">
                <div className="flex items-center gap-2">
                  <Headphones className="w-4 h-4 text-purple-400" />
                  <span className="font-semibold text-sm text-white/70">Audio &amp; Realism System</span>
                  {!analysisLoading && audioStatus === "completed" && (
                    <Badge className="ml-auto bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">Active</Badge>
                  )}
                  {audioStatus === "generating" && (
                    <Badge className="ml-auto bg-purple-400/10 text-purple-400 border-purple-400/20 text-xs animate-pulse">Generating</Badge>
                  )}
                  {!analysisLoading && audioStatus === "failed" && (
                    <Badge className="ml-auto bg-red-500/10 text-red-400 border-red-500/20 text-xs">Failed</Badge>
                  )}
                  {analysisLoading && (
                    <Badge className="ml-auto bg-white/5 text-white/30 border-white/10 text-xs flex items-center gap-1">
                      <Loader2 className="w-3 h-3 animate-spin" />Loading
                    </Badge>
                  )}
                  {!analysisLoading && audioStatus === "pending" && stage === "screenwrote" && (
                    <Badge className="ml-auto bg-purple-400/10 text-purple-300 border-purple-400/20 text-xs animate-pulse">Starting…</Badge>
                  )}
                  {!analysisLoading && audioStatus === "pending" && !["screenwrote", "rendering", "completed"].includes(stage) && (
                    <Badge className="ml-auto bg-white/5 text-white/30 border-white/10 text-xs">Awaiting Screenplay</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                {analysisLoading ? (
                  <div className="flex items-center justify-center py-10 gap-3 text-white/30">
                    <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
                    <span className="text-sm">Loading audio profile…</span>
                  </div>
                ) : audioStatus === "generating" ? (
                  <ThinkingAnimation messages={AUDIO_THINKING} icon={Headphones} color="text-purple-400" glow="rgba(192,132,252,0.3)" />
                ) : audioStatus === "completed" && analysis?.audioProfile && analysis?.realismProfile ? (
                  <AudioProfilePanel
                    audio={analysis.audioProfile as AudioProfile}
                    realism={analysis.realismProfile as RealismProfile}
                  />
                ) : audioStatus === "failed" ? (
                  <div className="text-center py-10 space-y-4">
                    <AlertCircle className="w-10 h-10 text-destructive mx-auto" />
                    <p className="text-white/40 text-sm">Audio profile generation failed. Click "Regenerate" above to retry.</p>
                  </div>
                ) : audioStatus === "pending" && ["screenwrote", "rendering", "completed"].includes(stage) ? (
                  <ThinkingAnimation messages={AUDIO_THINKING} icon={Headphones} color="text-purple-400" glow="rgba(192,132,252,0.3)" />
                ) : (
                  <div className="text-center py-10 space-y-3">
                    <Headphones className="w-10 h-10 text-purple-400/30 mx-auto" />
                    <div className="text-white/30 text-sm">Audio &amp; Realism profile will generate automatically after screenplay is complete.</div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {activePanel === "generate" && stage !== "rendering" && stage !== "completed" && (
          <motion.div key="generate" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
            <Card className="bg-black/30 border-green-400/10">
              <CardContent className="py-10 text-center space-y-3">
                <Video className="w-10 h-10 text-green-400 mx-auto" />
                <div className="text-white/60 font-semibold">Ready to Render</div>
                <div className="text-white/30 text-sm max-w-md mx-auto">
                  Screenplay and audio profile are approved. Click <strong>"Generate Video"</strong> above to start the full pipeline.
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
