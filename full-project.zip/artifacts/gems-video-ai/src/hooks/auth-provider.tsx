import { createContext, useContext, useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useGetMe, useLogin, useLogout, useRegister, getGetMeQueryKey } from "@workspace/api-client-react";
import type { LoginBody, RegisterBody, User } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";

export interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (data: LoginBody) => Promise<void>;
  register: (data: RegisterBody) => Promise<void>;
  logout: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const token = typeof window !== "undefined" ? localStorage.getItem("gems_token") : null;
  const hasToken = !!token;

  const { data: user, isLoading: isUserLoading, error, refetch } = useGetMe({
    query: {
      queryKey: getGetMeQueryKey(),
      enabled: hasToken,
      retry: false,
    },
  });

  const loginMutation = useLogin();
  const registerMutation = useRegister();
  const logoutMutation = useLogout();

  useEffect(() => {
    if (error && hasToken) {
      localStorage.removeItem("gems_token");
      setLocation("/login");
    }
  }, [error, hasToken, setLocation]);

  const login = async (data: LoginBody) => {
    try {
      const result = await loginMutation.mutateAsync({ data });
      localStorage.setItem("gems_token", result.token);
      await refetch();
      setLocation("/dashboard");
    } catch (err: any) {
      toast({
        title: "Login failed",
        description: err?.message || "Invalid credentials",
        variant: "destructive",
      });
      throw err;
    }
  };

  const register = async (data: RegisterBody) => {
    try {
      const result = await registerMutation.mutateAsync({ data });
      localStorage.setItem("gems_token", result.token);
      await refetch();
      setLocation("/dashboard");
    } catch (err: any) {
      toast({
        title: "Registration failed",
        description: err?.message || "Could not create account",
        variant: "destructive",
      });
      throw err;
    }
  };

  const logout = async () => {
    try {
      if (hasToken) {
        await logoutMutation.mutateAsync();
      }
    } catch {
      // ignore logout errors — token will be cleared regardless
    } finally {
      localStorage.removeItem("gems_token");
      setLocation("/");
      window.location.reload();
    }
  };

  const isLoading = isUserLoading && hasToken;

  return (
    <AuthContext.Provider value={{ user: user || null, isLoading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
