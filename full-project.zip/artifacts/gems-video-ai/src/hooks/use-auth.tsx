import { useContext } from "react";
import { AuthContext } from "@/hooks/auth-provider";
import type { AuthContextType } from "@/hooks/auth-provider";

export type { AuthContextType };
export { AuthContext };

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
