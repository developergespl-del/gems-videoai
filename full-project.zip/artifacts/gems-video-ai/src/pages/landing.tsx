import { Link } from "wouter";
import { motion } from "framer-motion";
import { Film, Play, Sparkles, Zap, ArrowRight, Video, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";

export function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground overflow-hidden">
      {/* Navigation */}
      <header className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2 text-primary font-display font-bold text-2xl tracking-tight">
            <Film className="w-8 h-8" />
            <span>GEMS</span>
          </div>
          <nav className="flex items-center gap-6">
            <Link href="/login" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Sign In
            </Link>
            <Link href="/register" className="block">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-6">
                Start Creating
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-6">
        {/* Cinematic background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-sm font-medium mb-8">
              <Sparkles className="w-4 h-4" />
              <span>GEMS Video AI 2.0 is live</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold tracking-tight mb-8 text-white">
              Direct the <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-amber-200">impossible.</span>
            </h1>
            
            <p className="text-lg md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12 leading-relaxed">
              The elite AI video generation studio for filmmakers. Transform scripts, stories, and raw concepts into cinematic reality with zero AI feel.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/register" className="block w-full sm:w-auto">
                <Button size="lg" className="w-full h-14 px-8 text-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_40px_-10px_rgba(234,179,8,0.5)]">
                  Enter the Studio
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="#demo" className="block w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full h-14 px-8 text-lg border-white/10 hover:bg-white/5">
                  <Play className="mr-2 w-5 h-5" />
                  Watch Showreel
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="demo" className="py-24 bg-zinc-950 px-6 border-y border-white/5 relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Precision Control.</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Everything you need to orchestrate a masterpiece.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Video,
                title: "Cinematic Fidelity",
                desc: "Outputs in 4K resolution with photorealistic textures, true-to-life physics, and professional color grading out of the box."
              },
              {
                icon: Zap,
                title: "Real-time Rendering",
                desc: "Our custom pipeline generates high-complexity scenes in minutes, not hours. Keep your creative momentum alive."
              },
              {
                icon: LayoutDashboard,
                title: "Studio Workspace",
                desc: "Organize by project, manage assets, and track rendering statuses in a dashboard designed for professional workflows."
              }
            ].map((feat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="p-8 rounded-2xl bg-zinc-900 border border-white/5 hover:border-primary/30 transition-colors group"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                  <feat.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feat.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feat.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-12 border-t border-white/5 text-center text-muted-foreground">
        <div className="max-w-7xl mx-auto px-6 flex flex-col items-center">
          <Film className="w-8 h-8 text-primary mb-6 opacity-50" />
          <p>© {new Date().getFullYear()} GEMS Video AI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
