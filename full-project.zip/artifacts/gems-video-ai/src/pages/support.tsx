import { useGetPlatformSettings, getGetPlatformSettingsQueryKey } from "@workspace/api-client-react";
import { MessageCircle, Mail, LifeBuoy, ExternalLink, Phone } from "lucide-react";

export function SupportPage() {
  const { data: settings, isLoading } = useGetPlatformSettings({
    query: { queryKey: getGetPlatformSettingsQueryKey(), staleTime: 30000 },
  });

  const hasWhatsapp = settings?.supportWhatsapp && settings.supportWhatsapp.trim() !== "";
  const hasEmail = settings?.supportEmail && settings.supportEmail.trim() !== "";
  const hasAnyContact = hasWhatsapp || hasEmail;

  return (
    <div className="max-w-2xl mx-auto py-10 px-4 space-y-8">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
          <LifeBuoy className="w-5 h-5 text-amber-400" />
        </div>
        <div>
          <h1 className="text-2xl font-display font-bold text-white">Support</h1>
          <p className="text-sm text-white/50">Kisi bhi sawaal ke liye humse contact karein</p>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <div key={i} className="h-24 rounded-xl bg-white/5 animate-pulse" />
          ))}
        </div>
      ) : hasAnyContact ? (
        <div className="space-y-4">
          {hasWhatsapp && (
            <a
              href={`https://wa.me/${settings!.supportWhatsapp!.replace(/[^0-9]/g, "")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-5 rounded-xl bg-green-500/10 border border-green-500/20 hover:bg-green-500/15 hover:border-green-500/30 transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center shrink-0">
                <MessageCircle className="w-6 h-6 text-green-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-green-400/80 font-medium mb-0.5">WhatsApp</p>
                <p className="text-white font-semibold text-lg truncate">{settings!.supportWhatsapp}</p>
                <p className="text-white/40 text-xs mt-0.5">Click karein WhatsApp pe message karne ke liye</p>
              </div>
              <ExternalLink className="w-4 h-4 text-green-400/50 group-hover:text-green-400 transition-colors shrink-0" />
            </a>
          )}

          {hasEmail && (
            <a
              href={`mailto:${settings!.supportEmail}`}
              className="flex items-center gap-4 p-5 rounded-xl bg-blue-500/10 border border-blue-500/20 hover:bg-blue-500/15 hover:border-blue-500/30 transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center shrink-0">
                <Mail className="w-6 h-6 text-blue-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-blue-400/80 font-medium mb-0.5">Email</p>
                <p className="text-white font-semibold text-lg truncate">{settings!.supportEmail}</p>
                <p className="text-white/40 text-xs mt-0.5">Email karein apni query ke saath</p>
              </div>
              <ExternalLink className="w-4 h-4 text-blue-400/50 group-hover:text-blue-400 transition-colors shrink-0" />
            </a>
          )}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 gap-4 text-center">
          <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
            <Phone className="w-8 h-8 text-white/20" />
          </div>
          <div>
            <p className="text-white/60 font-medium">Support contact abhi set nahi hai</p>
            <p className="text-white/30 text-sm mt-1">Admin se request karein contact details add karne ke liye</p>
          </div>
        </div>
      )}

      {/* Info card */}
      <div className="rounded-xl bg-white/3 border border-white/5 p-4 text-sm text-white/40 leading-relaxed">
        <p className="font-medium text-white/60 mb-1">Response Time</p>
        <p>Hum generally 24–48 ghante mein reply karte hain. WhatsApp pe jaldi response milta hai.</p>
      </div>
    </div>
  );
}
