import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  useAnalyzeScriptSounds,
  useListMySoundAnalyses,
  useGetSoundAnalysis,
  getListMySoundAnalysesQueryKey,
  getGetSoundAnalysisQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  AudioLines,
  Volume2,
  CheckCircle2,
  Sparkles,
  Plus,
  Loader2,
  ExternalLink,
  Wand2,
  Film,
  ShieldCheck,
} from "lucide-react";

export function SoundDesignPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [scriptText, setScriptText] = useState("");
  const [result, setResult] = useState<any>(null);

  const { data: history } = useListMySoundAnalyses({
    query: { queryKey: getListMySoundAnalysesQueryKey() },
  });

  const recent = (history as any[]) ?? [];
  const latestId: string | undefined = !result && recent.length > 0 ? recent[0].id : undefined;
  const { data: latestDetail } = useGetSoundAnalysis(latestId ?? "", {
    query: {
      queryKey: latestId ? getGetSoundAnalysisQueryKey(latestId) : ["sound-analysis", "skip"],
      enabled: !!latestId,
    },
  });
  const displayed: any = result ?? latestDetail ?? null;

  const analyzeMutation = useAnalyzeScriptSounds({
    mutation: {
      onSuccess: (data) => {
        setResult(data);
        queryClient.invalidateQueries({ queryKey: getListMySoundAnalysesQueryKey() });
        toast({
          title: "Sound design analysis complete",
          description: `${(data as any).totalDetected ?? 0} detected · ${(data as any).totalReplaced ?? 0} replaced · ${(data as any).totalAdded ?? 0} added`,
        });
      },
      onError: (e: any) => toast({
        title: "Analysis failed",
        description: e?.response?.data?.error || e.message,
        variant: "destructive",
      }),
    },
  });

  const onAnalyze = () => {
    if (scriptText.trim().length === 0) return;
    analyzeMutation.mutate({ data: { scriptText, persistResults: true } });
  };

  const decisions = (displayed?.decisions as any[]) ?? [];
  const grouped = decisions.reduce<Record<number, any[]>>((acc, d) => {
    (acc[d.sceneIndex] ??= []).push(d);
    return acc;
  }, {});

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-12 h-12 rounded-xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center">
          <AudioLines className="w-6 h-6 text-yellow-400" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold">Cinematic Sound Design</h1>
          <p className="text-sm text-zinc-400">AI validates every sound cue and auto-replaces weak/generic prompts with cinematic copyright-free alternatives.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 my-6">
        <Card className="bg-background/40 border-white/10">
          <CardContent className="p-4 flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <div className="text-sm font-medium">Validates Every Sound</div>
              <div className="text-xs text-zinc-500">Emotion · Environment · Timing · Intensity</div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-background/40 border-white/10">
          <CardContent className="p-4 flex items-center gap-3">
            <Wand2 className="w-5 h-5 text-blue-400" />
            <div>
              <div className="text-sm font-medium">Auto Cinematic Replacements</div>
              <div className="text-xs text-zinc-500">Weak prompt → layered, professional sound</div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-background/40 border-white/10">
          <CardContent className="p-4 flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-pink-400" />
            <div>
              <div className="text-sm font-medium">Smart Ambient Layering</div>
              <div className="text-xs text-zinc-500">Adds missing wind, footsteps, room tone</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-background/40 border-white/10 mb-6">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2"><Film className="w-4 h-4" />Paste your script</CardTitle>
          <CardDescription>Include your sound prompts inline (e.g. "thunder sound", "sad violin"). The AI will validate, replace, and add ambient cues.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea
            value={scriptText}
            onChange={(e) => setScriptText(e.target.value)}
            placeholder={`Scene 1: A dark stormy night in the village. (thunder sound) The old door creaks open as Maya steps inside.\n\nScene 2: She finds an old letter on the desk. Sad violin music plays as she begins to read.\n\nScene 3: Suddenly, a loud crash from outside! She runs to the window.`}
            className="min-h-[200px] bg-background/50 font-mono text-sm"
            data-testid="script-input"
          />
          <div className="flex items-center justify-between gap-3">
            <div className="text-xs text-zinc-500">{scriptText.trim().length} chars</div>
            <Button
              onClick={onAnalyze}
              disabled={analyzeMutation.isPending || scriptText.trim().length === 0}
              className="bg-yellow-500 hover:bg-yellow-400 text-black"
              data-testid="analyze-btn"
            >
              {analyzeMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing...</>
              ) : (
                <><Wand2 className="w-4 h-4 mr-2" />Analyze Sounds</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {displayed && (
        <div className="space-y-4" data-testid="analysis-result">
          {!result && latestDetail && (
            <div className="text-xs text-zinc-500">Showing your most recent analysis. Run a new one above to update.</div>
          )}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <SmallStat label="Detected" value={displayed.totalDetected} icon={<Volume2 className="w-4 h-4" />} />
            <SmallStat label="Kept" value={displayed.totalKept} icon={<CheckCircle2 className="w-4 h-4 text-emerald-400" />} />
            <SmallStat label="Replaced" value={displayed.totalReplaced} icon={<Wand2 className="w-4 h-4 text-yellow-400" />} />
            <SmallStat label="Added" value={displayed.totalAdded} icon={<Plus className="w-4 h-4 text-pink-400" />} />
          </div>
          {displayed.summary && (
            <Card className="bg-background/40 border-white/10">
              <CardContent className="p-4 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-yellow-400 mt-0.5" />
                <div className="text-sm text-zinc-300">{displayed.summary}</div>
              </CardContent>
            </Card>
          )}

          {Object.keys(grouped).length === 0 ? (
            <Card className="bg-background/40 border-white/10">
              <CardContent className="p-10 text-center text-zinc-400">
                <AudioLines className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p>No sound cues detected and no ambient additions suggested for this script.</p>
              </CardContent>
            </Card>
          ) : (
            Object.keys(grouped)
              .map(Number)
              .sort((a, b) => a - b)
              .map((sceneIdx) => (
                <Card key={sceneIdx} className="bg-background/40 border-white/10">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Scene {sceneIdx + 1}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {grouped[sceneIdx].map((d: any, i: number) => (
                      <DecisionCard key={i} decision={d} />
                    ))}
                  </CardContent>
                </Card>
              ))
          )}
        </div>
      )}

      {recent.length > 0 && (
        <Card className="bg-background/40 border-white/10 mt-8">
          <CardHeader>
            <CardTitle className="text-sm">Your recent analyses</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {recent.slice(0, 8).map((a: any) => (
              <div key={a.id} className="flex items-center justify-between text-xs border-b border-white/5 pb-2 last:border-0">
                <div className="flex items-center gap-2">
                  <AudioLines className="w-3.5 h-3.5 text-zinc-500" />
                  <span className="text-zinc-400">{new Date(a.createdAt).toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{a.totalDetected} detected</Badge>
                  <Badge variant="outline" className="text-emerald-300 border-emerald-500/30">{a.totalKept} kept</Badge>
                  <Badge variant="outline" className="text-yellow-300 border-yellow-500/30">{a.totalReplaced} replaced</Badge>
                  <Badge variant="outline" className="text-pink-300 border-pink-500/30">{a.totalAdded} added</Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function SmallStat({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <Card className="bg-background/40 border-white/10">
      <CardContent className="p-3 flex items-center justify-between">
        <div>
          <div className="text-xs text-zinc-400">{label}</div>
          <div className="text-2xl font-bold">{value ?? 0}</div>
        </div>
        {icon}
      </CardContent>
    </Card>
  );
}

function DecisionCard({ decision }: { decision: any }) {
  const colorClass =
    decision.decision === "kept" ? "border-emerald-500/30 bg-emerald-500/5" :
    decision.decision === "replaced" ? "border-yellow-500/30 bg-yellow-500/5" :
    "border-pink-500/30 bg-pink-500/5";
  const labelText =
    decision.decision === "kept" ? "KEPT" :
    decision.decision === "replaced" ? "REPLACED" : "ADDED";
  const labelColor =
    decision.decision === "kept" ? "text-emerald-300" :
    decision.decision === "replaced" ? "text-yellow-300" : "text-pink-300";

  return (
    <div className={`rounded-lg border p-3 ${colorClass}`} data-testid={`decision-${decision.decision}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className={`text-[10px] font-semibold tracking-wider mb-1 ${labelColor}`}>{labelText}</div>
          {decision.originalPrompt && (
            <div className="text-sm font-mono mb-1 text-zinc-300">"{decision.originalPrompt}"</div>
          )}
          <div className="flex flex-wrap gap-1 mb-1.5">
            {decision.detectedCategory && <Badge variant="outline" className="text-[10px]">{decision.detectedCategory}</Badge>}
            {decision.sceneEmotion && <Badge variant="outline" className="text-[10px]">emotion: {decision.sceneEmotion}</Badge>}
            {decision.sceneEnvironment && <Badge variant="outline" className="text-[10px]">env: {decision.sceneEnvironment}</Badge>}
            {decision.sceneIntensity && <Badge variant="outline" className="text-[10px]">intensity: {decision.sceneIntensity}</Badge>}
          </div>
          <p className="text-xs text-zinc-400">{decision.reason}</p>
          {decision.suggestedDescription && (
            <div className="mt-2 p-2 rounded bg-black/30 border border-white/5">
              <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Suggested cinematic sound</div>
              <div className="text-xs text-zinc-200">{decision.suggestedDescription}</div>
            </div>
          )}
          {decision.replacementSound && (
            <div className="mt-2 p-2 rounded bg-black/30 border border-emerald-500/20">
              <div className="text-[10px] uppercase tracking-wider text-emerald-400 mb-1 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />Matched library sound
              </div>
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-xs text-zinc-200 font-medium">{decision.replacementSound.name}</div>
                  <div className="text-[10px] text-zinc-500">{decision.replacementSound.category} · {decision.replacementSound.license}</div>
                </div>
                {decision.replacementSound.audioUrl && (
                  <a
                    href={decision.replacementSound.audioUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-zinc-400 hover:text-white text-xs flex items-center gap-1"
                  >
                    Open <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          )}
        </div>
        <Badge variant="outline" className="text-[10px] shrink-0">{decision.confidence}%</Badge>
      </div>
    </div>
  );
}
