import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Languages, Loader2, Zap, CheckCircle2, Clock, AlertCircle,
  Film, FileText, Type, RotateCcw, ChevronRight, Globe2, Sparkles,
  Play, Check, X,
} from "lucide-react";
import { useListLanguages, useListProjects } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const STYLES = [
  { value: "cinematic", label: "Cinematic", emoji: "🎬" },
  { value: "documentary", label: "Documentary", emoji: "📽️" },
  { value: "dramatic", label: "Dramatic", emoji: "🎭" },
  { value: "action", label: "Action", emoji: "⚡" },
  { value: "romantic", label: "Romantic", emoji: "❤️" },
  { value: "horror", label: "Horror", emoji: "👻" },
  { value: "comedy", label: "Comedy", emoji: "😄" },
] as const;

const INPUT_TYPES = [
  { value: "story", label: "Story", icon: FileText, desc: "Narrative description" },
  { value: "script", label: "Script", icon: Type, desc: "Scene-by-scene screenplay" },
] as const;

const bulkSchema = z.object({
  title: z.string().min(1, "Title is required"),
  inputType: z.enum(["story", "script"]),
  inputContent: z.string().min(10, "Content must be at least 10 characters"),
  style: z.enum(["cinematic", "documentary", "dramatic", "action", "romantic", "horror", "comedy"]),
  durationSeconds: z.number().min(10).max(10800),
  projectId: z.string().optional(),
});

type BulkFormValues = z.infer<typeof bulkSchema>;

type VideoJob = {
  id: string;
  languageId: string;
  languageCode: string;
  languageName: string;
  languageFlag: string;
  title: string;
  status: "pending" | "processing" | "completed" | "failed";
  progress: number;
};

function StatusIcon({ status, progress }: { status: VideoJob["status"]; progress: number }) {
  if (status === "completed") return <CheckCircle2 className="w-5 h-5 text-green-400" />;
  if (status === "failed") return <AlertCircle className="w-5 h-5 text-red-400" />;
  if (status === "processing") return (
    <div className="relative w-5 h-5">
      <svg className="w-5 h-5 -rotate-90" viewBox="0 0 20 20">
        <circle cx="10" cy="10" r="8" fill="none" stroke="currentColor" strokeWidth="2" className="text-white/10" />
        <circle
          cx="10" cy="10" r="8" fill="none" stroke="currentColor" strokeWidth="2"
          className="text-primary"
          strokeDasharray={`${2 * Math.PI * 8}`}
          strokeDashoffset={`${2 * Math.PI * 8 * (1 - progress / 100)}`}
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
  return <Clock className="w-5 h-5 text-white/30 animate-pulse" />;
}

function VideoJobRow({ job, onView }: { job: VideoJob; onView: () => void }) {
  return (
    <div className={cn(
      "flex items-center gap-4 p-4 rounded-xl border transition-all duration-300",
      job.status === "completed" && "border-green-500/30 bg-green-500/5",
      job.status === "failed" && "border-red-500/30 bg-red-500/5",
      job.status === "processing" && "border-primary/30 bg-primary/5",
      job.status === "pending" && "border-border bg-white/2",
    )}>
      <div className="text-2xl w-9 text-center">{job.languageFlag}</div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium text-sm truncate">{job.languageName}</span>
          <Badge variant="outline" className="text-xs font-mono shrink-0">{job.languageCode.toUpperCase()}</Badge>
        </div>
        <div className="text-xs text-muted-foreground truncate mt-0.5">{job.title}</div>
        {job.status === "processing" && (
          <div className="mt-2 h-1 rounded-full bg-white/10 overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-700"
              style={{ width: `${job.progress}%` }}
            />
          </div>
        )}
      </div>
      <div className="flex items-center gap-3">
        {job.status === "processing" && (
          <span className="text-xs text-primary tabular-nums">{job.progress}%</span>
        )}
        <StatusIcon status={job.status} progress={job.progress} />
        {job.status === "completed" && (
          <Button size="sm" variant="outline" onClick={onView} className="h-7 text-xs gap-1">
            <Play className="w-3 h-3" /> View
          </Button>
        )}
        <span className={cn(
          "text-xs font-medium capitalize px-2 py-0.5 rounded-full",
          job.status === "completed" && "text-green-400 bg-green-400/10",
          job.status === "failed" && "text-red-400 bg-red-400/10",
          job.status === "processing" && "text-primary bg-primary/10",
          job.status === "pending" && "text-white/40 bg-white/5",
        )}>
          {job.status}
        </span>
      </div>
    </div>
  );
}

export function BulkGeneratePage() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  const [selectedLanguageIds, setSelectedLanguageIds] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [jobs, setJobs] = useState<VideoJob[]>([]);
  const [batchDone, setBatchDone] = useState(false);
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const { data: langData, isLoading: isLangLoading } = useListLanguages({
    query: { queryKey: ["listLanguages"] },
  });
  const { data: projectsData } = useListProjects();

  const languages = (langData as any) ?? [];
  const projects = projectsData?.projects ?? [];
  const isSuperAdmin = user?.role === "super_admin";

  const form = useForm<BulkFormValues>({
    resolver: zodResolver(bulkSchema),
    defaultValues: {
      title: "",
      inputType: "story",
      inputContent: "",
      style: "cinematic",
      durationSeconds: 60,
    },
  });

  const inputType = form.watch("inputType");
  const style = form.watch("style");

  const toggleLang = (id: string) => {
    setSelectedLanguageIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const selectAll = () => setSelectedLanguageIds(languages.map((l: any) => l.id));
  const clearAll = () => setSelectedLanguageIds([]);

  const indianLangs = languages.filter((l: any) => l.region === "indian");
  const globalLangs = languages.filter((l: any) => l.region === "global");

  // Poll each video's status while any is still pending/processing
  const startPolling = (videoJobs: VideoJob[]) => {
    if (pollingRef.current) clearInterval(pollingRef.current);
    pollingRef.current = setInterval(async () => {
      const token = localStorage.getItem("gems_token");
      const headers = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };

      const updates = await Promise.all(
        videoJobs.map(async (job) => {
          if (job.status === "completed" || job.status === "failed") return job;
          try {
            const res = await fetch(`/api/videos/${job.id}`, { headers });
            if (!res.ok) return job;
            const data = await res.json();
            return { ...job, status: data.status, progress: data.progress ?? job.progress };
          } catch {
            return job;
          }
        })
      );

      setJobs(updates);

      const allDone = updates.every((j) => j.status === "completed" || j.status === "failed");
      if (allDone) {
        setBatchDone(true);
        if (pollingRef.current) clearInterval(pollingRef.current);
      }
    }, 2500);
  };

  useEffect(() => () => { if (pollingRef.current) clearInterval(pollingRef.current); }, []);

  const onSubmit = async (values: BulkFormValues) => {
    if (selectedLanguageIds.length === 0) {
      toast({ title: "Select at least one language", variant: "destructive" });
      return;
    }
    setIsSubmitting(true);
    try {
      const token = localStorage.getItem("gems_token");
      const res = await fetch("/api/videos/bulk-generate", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          title: values.title,
          inputType: values.inputType,
          inputContent: values.inputContent,
          style: values.style,
          durationSeconds: values.durationSeconds,
          languageIds: selectedLanguageIds,
          projectId: values.projectId && values.projectId !== "none" ? values.projectId : undefined,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message ?? "Failed to start bulk generation");
      }

      const result = await res.json();
      const newJobs: VideoJob[] = result.videos.map((v: any) => ({
        id: v.id,
        languageId: v.languageId,
        languageCode: v.languageCode,
        languageName: v.languageName,
        languageFlag: v.languageFlag,
        title: v.title,
        status: v.status,
        progress: 0,
      }));

      setJobs(newJobs);
      setBatchDone(false);
      startPolling(newJobs);

      toast({
        title: `${newJobs.length} videos queued!`,
        description: `Generating in: ${newJobs.map((j) => j.languageName).join(", ")}`,
      });
    } catch (err: any) {
      toast({ title: "Generation failed", description: err.message, variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isSuperAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 text-center">
        <div className="w-16 h-16 rounded-2xl bg-red-500/10 flex items-center justify-center">
          <X className="w-8 h-8 text-red-400" />
        </div>
        <h2 className="text-2xl font-bold text-white">Access Restricted</h2>
        <p className="text-muted-foreground max-w-sm">Bulk generation is only available to Super Admin.</p>
      </div>
    );
  }

  const completedCount = jobs.filter((j) => j.status === "completed").length;
  const failedCount = jobs.filter((j) => j.status === "failed").length;

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Languages className="w-5 h-5 text-primary" />
            </div>
            <h1 className="text-3xl font-display font-bold text-white">Bulk Language Generator</h1>
          </div>
          <p className="text-muted-foreground ml-[52px]">
            Generate one video in multiple languages simultaneously — super admin only.
          </p>
        </div>
        <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 gap-1.5 px-3 py-1.5">
          <Zap className="w-3.5 h-3.5" /> Super Admin
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left — Form */}
        <div className="lg:col-span-3 space-y-5">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              {/* Script Input */}
              <Card className="border-border bg-card/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="w-4 h-4 text-primary" /> Script / Story
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField control={form.control} name="title" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Production Title</FormLabel>
                      <FormControl>
                        <Input placeholder="E.g. Monsoon Drama" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  {/* Input type toggle */}
                  <div className="flex gap-2">
                    {INPUT_TYPES.map((t) => (
                      <button
                        key={t.value} type="button"
                        onClick={() => form.setValue("inputType", t.value)}
                        className={cn(
                          "flex-1 flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm transition-all",
                          inputType === t.value
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border text-muted-foreground hover:border-white/20"
                        )}
                      >
                        <t.icon className="w-4 h-4" />
                        <div className="text-left">
                          <div className="font-medium">{t.label}</div>
                          <div className="text-xs opacity-60">{t.desc}</div>
                        </div>
                      </button>
                    ))}
                  </div>

                  <FormField control={form.control} name="inputContent" render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea
                          placeholder={inputType === "story"
                            ? "Describe your story in detail. The AI will interpret it for each language..."
                            : "Write your script scene-by-scene. The AI will adapt it per language..."}
                          rows={7}
                          className="resize-none font-mono text-sm"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </CardContent>
              </Card>

              {/* Settings */}
              <Card className="border-border bg-card/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-primary" /> Production Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Style */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Style</label>
                    <div className="grid grid-cols-4 gap-2">
                      {STYLES.map((s) => (
                        <button
                          key={s.value} type="button"
                          onClick={() => form.setValue("style", s.value)}
                          className={cn(
                            "flex flex-col items-center gap-1 p-2 rounded-lg border text-xs transition-all",
                            style === s.value
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border text-muted-foreground hover:border-white/20"
                          )}
                        >
                          <span className="text-lg">{s.emoji}</span>
                          <span className="font-medium">{s.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Duration + Project */}
                  <div className="grid grid-cols-2 gap-4">
                    <FormField control={form.control} name="durationSeconds" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Duration (seconds)</FormLabel>
                        <FormControl>
                          <Input
                            type="number" min={10} max={10800} step={10}
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value, 10) || 60)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />

                    <FormField control={form.control} name="projectId" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project (optional)</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value ?? "none"}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="No project" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">No project</SelectItem>
                            {projects.map((p: any) => (
                              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )} />
                  </div>
                </CardContent>
              </Card>

              <Button
                type="submit"
                disabled={isSubmitting || selectedLanguageIds.length === 0}
                className="w-full h-12 text-base font-bold gap-2"
              >
                {isSubmitting ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> Queuing Videos...</>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    Generate in {selectedLanguageIds.length > 0 ? selectedLanguageIds.length : "?"} Language{selectedLanguageIds.length !== 1 ? "s" : ""}
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </Button>
            </form>
          </Form>
        </div>

        {/* Right — Language selector */}
        <div className="lg:col-span-2">
          <Card className="border-border bg-card/50 sticky top-6">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Globe2 className="w-4 h-4 text-primary" /> Languages
                </CardTitle>
                <div className="flex gap-1.5">
                  <Button variant="ghost" size="sm" className="h-7 text-xs px-2" onClick={selectAll}>All</Button>
                  <Button variant="ghost" size="sm" className="h-7 text-xs px-2" onClick={clearAll}>Clear</Button>
                </div>
              </div>
              <CardDescription className="text-xs">
                {selectedLanguageIds.length} selected — each generates a separate video
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
              {isLangLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              ) : (
                <>
                  {indianLangs.length > 0 && (
                    <div>
                      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">🇮🇳 Indian</div>
                      <div className="space-y-1">
                        {indianLangs.map((lang: any) => {
                          const selected = selectedLanguageIds.includes(lang.id);
                          return (
                            <button
                              key={lang.id} type="button"
                              onClick={() => toggleLang(lang.id)}
                              className={cn(
                                "w-full flex items-center gap-3 px-3 py-2 rounded-lg border text-sm transition-all",
                                selected
                                  ? "border-primary bg-primary/10 text-white"
                                  : "border-transparent hover:border-border text-muted-foreground hover:text-white"
                              )}
                            >
                              <span className="text-lg w-7 text-center">{lang.flag}</span>
                              <div className="flex-1 text-left">
                                <div className="font-medium text-xs">{lang.name}</div>
                                <div className="text-xs opacity-50">{lang.nativeName}</div>
                              </div>
                              <div className={cn(
                                "w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-all",
                                selected ? "bg-primary border-primary" : "border-border"
                              )}>
                                {selected && <Check className="w-3 h-3 text-black" />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {globalLangs.length > 0 && (
                    <div>
                      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">🌍 Global</div>
                      <div className="space-y-1">
                        {globalLangs.map((lang: any) => {
                          const selected = selectedLanguageIds.includes(lang.id);
                          return (
                            <button
                              key={lang.id} type="button"
                              onClick={() => toggleLang(lang.id)}
                              className={cn(
                                "w-full flex items-center gap-3 px-3 py-2 rounded-lg border text-sm transition-all",
                                selected
                                  ? "border-primary bg-primary/10 text-white"
                                  : "border-transparent hover:border-border text-muted-foreground hover:text-white"
                              )}
                            >
                              <span className="text-lg w-7 text-center">{lang.flag}</span>
                              <div className="flex-1 text-left">
                                <div className="font-medium text-xs">{lang.name}</div>
                                <div className="text-xs opacity-50">{lang.nativeName}</div>
                              </div>
                              <div className={cn(
                                "w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-all",
                                selected ? "bg-primary border-primary" : "border-border"
                              )}>
                                {selected && <Check className="w-3 h-3 text-black" />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Progress Tracker */}
      {jobs.length > 0 && (
        <Card className="border-border bg-card/50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Film className="w-4 h-4 text-primary" /> Batch Progress
                <Badge variant="outline" className="text-xs">{jobs.length} videos</Badge>
              </CardTitle>
              <div className="flex items-center gap-3 text-sm">
                {completedCount > 0 && (
                  <span className="text-green-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> {completedCount} done
                  </span>
                )}
                {failedCount > 0 && (
                  <span className="text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" /> {failedCount} failed
                  </span>
                )}
                {batchDone ? (
                  <Badge className="bg-green-500/20 text-green-300 border-green-500/30">Batch Complete</Badge>
                ) : (
                  <div className="flex items-center gap-1.5 text-primary text-xs">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" /> Processing...
                  </div>
                )}
              </div>
            </div>

            {/* Overall progress bar */}
            <div className="mt-2 h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all duration-700"
                style={{ width: `${jobs.length > 0 ? ((completedCount + failedCount) / jobs.length) * 100 : 0}%` }}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {jobs.map((job) => (
                <VideoJobRow
                  key={job.id}
                  job={job}
                  onView={() => setLocation(`/videos/${job.id}`)}
                />
              ))}
            </div>

            {batchDone && (
              <div className="mt-4 flex gap-2">
                <Button
                  variant="outline"
                  className="gap-2"
                  onClick={() => { setJobs([]); setBatchDone(false); form.reset(); setSelectedLanguageIds([]); }}
                >
                  <RotateCcw className="w-4 h-4" /> Start New Batch
                </Button>
                <Button className="gap-2" onClick={() => setLocation("/videos")}>
                  <Film className="w-4 h-4" /> View All Videos
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
