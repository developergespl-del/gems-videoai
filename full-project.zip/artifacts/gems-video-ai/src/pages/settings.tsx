import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useUpdateUser, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { User, Mail, Shield, Loader2, Save, Key, Crown, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

const PLAN_CONFIG = {
  user: {
    label: "Free Plan",
    description: "Basic video generation with CPU rendering.",
    icon: Shield,
    iconColor: "text-zinc-400",
    badgeClass: "bg-zinc-700 text-zinc-100",
  },
  admin: {
    label: "Paid Plan",
    description: "GPU-accelerated rendering, 5 scenes per video, and priority queue access.",
    icon: Zap,
    iconColor: "text-purple-400",
    badgeClass: "bg-purple-700 text-white",
  },
  super_admin: {
    label: "Enterprise Plan",
    description: "H100 GPU cluster, 8 scenes per video, 4K rendering, and highest priority queue.",
    icon: Crown,
    iconColor: "text-amber-400",
    badgeClass: "bg-amber-600 text-white",
  },
};

export function SettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const updateUser = useUpdateUser();

  const [name, setName] = useState(user?.name || "");
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || "");

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordLoading, setPasswordLoading] = useState(false);

  const handleUpdateProfile = async () => {
    if (!user) return;
    try {
      await updateUser.mutateAsync({
        id: user.id,
        data: { name, avatarUrl }
      });
      toast({ title: "Profile updated successfully" });
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    } catch (err: any) {
      toast({ title: "Update failed", description: err.message, variant: "destructive" });
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast({ title: "Passwords don't match", description: "New password and confirm password must be the same.", variant: "destructive" });
      return;
    }
    if (newPassword.length < 8) {
      toast({ title: "Password too short", description: "New password must be at least 8 characters.", variant: "destructive" });
      return;
    }

    setPasswordLoading(true);
    try {
      const token = localStorage.getItem("gems_token");
      const resp = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await resp.json() as { message?: string; error?: string };
      if (!resp.ok) {
        toast({ title: "Password change failed", description: data.error || data.message || "Unknown error", variant: "destructive" });
        return;
      }
      toast({ title: "Password updated", description: "Your password has been changed successfully." });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch {
      toast({ title: "Network error", description: "Could not reach the server. Please try again.", variant: "destructive" });
    } finally {
      setPasswordLoading(false);
    }
  };

  if (!user) return null;

  const plan = PLAN_CONFIG[(user.role as keyof typeof PLAN_CONFIG) ?? "user"] ?? PLAN_CONFIG.user;
  const PlanIcon = plan.icon;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground mt-1">Manage your studio profile and preferences.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          {/* Profile Settings */}
          <Card className="bg-card border-white/5 shadow-xl">
            <CardHeader>
              <CardTitle>Profile</CardTitle>
              <CardDescription>Your identity within the studio.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-6">
                <div className="w-24 h-24 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-primary text-3xl font-bold overflow-hidden">
                  {avatarUrl ? (
                    <img src={avatarUrl} alt={name} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
                  ) : (
                    name.charAt(0).toUpperCase()
                  )}
                </div>
                <div className="flex-1 space-y-1">
                  <h3 className="font-bold text-lg">{user.name}</h3>
                  <p className="text-muted-foreground text-sm flex items-center gap-2">
                    <Mail className="w-4 h-4" /> {user.email}
                  </p>
                  <div className="pt-2">
                    <Badge variant="secondary" className={`capitalize ${plan.badgeClass}`}>
                      {user.role.replace("_", " ")}
                    </Badge>
                  </div>
                </div>
              </div>
              
              <Separator className="bg-white/5" />
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <User className="w-4 h-4 text-muted-foreground" /> Full Name
                  </label>
                  <Input 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    className="bg-background/50 border-white/10 max-w-md"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    Avatar URL
                  </label>
                  <Input 
                    placeholder="https://example.com/avatar.jpg"
                    value={avatarUrl} 
                    onChange={(e) => setAvatarUrl(e.target.value)} 
                    className="bg-background/50 border-white/10 max-w-md"
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-white/[0.02] border-t border-white/5 flex justify-end">
              <Button onClick={handleUpdateProfile} disabled={updateUser.isPending} className="bg-primary text-primary-foreground hover:bg-primary/90">
                {updateUser.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                Save Changes
              </Button>
            </CardFooter>
          </Card>

          {/* Security Settings */}
          <Card className="bg-card border-white/5 shadow-xl">
            <CardHeader>
              <CardTitle>Security</CardTitle>
              <CardDescription>Update your password to keep your account secure.</CardDescription>
            </CardHeader>
            <form onSubmit={handleUpdatePassword}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Key className="w-4 h-4 text-muted-foreground" /> Current Password
                  </label>
                  <Input 
                    type="password"
                    value={currentPassword} 
                    onChange={(e) => setCurrentPassword(e.target.value)} 
                    className="bg-background/50 border-white/10 max-w-md"
                    placeholder="Enter current password"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    New Password
                  </label>
                  <Input 
                    type="password"
                    value={newPassword} 
                    onChange={(e) => setNewPassword(e.target.value)} 
                    className="bg-background/50 border-white/10 max-w-md"
                    placeholder="Min. 8 characters"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    Confirm New Password
                  </label>
                  <Input 
                    type="password"
                    value={confirmPassword} 
                    onChange={(e) => setConfirmPassword(e.target.value)} 
                    className="bg-background/50 border-white/10 max-w-md"
                    placeholder="Repeat new password"
                    required
                  />
                </div>
              </CardContent>
              <CardFooter className="bg-white/[0.02] border-t border-white/5 flex justify-end">
                <Button type="submit" disabled={passwordLoading || !currentPassword || !newPassword || !confirmPassword} className="bg-primary text-primary-foreground hover:bg-primary/90">
                  {passwordLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Key className="w-4 h-4 mr-2" />}
                  Update Password
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <Card className="bg-card border-white/5">
            <CardHeader>
              <CardTitle className="text-lg">Account Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="flex justify-between py-2 border-b border-white/5">
                <span className="text-muted-foreground">Member Since</span>
                <span className="font-medium">{new Date(user.createdAt).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-white/5">
                <span className="text-muted-foreground">Storage Used</span>
                <span className="font-medium">{(user.storageUsedMb || 0).toFixed(1)} MB</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-muted-foreground">Total Videos</span>
                <span className="font-medium">{user.videoCount || 0}</span>
              </div>
            </CardContent>
          </Card>

          <Card className={`border ${
            user.role === "super_admin" 
              ? "bg-amber-500/5 border-amber-500/20" 
              : user.role === "admin" 
              ? "bg-purple-500/5 border-purple-500/20" 
              : "bg-zinc-800/40 border-white/5"
          }`}>
            <CardContent className="p-6">
              <PlanIcon className={`w-8 h-8 mb-4 ${plan.iconColor}`} />
              <h3 className="font-bold mb-2">{plan.label}</h3>
              <p className="text-sm text-muted-foreground">
                {plan.description}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
