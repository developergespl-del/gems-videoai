import { Link } from "wouter";
import { motion } from "framer-motion";
import { 
  Film, 
  Play, 
  Clock, 
  Database, 
  Plus, 
  Activity,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Megaphone,
} from "lucide-react";
import { 
  useGetDashboardStats, 
  getGetDashboardStatsQueryKey,
  useGetRecentActivity,
  getGetRecentActivityQueryKey,
  useGetVideoStatusBreakdown,
  getGetVideoStatusBreakdownQueryKey,
  useListAds,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { AdUnit } from "@/components/ad-unit";

function formatDuration(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatStorage(mb: number) {
  if (mb > 1024) return `${(mb / 1024).toFixed(2)} GB`;
  return `${mb.toFixed(1)} MB`;
}

export function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats({
    query: {
      queryKey: getGetDashboardStatsQueryKey(),
      refetchInterval: (q) => {
        const d = q.state.data as any;
        return (d?.processingVideos ?? 0) > 0 ? 5000 : false;
      },
    },
  });
  const { data: recent, isLoading: recentLoading } = useGetRecentActivity({ limit: 5 }, {
    query: {
      queryKey: getGetRecentActivityQueryKey({ limit: 5 }),
      refetchInterval: (q) => {
        const d = q.state.data as any;
        if (!d?.activities) return false;
        const hasProcessing = d.activities.some((a: any) =>
          a.status === "processing" || a.status === "pending"
        );
        return hasProcessing ? 5000 : false;
      },
    },
  });
  const { data: breakdown, isLoading: breakdownLoading } = useGetVideoStatusBreakdown({
    query: {
      queryKey: getGetVideoStatusBreakdownQueryKey(),
      refetchInterval: (q) => {
        const d = q.state.data as any;
        return (d?.processing ?? 0) > 0 || (d?.pending ?? 0) > 0 ? 5000 : false;
      },
    },
  });
  const { data: dashboardAds } = useListAds({ placement: "dashboard" });

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight">Studio Dashboard</h1>
          <p className="text-muted-foreground mt-1">Overview of your cinematic productions.</p>
        </div>
        <Link href="/videos/new">
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-[0_0_20px_-5px_rgba(234,179,8,0.4)]">
            <Plus className="w-4 h-4 mr-2" />
            New Production
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-white/5 hover:border-primary/20 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Videos</CardTitle>
            <Film className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            {statsLoading ? <Skeleton className="h-8 w-16" /> : (
              <div className="text-3xl font-display font-bold">{stats?.totalVideos || 0}</div>
            )}
          </CardContent>
        </Card>
        
        <Card className="bg-card border-white/5 hover:border-primary/20 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Completed</CardTitle>
            <CheckCircle2 className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            {statsLoading ? <Skeleton className="h-8 w-16" /> : (
              <div className="text-3xl font-display font-bold">{stats?.completedVideos || 0}</div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card border-white/5 hover:border-primary/20 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Duration</CardTitle>
            <Clock className="w-4 h-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            {statsLoading ? <Skeleton className="h-8 w-24" /> : (
              <div className="text-3xl font-display font-bold">{formatDuration(stats?.totalDurationSeconds || 0)}</div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card border-white/5 hover:border-primary/20 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Storage Used</CardTitle>
            <Database className="w-4 h-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            {statsLoading ? <Skeleton className="h-8 w-24" /> : (
              <div className="text-3xl font-display font-bold">{formatStorage(stats?.storageUsedMb || 0)}</div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <Card className="lg:col-span-2 bg-card border-white/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentLoading ? (
              <div className="space-y-4">
                {[1,2,3].map(i => <Skeleton key={i} className="h-16 w-full" />)}
              </div>
            ) : recent?.activities && recent.activities.length > 0 ? (
              <div className="space-y-4">
                {recent.activities.map((act, i) => (
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    key={act.id} 
                    className="flex items-center gap-4 p-3 rounded-lg border border-white/5 bg-background/50 hover:bg-white/5 transition-colors"
                  >
                    <div className="w-16 h-12 bg-secondary rounded overflow-hidden flex-shrink-0 relative border border-white/10">
                      {act.thumbnailUrl ? (
                        <img src={act.thumbnailUrl} alt={act.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Film className="w-4 h-4 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <Link href={`/videos/${act.videoId}`} className="font-medium hover:text-primary transition-colors truncate block">
                        {act.title}
                      </Link>
                      <div className="text-xs text-muted-foreground mt-1">
                        {new Date(act.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    <div>
                      {act.status === 'completed' && <Badge className="bg-green-500/10 text-green-500 border-green-500/20">Ready</Badge>}
                      {act.status === 'processing' && <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20">Rendering <Loader2 className="w-3 h-3 inline ml-1 animate-spin" /></Badge>}
                      {act.status === 'pending' && <Badge variant="outline" className="text-muted-foreground">Queued</Badge>}
                      {act.status === 'failed' && <Badge variant="destructive" className="bg-destructive/10 text-destructive border-destructive/20">Failed</Badge>}
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Film className="w-6 h-6 opacity-50" />
                </div>
                <p>No recent activity found.</p>
                <Link href="/videos/new" className="text-primary hover:underline mt-2 inline-block">Create your first video</Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Status Breakdown */}
        <Card className="bg-card border-white/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5 text-primary" />
              Status Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            {breakdownLoading ? (
              <div className="space-y-4">
                {[1,2,3,4].map(i => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded bg-green-500/5 border border-green-500/10">
                  <div className="flex items-center gap-2 text-green-500">
                    <CheckCircle2 className="w-4 h-4" />
                    <span className="font-medium">Completed</span>
                  </div>
                  <span className="font-display font-bold">{breakdown?.completed || 0}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded bg-blue-500/5 border border-blue-500/10">
                  <div className="flex items-center gap-2 text-blue-500">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="font-medium">Processing</span>
                  </div>
                  <span className="font-display font-bold">{breakdown?.processing || 0}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded bg-zinc-500/5 border border-zinc-500/10">
                  <div className="flex items-center gap-2 text-zinc-400">
                    <Clock className="w-4 h-4" />
                    <span className="font-medium">Pending</span>
                  </div>
                  <span className="font-display font-bold">{breakdown?.pending || 0}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded bg-red-500/5 border border-red-500/10">
                  <div className="flex items-center gap-2 text-red-500">
                    <AlertCircle className="w-4 h-4" />
                    <span className="font-medium">Failed</span>
                  </div>
                  <span className="font-display font-bold">{breakdown?.failed || 0}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Studio Spotlight — non-intrusive ad section */}
      {dashboardAds && dashboardAds.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Megaphone className="w-4 h-4 text-white/30" />
            <span className="text-sm text-white/30 font-medium">Studio Spotlight</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {dashboardAds.slice(0, 3).map((ad) => (
              <AdUnit key={ad.id} ad={ad} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
