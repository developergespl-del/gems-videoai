import { useParams, Link } from "wouter";
import { useState } from "react";
import { motion } from "framer-motion";
import { 
  useGetProject, 
  useListVideos, 
  useUpdateProject, 
  useDeleteProject,
  getGetProjectQueryKey,
  getListVideosQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { 
  FolderKanban, 
  Plus, 
  Film, 
  ArrowLeft, 
  Edit2, 
  Trash2, 
  MoreVertical,
  Play,
  Loader2,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useLocation } from "wouter";

export function ProjectDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id as string;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: project, isLoading: isProjectLoading, error } = useGetProject(id, {
    query: { enabled: !!id, queryKey: getGetProjectQueryKey(id) }
  });

  const { data: videosData, isLoading: isVideosLoading } = useListVideos({ projectId: id }, {
    query: {
      enabled: !!id,
      queryKey: getListVideosQueryKey({ projectId: id }),
      refetchInterval: (q) => {
        const vids = (q.state.data as any)?.videos as any[] | undefined;
        if (!vids) return false;
        const hasActive = vids.some((v: any) => v.status === "processing" || v.status === "pending");
        return hasActive ? 5000 : false;
      },
    },
  });

  const updateProject = useUpdateProject();
  const deleteProject = useDeleteProject();

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editName, setEditName] = useState("");
  const [editDesc, setEditDesc] = useState("");

  if (error) {
    return (
      <div className="text-center py-20 bg-card rounded-xl border border-white/5">
        <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2">Project not found</h2>
        <p className="text-muted-foreground mb-6">The requested project could not be loaded or doesn't exist.</p>
        <Link href="/projects">
          <Button>Return to Projects</Button>
        </Link>
      </div>
    );
  }

  if (isProjectLoading || !project) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="w-10 h-10 rounded-full" />
          <Skeleton className="h-10 w-1/3" />
        </div>
        <Skeleton className="h-24 w-full rounded-xl" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1,2,3].map(i => <Skeleton key={i} className="h-48 rounded-xl" />)}
        </div>
      </div>
    );
  }

  const openEditModal = () => {
    setEditName(project.name);
    setEditDesc(project.description || "");
    setIsEditOpen(true);
  };

  const handleUpdate = async () => {
    if (!editName.trim()) return;
    try {
      await updateProject.mutateAsync({
        id,
        data: { name: editName, description: editDesc }
      });
      toast({ title: "Project updated" });
      setIsEditOpen(false);
      queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(id) });
    } catch (err: any) {
      toast({ title: "Update failed", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async () => {
    try {
      await deleteProject.mutateAsync({ id });
      toast({ title: "Project deleted" });
      setLocation("/projects");
    } catch (err: any) {
      toast({ title: "Delete failed", description: err.message, variant: "destructive" });
    }
  };

  const videos = videosData?.videos || [];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Link href="/projects">
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/5">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3">
              <FolderKanban className="w-8 h-8 text-primary" />
              {project.name}
            </h1>
            <p className="text-muted-foreground mt-1">
              Created on {new Date(project.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Link href="/videos/new">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold">
              <Plus className="w-4 h-4 mr-2" />
              Add Video
            </Button>
          </Link>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" className="border-white/10 hover:bg-white/5">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 bg-card border-white/10">
              <DropdownMenuItem className="cursor-pointer" onClick={openEditModal}>
                <Edit2 className="w-4 h-4 mr-2" />
                Edit Details
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-white/10" />
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:bg-destructive/10 cursor-pointer">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete Project
                  </DropdownMenuItem>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-card border-white/10">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete {project.name}?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. This will delete the project folder, but not the videos inside it.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="bg-transparent border-white/10 hover:bg-white/5">Cancel</AlertDialogCancel>
                    <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>
                      Delete Project
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {project.description && (
        <div className="bg-card border border-white/5 rounded-xl p-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-2">Project Notes</h3>
          <p className="text-sm leading-relaxed">{project.description}</p>
        </div>
      )}

      <div>
        <h2 className="text-2xl font-display font-bold tracking-tight mb-6">Productions in this Project</h2>
        
        {isVideosLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-xl overflow-hidden border border-white/5 bg-card">
                <Skeleton className="w-full aspect-video" />
                <div className="p-4 space-y-3">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : videos.length === 0 ? (
          <div className="text-center py-20 bg-card rounded-xl border border-white/5">
            <Film className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-bold mb-2">No videos in this project</h3>
            <p className="text-muted-foreground mb-6">Create a new video and assign it to this project.</p>
            <Link href="/videos/new">
              <Button>Create First Video</Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {videos.map((video, index) => (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                key={video.id}
                className="group rounded-xl overflow-hidden border border-white/5 bg-card hover:border-primary/30 transition-colors relative"
              >
                <div className="aspect-video bg-zinc-900 relative border-b border-white/5">
                  {video.status === "completed" && video.thumbnailUrl ? (
                    <>
                      <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Link href={`/videos/${video.id}`}>
                          <Button variant="secondary" size="icon" className="rounded-full w-12 h-12 bg-white/20 hover:bg-primary hover:text-primary-foreground backdrop-blur-sm border-none">
                            <Play className="w-6 h-6 ml-1" />
                          </Button>
                        </Link>
                      </div>
                    </>
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground bg-gradient-to-br from-zinc-900 to-zinc-950">
                      {video.status === "processing" ? (
                        <>
                          <Loader2 className="w-8 h-8 animate-spin mb-3 text-blue-500" />
                          <div className="text-sm font-medium">Rendering ({video.progress}%)</div>
                        </>
                      ) : video.status === "failed" ? (
                        <>
                          <AlertCircle className="w-8 h-8 mb-3 text-destructive" />
                          <div className="text-sm font-medium">Render Failed</div>
                        </>
                      ) : (
                        <>
                          <Film className="w-8 h-8 mb-3 opacity-50" />
                          <div className="text-sm font-medium">Queued</div>
                        </>
                      )}
                    </div>
                  )}
                  
                  <div className="absolute top-3 left-3 flex flex-col gap-2">
                    <Badge variant="secondary" className="bg-black/60 backdrop-blur-md border-white/10 uppercase tracking-wider text-[10px]">
                      {video.style}
                    </Badge>
                  </div>
                </div>

                <div className="p-4">
                  <div className="min-w-0">
                    <Link href={`/videos/${video.id}`} className="font-bold text-lg hover:text-primary transition-colors truncate block">
                      {video.title}
                    </Link>
                    <div className="text-xs text-muted-foreground mt-1">
                      {new Date(video.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-card border-white/10 sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Project</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Project Name</label>
              <Input 
                value={editName} 
                onChange={(e) => setEditName(e.target.value)} 
                className="bg-background/50 border-white/10"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea 
                value={editDesc} 
                onChange={(e) => setEditDesc(e.target.value)}
                className="bg-background/50 border-white/10 resize-none h-24"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>Cancel</Button>
            <Button onClick={handleUpdate} disabled={!editName.trim() || updateProject.isPending} className="bg-primary text-primary-foreground hover:bg-primary/90">
              {updateProject.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
