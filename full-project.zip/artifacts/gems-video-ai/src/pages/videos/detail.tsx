import { useParams, Link, useLocation } from "wouter";
import {
  useGetVideo,
  useUpdateVideo,
  useDeleteVideo,
  getGetVideoQueryKey,
  useGenerateMarketingAssets,
  useGetVideoMarketingAssets,
  useDeleteMarketingAsset,
  useRegenerateMarketingAsset,
  getGetVideoMarketingAssetsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  Film,
  Clock,
  ArrowLeft,
  AlignLeft,
  Image as ImageIcon,
  Edit2,
  Trash2,
  Loader2,
  AlertCircle,
  Download,
  Clapperboard,
  Megaphone,
  Ticket,
  Monitor,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  Music,
  Languages,
  Play,
  Plus,
  MonitorPlay,
  Palette,
  Volume2,
  Scissors,
  Coffee,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GenerationWorkflow } from "@/components/generation-workflow";

// ---------------------------------------------------------------------------
// Stage label helpers
// ---------------------------------------------------------------------------
const STAGE_LABEL: Record<string, { label: string; color: string }> = {
  analyzing:   { label: "Analyzing",    color: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
  analyzed:    { label: "Ready for Screenplay", color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  screenwrote: { label: "Ready to Generate", color: "bg-green-500/10 text-green-400 border-green-500/20" },
  rendering:   { label: "Rendering",    color: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
  completed:   { label: "Completed",    color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
  failed:      { label: "Failed",       color: "bg-destructive/10 text-destructive border-destructive/20" },
};

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------
export function VideoDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id as string;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: video, isLoading, error } = useGetVideo(id, {
    query: {
      enabled: !!id,
      queryKey: getGetVideoQueryKey(id),
      refetchInterval: (query) => {
        const d = query.state.data as any;
        if (!d) return 3000;
        const stage = d.generationStage ?? d.status;
        // "screenwrote" is included because the worker auto-advances through it to "rendering"
        return ["analyzing", "screenwrote", "rendering", "processing", "queued", "pending"].includes(stage) ? 3000 : false;
      },
    },
  });

  const updateVideo = useUpdateVideo();
  const deleteVideo = useDeleteVideo();

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editTitle, setEditTitle] = useState("");
  const [editDesc, setEditDesc] = useState("");

  if (error) {
    return (
      <div className="text-center py-20">
        <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2">Video not found</h2>
        <p className="text-muted-foreground mb-6">This video could not be loaded or doesn't exist.</p>
        <Link href="/videos"><Button>Return to Library</Button></Link>
      </div>
    );
  }

  if (isLoading || !video) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="w-10 h-10 rounded-full" />
          <Skeleton className="h-10 w-1/3" />
        </div>
        <Skeleton className="w-full h-48 rounded-xl" />
        <Skeleton className="w-full h-96 rounded-xl" />
      </div>
    );
  }

  const stage = video.generationStage ?? "analyzing";
  const stageInfo = STAGE_LABEL[stage] ?? STAGE_LABEL.analyzing;

  const handleUpdate = async () => {
    try {
      await updateVideo.mutateAsync({ id, data: { title: editTitle, description: editDesc } });
      toast({ title: "Updated" });
      setIsEditOpen(false);
      queryClient.invalidateQueries({ queryKey: getGetVideoQueryKey(id) });
    } catch (err: any) {
      toast({ title: "Update failed", description: err.message, variant: "destructive" });
    }
  };

  const openEditModal = () => {
    setEditTitle(video.title);
    setEditDesc(video.description || "");
    setIsEditOpen(true);
  };

  const handleDelete = async () => {
    if (!confirm("Delete this video? This cannot be undone.")) return;
    try {
      await deleteVideo.mutateAsync({ id });
      toast({ title: "Video deleted" });
      setLocation("/videos");
    } catch (err: any) {
      toast({ title: "Delete failed", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          <Link href="/videos">
            <Button variant="ghost" size="icon" className="rounded-full mt-0.5">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl sm:text-3xl font-display font-bold tracking-tight leading-tight">
              {video.title}
            </h1>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <Badge className={`text-xs ${stageInfo.color}`}>{stageInfo.label}</Badge>
              <Badge variant="outline" className="text-xs border-white/10 capitalize">{video.style}</Badge>
              <span className="text-muted-foreground text-xs">
                {Math.floor(video.durationSeconds / 60)}m {video.durationSeconds % 60}s
              </span>
              <span className="text-muted-foreground text-xs">·</span>
              <span className="text-muted-foreground text-xs">
                {new Date(video.createdAt).toLocaleDateString()}
              </span>
              {video.projectId && (
                <>
                  <span className="text-white/20">·</span>
                  <Link href={`/projects/${video.projectId}`} className="text-xs text-primary hover:underline">
                    View Project
                  </Link>
                </>
              )}
            </div>
            {/* Cinema spec badges */}
            {((video as any).resolution || (video as any).aspectRatio) && (
              <div className="flex flex-wrap items-center gap-2 mt-2">
                {(video as any).cinemaMode && (
                  <Badge className="bg-primary/20 text-primary border-primary/30 text-[10px] px-2 py-0.5 gap-1">
                    <Film className="w-2.5 h-2.5" /> Cinema Mode
                  </Badge>
                )}
                {(video as any).resolution && (
                  <Badge variant="outline" className="text-[10px] border-white/10 gap-1 px-2 py-0.5">
                    <MonitorPlay className="w-2.5 h-2.5 text-muted-foreground" />
                    {(video as any).resolution}
                  </Badge>
                )}
                {(video as any).aspectRatio && (
                  <Badge variant="outline" className="text-[10px] border-white/10 px-2 py-0.5">
                    {(video as any).aspectRatio}
                  </Badge>
                )}
                {(video as any).colorGrade && (video as any).colorGrade !== "natural" && (
                  <Badge variant="outline" className="text-[10px] border-white/10 gap-1 px-2 py-0.5 capitalize">
                    <Palette className="w-2.5 h-2.5 text-muted-foreground" />
                    {(video as any).colorGrade}
                  </Badge>
                )}
                {(video as any).filmGrain && (
                  <Badge variant="outline" className="text-[10px] border-white/10 px-2 py-0.5">Grain</Badge>
                )}
                {(video as any).depthOfField && (
                  <Badge variant="outline" className="text-[10px] border-white/10 px-2 py-0.5">DoF</Badge>
                )}
                {(video as any).audioMastering === "surround-ready" && (
                  <Badge variant="outline" className="text-[10px] border-white/10 gap-1 px-2 py-0.5">
                    <Volume2 className="w-2.5 h-2.5 text-muted-foreground" /> Surround
                  </Badge>
                )}
                {Array.isArray((video as any).exportFormats) && (video as any).exportFormats.length > 0 && (
                  <Badge variant="outline" className="text-[10px] border-white/10 px-2 py-0.5">
                    {(video as any).exportFormats.join(" · ")}
                  </Badge>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 pl-14 sm:pl-0">
          {stage === "completed" && video.outputUrl && (
            <Button variant="outline" size="sm" className="border-white/10 gap-2"
              onClick={async () => {
                try {
                  const token = localStorage.getItem("gems_token");
                  const resp = await fetch(`/api/videos/${video.id}/download`, {
                    headers: token ? { Authorization: `Bearer ${token}` } : {},
                  });
                  if (!resp.ok) throw new Error("Failed to get download link");
                  const { url } = await resp.json() as { url: string };
                  window.open(url, "_blank");
                } catch {
                  window.open(video.outputUrl!, "_blank");
                }
              }}>
              <Download className="w-4 h-4" /> Download
            </Button>
          )}
          <Button variant="outline" size="icon" onClick={openEditModal} className="border-white/10">
            <Edit2 className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={handleDelete}
            className="border-white/10 text-destructive hover:bg-destructive/10">
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* ── Completed Video Player ── */}
      {stage === "completed" && video.thumbnailUrl && (
        <Card className="overflow-hidden bg-black border-white/10 shadow-2xl">
          <div className="relative aspect-video bg-black w-full flex items-center justify-center">
            {video.outputUrl ? (
              <video controls className="w-full h-full object-contain"
                poster={video.thumbnailUrl} src={video.outputUrl} />
            ) : (
              <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover opacity-60" />
            )}
          </div>
        </Card>
      )}

      {/* ── 3-Step Generation Workflow ── */}
      <div>
        <div className="flex items-center gap-2 mb-5">
          <Clapperboard className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-display font-bold tracking-tight">Generation Pipeline</h2>
        </div>
        <GenerationWorkflow
          video={{
            id: video.id,
            title: video.title,
            inputType: video.inputType,
            style: video.style,
            durationSeconds: video.durationSeconds,
            generationStage: stage,
            status: video.status,
            progress: video.progress,
            priority: (video as any).priority,
            workerType: (video as any).workerType,
            sceneCount: (video as any).sceneCount,
            scenesCompleted: (video as any).scenesCompleted,
            estimatedSeconds: (video as any).estimatedSeconds,
            queuePosition: (video as any).queuePosition,
            processingStartedAt: (video as any).processingStartedAt,
          }}
        />
      </div>

      {/* ── Long Film Structure ── */}
      {((video as any).hasIntermission || (video as any).isSplit) && (
        <Card className="bg-card border-white/5">
          <CardHeader>
            <CardTitle className="text-sm font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <Scissors className="w-4 h-4 text-amber-400" />
              Long Film Structure
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {(video as any).isSplit && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge className="bg-amber-400/15 text-amber-300 border-amber-400/30 text-[10px] px-2 py-0.5">
                    2-Part Film
                  </Badge>
                  {(video as any).splitAtSecond != null && (
                    <span className="text-xs text-muted-foreground">
                      Split at {Math.floor((video as any).splitAtSecond / 3600)}h {Math.floor(((video as any).splitAtSecond % 3600) / 60)}m
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="bg-background/50 border border-white/5 rounded-lg p-4">
                    <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">Part 1</div>
                    <div className="text-sm font-medium text-white/90 mb-3">
                      {(video as any).part1Title ?? `${video.title} — Part 1`}
                    </div>
                    {video.outputUrl && (
                      <Button size="sm" variant="outline"
                        className="border-white/10 text-xs gap-1.5 w-full"
                        onClick={async () => {
                          try {
                            const token = localStorage.getItem("gems_token");
                            const resp = await fetch(`/api/videos/${video.id}/download`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
                            const { url } = await resp.json() as { url: string };
                            window.open(url, "_blank");
                          } catch { window.open(video.outputUrl!, "_blank"); }
                        }}>
                        <Download className="w-3.5 h-3.5" /> Download Part 1
                      </Button>
                    )}
                    {!video.outputUrl && (
                      <div className="text-xs text-muted-foreground italic">Available after render</div>
                    )}
                  </div>
                  <div className="bg-background/50 border border-white/5 rounded-lg p-4">
                    <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">Part 2</div>
                    <div className="text-sm font-medium text-white/90 mb-3">
                      {(video as any).part2Title ?? `${video.title} — Part 2`}
                    </div>
                    {video.outputUrl && (
                      <Button size="sm" variant="outline"
                        className="border-white/10 text-xs gap-1.5 w-full"
                        onClick={async () => {
                          try {
                            const token = localStorage.getItem("gems_token");
                            const resp = await fetch(`/api/videos/${video.id}/download`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
                            const { url } = await resp.json() as { url: string };
                            window.open(url, "_blank");
                          } catch { window.open(video.outputUrl!, "_blank"); }
                        }}>
                        <Download className="w-3.5 h-3.5" /> Download Part 2
                      </Button>
                    )}
                    {!video.outputUrl && (
                      <div className="text-xs text-muted-foreground italic">Available after render</div>
                    )}
                  </div>
                </div>
              </div>
            )}
            {(video as any).hasIntermission && (
              <div className="flex items-start gap-3 bg-background/50 border border-white/5 rounded-lg p-4">
                <Coffee className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium text-white/90">Intermission</span>
                    {(video as any).intermissionLabel && (video as any).intermissionLabel !== "INTERMISSION" && (
                      <Badge variant="outline" className="text-[10px] border-white/10 px-2 py-0">
                        {(video as any).intermissionLabel}
                      </Badge>
                    )}
                    {(video as any).intermissionAtSecond != null && (
                      <span className="text-xs text-muted-foreground">
                        at {Math.floor((video as any).intermissionAtSecond / 3600)}h{" "}
                        {Math.floor(((video as any).intermissionAtSecond % 3600) / 60)}m
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Cinematic intermission card inserted at a natural narrative break.
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── Marketing Assets ── */}
      <MarketingAssetsPanel
        videoId={video.id}
        durationSeconds={video.durationSeconds}
        defaultLanguage={(video as any).language ?? "hi"}
      />

      {/* ── Source Material ── */}
      <Card className="bg-card border-white/5">
        <CardHeader>
          <CardTitle className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
            Source Material
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          {video.description && (
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-2">
                <AlignLeft className="w-3.5 h-3.5" /> Description
              </div>
              <p className="text-sm leading-relaxed bg-background/50 p-4 rounded-lg border border-white/5">
                {video.description}
              </p>
            </div>
          )}
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-2">
              {video.inputType === "story" && <AlignLeft className="w-3.5 h-3.5" />}
              {video.inputType === "script" && <Film className="w-3.5 h-3.5" />}
              {video.inputType === "image" && <ImageIcon className="w-3.5 h-3.5" />}
              <span className="capitalize">{video.inputType} Input</span>
            </div>
            {video.inputType === "image" ? (
              <a href={video.inputContent} target="_blank" rel="noreferrer"
                className="text-primary hover:underline text-sm break-all block bg-background/50 p-4 rounded-lg border border-white/5">
                {video.inputContent}
              </a>
            ) : (
              <div className="bg-background/50 p-4 rounded-lg border border-white/5 font-mono text-xs
                whitespace-pre-wrap max-h-72 overflow-y-auto leading-relaxed text-white/70">
                {video.inputContent}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ── Edit dialog ── */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-card border-white/10 sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Production Metadata</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Title</label>
              <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)}
                className="bg-background/50 border-white/10" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea value={editDesc} onChange={(e) => setEditDesc(e.target.value)}
                className="bg-background/50 border-white/10 resize-none h-24" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>Cancel</Button>
            <Button onClick={handleUpdate} disabled={updateVideo.isPending}
              className="bg-primary text-primary-foreground hover:bg-primary/90">
              {updateVideo.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving</> : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// MARKETING ASSETS PANEL
// ============================================================
const LANGUAGE_OPTIONS = [
  { code: "hi", label: "Hindi" },
  { code: "en", label: "English" },
  { code: "ta", label: "Tamil" },
  { code: "te", label: "Telugu" },
  { code: "bn", label: "Bengali" },
  { code: "mr", label: "Marathi" },
  { code: "pa", label: "Punjabi" },
  { code: "kn", label: "Kannada" },
  { code: "ml", label: "Malayalam" },
  { code: "gu", label: "Gujarati" },
  { code: "or", label: "Odia" },
  { code: "ur", label: "Urdu" },
  { code: "as", label: "Assamese" },
  { code: "ar", label: "Arabic" },
  { code: "zh", label: "Mandarin" },
  { code: "es", label: "Spanish" },
  { code: "fr", label: "French" },
  { code: "pt", label: "Portuguese" },
  { code: "de", label: "German" },
  { code: "ja", label: "Japanese" },
  { code: "ko", label: "Korean" },
  { code: "ru", label: "Russian" },
  { code: "it", label: "Italian" },
  { code: "sw", label: "Swahili" },
];

function MarketingAssetsPanel({ videoId, durationSeconds, defaultLanguage }: { videoId: string; durationSeconds: number; defaultLanguage?: string }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [language, setLanguage] = useState(defaultLanguage ?? "hi");
  const [expandedTrailer, setExpandedTrailer] = useState(false);

  const hours = durationSeconds / 3600;
  const willGenerateTrailerAndPoster = hours >= 1;

  const { data: assets, isLoading } = useGetVideoMarketingAssets(videoId, {
    query: {
      queryKey: getGetVideoMarketingAssetsQueryKey(videoId),
      refetchInterval: (q) => {
        const list = q.state.data as any[];
        if (Array.isArray(list) && list.some((a: any) => a.status === "generating")) return 3000;
        return false;
      },
    },
  });

  const generateMutation = useGenerateMarketingAssets({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getGetVideoMarketingAssetsQueryKey(videoId) });
        toast({ title: "Marketing assets generating", description: "Poster, thumbnail and trailer are being created in the background." });
      },
      onError: (e: any) => toast({ title: "Generation failed", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });

  const deleteMutation = useDeleteMarketingAsset({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetVideoMarketingAssetsQueryKey(videoId) });
        toast({ title: "Asset deleted" });
      },
      onError: (e: any) => toast({ title: "Delete failed", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });

  const regenerateMutation = useRegenerateMarketingAsset({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetVideoMarketingAssetsQueryKey(videoId) });
        toast({ title: "Regenerating asset…" });
      },
      onError: (e: any) => toast({ title: "Regenerate failed", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });

  const assetList = (assets as any[]) ?? [];
  const poster = assetList.find((a: any) => a.assetType === "poster");
  const thumbnail = assetList.find((a: any) => a.assetType === "thumbnail");
  const trailer = assetList.find((a: any) => a.assetType === "trailer");
  const hasAssets = assetList.length > 0;
  const anyGenerating = assetList.some((a: any) => a.status === "generating");

  return (
    <div>
      <div className="flex items-center justify-between gap-3 mb-5 flex-wrap">
        <div className="flex items-center gap-2">
          <Megaphone className="w-5 h-5 text-pink-400" />
          <h2 className="text-lg font-display font-bold tracking-tight">Marketing Assets</h2>
          {willGenerateTrailerAndPoster ? (
            <Badge variant="outline" className="text-xs text-pink-300 border-pink-500/30">Trailer + Poster + Thumbnail</Badge>
          ) : (
            <Badge variant="outline" className="text-xs">Thumbnail only</Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-36 h-8 text-xs bg-background/50 border-white/10">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGE_OPTIONS.map((l) => (
                <SelectItem key={l.code} value={l.code} className="text-xs">
                  {l.label} ({l.code})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            size="sm"
            onClick={() => generateMutation.mutate({ data: { videoId, language, forceRegenerate: hasAssets } })}
            disabled={generateMutation.isPending || anyGenerating}
            className="bg-pink-600 hover:bg-pink-500 text-white"
            data-testid="generate-marketing-btn"
          >
            {generateMutation.isPending || anyGenerating ? (
              <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Generating…</>
            ) : hasAssets ? (
              <><RefreshCw className="w-3.5 h-3.5 mr-1.5" />Regenerate</>
            ) : (
              <><Plus className="w-3.5 h-3.5 mr-1.5" />Generate</>
            )}
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-48 w-full rounded-xl" />)}
        </div>
      ) : !hasAssets ? (
        <Card className="bg-background/30 border-white/5 border-dashed">
          <CardContent className="p-10 text-center text-zinc-500">
            <Megaphone className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No marketing assets yet. Click Generate to create them automatically.</p>
            <p className="text-xs mt-1 text-zinc-600">
              {willGenerateTrailerAndPoster
                ? "This video (≥1 hour) will get a cinematic trailer, film poster, and YouTube thumbnail."
                : "This video (<1 hour) will get a professional YouTube thumbnail."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {/* Poster + Thumbnail side by side */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {poster && <AssetCard asset={poster} label="Film Poster" icon={<Ticket className="w-4 h-4" />} onDelete={() => deleteMutation.mutate({ id: poster.id })} onRegenerate={() => regenerateMutation.mutate({ id: poster.id })} />}
            {thumbnail && <AssetCard asset={thumbnail} label="YouTube Thumbnail" icon={<Monitor className="w-4 h-4" />} onDelete={() => deleteMutation.mutate({ id: thumbnail.id })} onRegenerate={() => regenerateMutation.mutate({ id: thumbnail.id })} />}
          </div>

          {/* Trailer */}
          {trailer && (
            <Card className="bg-background/40 border-white/10">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Play className="w-4 h-4 text-amber-400" />
                    <CardTitle className="text-base">Cinematic Trailer Script</CardTitle>
                    {trailer.status === "generating" && <Loader2 className="w-4 h-4 animate-spin text-zinc-400" />}
                    {trailer.status === "completed" && <Badge variant="outline" className="text-xs text-emerald-300 border-emerald-500/30">Ready</Badge>}
                    {trailer.status === "failed" && <Badge variant="outline" className="text-xs text-red-300 border-red-500/30">Failed</Badge>}
                  </div>
                  <div className="flex items-center gap-1.5">
                    {trailer.status !== "generating" && (
                      <Button size="sm" variant="ghost" onClick={() => regenerateMutation.mutate({ id: trailer.id })} className="h-7 text-xs">
                        <RefreshCw className="w-3.5 h-3.5 mr-1" />Re-gen
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate({ id: trailer.id })} className="h-7 text-xs text-red-400 hover:text-red-300">
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              {trailer.status === "completed" && trailer.trailerContent && (
                <CardContent className="space-y-3 pt-0">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    <MiniStat label="Duration" value={(trailer.trailerContent as any).totalDuration} icon={<Clock className="w-3.5 h-3.5" />} />
                    <MiniStat label="Scenes" value={(trailer.trailerContent as any).scenes?.length ?? 0} icon={<Film className="w-3.5 h-3.5" />} />
                    <MiniStat label="Language" value={trailer.language} icon={<Languages className="w-3.5 h-3.5" />} />
                    <MiniStat label="Music" value="Described" icon={<Music className="w-3.5 h-3.5" />} />
                  </div>

                  {(trailer.trailerContent as any).hook && (
                    <div className="bg-black/30 rounded-lg border border-white/5 p-3">
                      <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Opening Hook</div>
                      <div className="text-sm font-medium text-yellow-300">"{(trailer.trailerContent as any).hook}"</div>
                    </div>
                  )}

                  {(trailer.trailerContent as any).musicBed && (
                    <div className="text-xs text-zinc-400 flex items-start gap-1.5">
                      <Music className="w-3.5 h-3.5 mt-0.5 shrink-0 text-zinc-500" />
                      <span><span className="text-zinc-500">Music bed:</span> {(trailer.trailerContent as any).musicBed}</span>
                    </div>
                  )}

                  <button
                    onClick={() => setExpandedTrailer(!expandedTrailer)}
                    className="text-xs text-zinc-400 hover:text-white flex items-center gap-1"
                  >
                    {expandedTrailer ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    {expandedTrailer ? "Hide" : "Show"} {(trailer.trailerContent as any).scenes?.length ?? 0} scenes
                  </button>

                  {expandedTrailer && (
                    <div className="space-y-2">
                      {((trailer.trailerContent as any).scenes ?? []).map((scene: any) => (
                        <div key={scene.sceneNumber} className="rounded-lg border border-white/5 bg-black/20 p-3 text-xs">
                          <div className="flex items-center gap-2 mb-1.5">
                            <Badge variant="outline" className="text-[10px] py-0">{scene.duration}</Badge>
                            <span className="text-zinc-500 capitalize">{scene.transition}</span>
                          </div>
                          <p className="text-zinc-300 mb-1">{scene.description}</p>
                          {scene.textHook && (
                            <div className="text-yellow-300 font-medium bg-black/30 px-2 py-1 rounded mt-1">"{scene.textHook}"</div>
                          )}
                          <div className="text-zinc-600 mt-1 text-[10px] flex items-center gap-1">
                            <Music className="w-3 h-3" />{scene.musicCue}
                          </div>
                        </div>
                      ))}
                      {(trailer.trailerContent as any).closingTagline && (
                        <div className="bg-gradient-to-r from-yellow-500/10 to-pink-500/10 rounded-lg border border-yellow-500/20 p-3 text-center">
                          <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1">Closing Tagline</div>
                          <div className="text-sm font-bold text-white">"{(trailer.trailerContent as any).closingTagline}"</div>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              )}
              {trailer.status === "generating" && (
                <CardContent className="pt-0">
                  <div className="h-24 flex items-center justify-center gap-2 text-zinc-400 text-sm">
                    <Loader2 className="w-5 h-5 animate-spin" />Crafting your cinematic trailer script…
                  </div>
                </CardContent>
              )}
              {trailer.status === "failed" && (
                <CardContent className="pt-0">
                  <div className="text-xs text-red-400 bg-red-500/5 rounded p-3 border border-red-500/20">
                    {trailer.errorMessage || "Trailer generation failed. Click Re-gen to try again."}
                  </div>
                </CardContent>
              )}
            </Card>
          )}
        </div>
      )}
    </div>
  );
}

function AssetCard({ asset, label, icon, onDelete, onRegenerate }: { asset: any; label: string; icon: React.ReactNode; onDelete: () => void; onRegenerate: () => void }) {
  return (
    <Card className="bg-background/40 border-white/10 overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm font-medium">
            {icon}{label}
            {asset.status === "generating" && <Loader2 className="w-3.5 h-3.5 animate-spin text-zinc-400" />}
            {asset.status === "completed" && <Badge variant="outline" className="text-[10px] text-emerald-300 border-emerald-500/30">Ready</Badge>}
            {asset.status === "failed" && <Badge variant="outline" className="text-[10px] text-red-300 border-red-500/30">Failed</Badge>}
          </div>
          <div className="flex items-center gap-1">
            {asset.status !== "generating" && (
              <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={onRegenerate} title="Regenerate">
                <RefreshCw className="w-3.5 h-3.5" />
              </Button>
            )}
            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400 hover:text-red-300" onClick={onDelete} title="Delete">
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {asset.status === "completed" && asset.imageData ? (
          <div className="rounded-lg overflow-hidden border border-white/10">
            <img
              src={asset.imageData}
              alt={label}
              className="w-full h-auto object-cover max-h-72"
              data-testid={`asset-image-${asset.assetType}`}
            />
          </div>
        ) : asset.status === "generating" ? (
          <div className="h-44 flex items-center justify-center gap-2 text-zinc-500 text-sm bg-black/20 rounded-lg border border-white/5">
            <Loader2 className="w-5 h-5 animate-spin" />Generating image…
          </div>
        ) : asset.status === "failed" ? (
          <div className="h-20 flex items-start gap-2 text-xs text-red-400 bg-red-500/5 rounded-lg border border-red-500/20 p-3">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />{asset.errorMessage || "Generation failed. Click Re-gen to retry."}
          </div>
        ) : (
          <Skeleton className="h-44 w-full rounded-lg" />
        )}
      </CardContent>
    </Card>
  );
}

function MiniStat({ label, value, icon }: { label: string; value: any; icon: React.ReactNode }) {
  return (
    <div className="bg-black/20 rounded-lg p-2 border border-white/5">
      <div className="flex items-center gap-1.5 text-zinc-500 mb-0.5">{icon}<span className="text-[10px] uppercase tracking-wider">{label}</span></div>
      <div className="text-xs font-semibold text-zinc-200">{String(value ?? "—")}</div>
    </div>
  );
}
