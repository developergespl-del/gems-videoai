import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useListVideos, useDeleteVideo, useRetryVideo, getListVideosQueryKey, useGetMySpecialAccess } from "@workspace/api-client-react";
import { Film, Play, Search, Trash2, RefreshCw, Loader2, MoreVertical, Filter, AlertCircle, Rocket, Zap, Cpu, Activity, X, Lock } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import type { ListVideosStatus } from "@workspace/api-client-react";

export function VideosPage() {
  const [statusFilter, setStatusFilter] = useState<ListVideosStatus | "all">("all");
  const [searchInput, setSearchInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";
  const { data: accessData } = useGetMySpecialAccess({ query: { queryKey: ["getMySpecialAccess"], enabled: !isSuperAdmin } });
  const now = new Date();
  const entry = accessData?.entry;
  const isAccessLive = entry?.isActive && (!entry.expiresAt || new Date(entry.expiresAt) > now);
  const canGenerate = isSuperAdmin || (isAccessLive && entry?.canGenerateVideos);

  // Debounce search input by 350ms
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setSearchQuery(searchInput), 350);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [searchInput]);

  const queryParams = {
    status: statusFilter === "all" ? undefined : statusFilter,
    search: searchQuery.trim() || undefined,
  };

  const { data, isLoading } = useListVideos(queryParams, {
    query: {
      queryKey: getListVideosQueryKey(queryParams),
      // Auto-refresh every 5s when there are active processing/pending videos
      refetchInterval: (q) => {
        const vids = (q.state.data as any)?.videos as any[] | undefined;
        if (!vids) return false;
        const hasActive = vids.some((v) => v.status === "processing" || v.status === "pending");
        return hasActive ? 5000 : false;
      },
    },
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteVideo = useDeleteVideo();
  const retryVideo = useRetryVideo();

  const handleDelete = async (id: string) => {
    try {
      await deleteVideo.mutateAsync({ id });
      toast({ title: "Video deleted successfully" });
      queryClient.invalidateQueries({ queryKey: getListVideosQueryKey() });
    } catch (err: any) {
      toast({ title: "Failed to delete video", description: err.message, variant: "destructive" });
    }
  };

  const handleRetry = async (id: string) => {
    try {
      await retryVideo.mutateAsync({ id });
      toast({ title: "Video queued for retry" });
      queryClient.invalidateQueries({ queryKey: getListVideosQueryKey() });
    } catch (err: any) {
      toast({ title: "Failed to retry video", description: err.message, variant: "destructive" });
    }
  };

  const videos = data?.videos || [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight">My Videos</h1>
          <p className="text-muted-foreground mt-1">Manage and view your cinematic outputs.</p>
        </div>
        {canGenerate ? (
          <Link href="/videos/new">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-[0_0_20px_-5px_rgba(234,179,8,0.4)]">
              <Film className="w-4 h-4 mr-2" />
              New Production
            </Button>
          </Link>
        ) : (
          <Link href="/videos/new">
            <Button variant="outline" className="border-white/10 text-zinc-400 cursor-pointer" title="Contact Super Admin for access">
              <Lock className="w-4 h-4 mr-2" />
              New Production
            </Button>
          </Link>
        )}
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between bg-card p-4 rounded-lg border border-white/5">
        <div className="relative w-full sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search videos..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pl-9 pr-8 bg-background/50 border-white/10"
          />
          {searchInput && (
            <button
              onClick={() => setSearchInput("")}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-muted-foreground hidden sm:block" />
          <Select value={statusFilter} onValueChange={(val: any) => setStatusFilter(val)}>
            <SelectTrigger className="w-full sm:w-[180px] bg-background/50 border-white/10">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="processing">Processing</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="rounded-xl overflow-hidden border border-white/5 bg-card">
              <Skeleton className="w-full aspect-video" />
              <div className="p-4 space-y-3">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="text-center py-20 bg-card rounded-xl border border-white/5">
          <Film className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
          <h3 className="text-xl font-bold mb-2">No videos found</h3>
          <p className="text-muted-foreground mb-6">Create your first cinematic masterpiece.</p>
          <Link href="/videos/new">
            <Button>Start Creating</Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {videos.map((video, index) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              key={video.id}
              className="group rounded-xl overflow-hidden border border-white/5 bg-card hover:border-primary/30 transition-colors relative"
            >
              {/* Thumbnail / Status Area */}
              <div className="aspect-video bg-zinc-900 relative border-b border-white/5">
                {video.status === "completed" && video.thumbnailUrl ? (
                  <>
                    <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Link href={`/videos/${video.id}`}>
                        <Button variant="secondary" size="icon" className="rounded-full w-12 h-12 bg-white/20 hover:bg-primary hover:text-primary-foreground backdrop-blur-sm border-none">
                          <Play className="w-6 h-6 ml-1" />
                        </Button>
                      </Link>
                    </div>
                  </>
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground bg-gradient-to-br from-zinc-900 to-zinc-950">
                    {video.status === "processing" ? (
                      <>
                        <Loader2 className="w-8 h-8 animate-spin mb-3 text-blue-500" />
                        <div className="text-sm font-medium">Rendering ({video.progress}%)</div>
                        {(video as any).sceneCount > 0 && (
                          <div className="text-xs text-blue-400/70 mt-1">{(video as any).scenesCompleted}/{(video as any).sceneCount} scenes</div>
                        )}
                        {(video as any).queuePosition > 0 && (
                          <div className="text-xs text-amber-400/70 mt-1">Queue #{(video as any).queuePosition}</div>
                        )}
                      </>
                    ) : video.status === "failed" ? (
                      <>
                        <AlertCircle className="w-8 h-8 mb-3 text-destructive" />
                        <div className="text-sm font-medium">Render Failed</div>
                      </>
                    ) : (
                      <>
                        <Film className="w-8 h-8 mb-3 opacity-50" />
                        <div className="text-sm font-medium">Queued</div>
                      </>
                    )}
                  </div>
                )}
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  <Badge variant="secondary" className="bg-black/60 backdrop-blur-md border-white/10 uppercase tracking-wider text-[10px]">
                    {video.style}
                  </Badge>
                  <Badge variant="secondary" className="bg-black/60 backdrop-blur-md border-white/10 text-[10px]">
                    {Math.floor(video.durationSeconds / 60)}m {video.durationSeconds % 60}s
                  </Badge>
                </div>
                {/* Priority + GPU badges */}
                <div className="absolute top-3 right-3 flex flex-col gap-1.5 items-end">
                  {(video as any).priority === "enterprise" && (
                    <Badge className="bg-amber-500/80 text-amber-950 border-0 text-[10px] gap-1 px-1.5 py-0.5 font-bold backdrop-blur-sm">
                      <Rocket className="w-2.5 h-2.5" />ENTERPRISE
                    </Badge>
                  )}
                  {(video as any).priority === "paid" && (
                    <Badge className="bg-purple-500/80 text-white border-0 text-[10px] gap-1 px-1.5 py-0.5 font-bold backdrop-blur-sm">
                      <Zap className="w-2.5 h-2.5" />PAID
                    </Badge>
                  )}
                  {(video as any).workerType === "gpu" && (
                    <Badge className="bg-emerald-500/70 text-emerald-950 border-0 text-[10px] gap-1 px-1.5 py-0.5 font-bold backdrop-blur-sm">
                      <Activity className="w-2.5 h-2.5" />GPU
                    </Badge>
                  )}
                </div>
              </div>

              {/* Details Area */}
              <div className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <Link href={`/videos/${video.id}`} className="font-bold text-lg hover:text-primary transition-colors truncate block">
                      {video.title}
                    </Link>
                    <div className="text-xs text-muted-foreground mt-1">
                      {new Date(video.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 bg-card border-white/10">
                      <Link href={`/videos/${video.id}`}>
                        <DropdownMenuItem className="cursor-pointer">
                          View Details
                        </DropdownMenuItem>
                      </Link>
                      
                      {video.status === "failed" && (
                        <DropdownMenuItem className="cursor-pointer" onClick={() => handleRetry(video.id)}>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          Retry Render
                        </DropdownMenuItem>
                      )}
                      
                      <DropdownMenuSeparator className="bg-white/10" />
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:bg-destructive/10 cursor-pointer">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Video
                          </DropdownMenuItem>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="bg-card border-white/10">
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete {video.title}?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action cannot be undone. This will permanently delete your cinematic output and free up storage space.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="bg-transparent border-white/10 hover:bg-white/5">Cancel</AlertDialogCancel>
                            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => handleDelete(video.id)}>
                              Delete Permanently
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
              
              {/* Progress bar overlay for processing */}
              {video.status === "processing" && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-zinc-800">
                  <div 
                    className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)] transition-all duration-1000 ease-in-out" 
                    style={{ width: `${video.progress}%` }} 
                  />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
