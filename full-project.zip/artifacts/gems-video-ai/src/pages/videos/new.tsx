import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Film, Image as ImageIcon, FileText, Type, Loader2, Clock, Sparkles,
  Clapperboard, MonitorPlay, Palette, Volume2, Download, CheckSquare,
  Lock, ShieldOff, Zap, Star, User, Plus, X, ChevronDown,
} from "lucide-react";
import { useCreateVideo, useListProjects, useGetMySpecialAccess, useListCharacters } from "@workspace/api-client-react";
import type { CreateVideoBodyInputType, CreateVideoBodyStyle } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const ASPECT_RATIOS = [
  { value: "16:9", label: "16:9", desc: "Widescreen", w: 16, h: 9 },
  { value: "9:16", label: "9:16", desc: "Portrait", w: 9, h: 16 },
  { value: "21:9", label: "21:9", desc: "Ultra Wide", w: 21, h: 9 },
  { value: "2.39:1", label: "2.39:1", desc: "Anamorphic", w: 2.39, h: 1 },
] as const;

const RESOLUTIONS = [
  { value: "1080p", label: "1080p", sub: "Full HD" },
  { value: "2K", label: "2K", sub: "2048×1080" },
  { value: "4K", label: "4K", sub: "Cinema", cinema: true },
  { value: "8K", label: "8K", sub: "Ultra Cinema", cinema: true },
] as const;

const COLOR_GRADES = [
  { value: "natural", label: "Natural", desc: "True-to-life balance", swatch: "from-amber-100 to-sky-200" },
  { value: "warm", label: "Warm", desc: "Golden analog tones", swatch: "from-orange-300 to-yellow-200" },
  { value: "cold", label: "Cold", desc: "Clinical blues", swatch: "from-blue-300 to-cyan-100" },
  { value: "noir", label: "Noir", desc: "Deep blacks, low-key", swatch: "from-gray-900 to-gray-600" },
  { value: "vibrant", label: "Vibrant", desc: "Punchy saturation", swatch: "from-pink-400 to-purple-400" },
  { value: "indian-vivid", label: "Indian Vivid", desc: "Jewel tones, Bollywood", swatch: "from-rose-500 to-yellow-400" },
] as const;

const EXPORT_FORMATS = [
  { value: "youtube", label: "YouTube", desc: "H.264 / H.265" },
  { value: "instagram", label: "Instagram", desc: "MP4 1:1 / 4:5 / 9:16" },
  { value: "dcp", label: "DCP", desc: "Digital Cinema Package" },
  { value: "prores", label: "ProRes", desc: "Apple ProRes 4444" },
  { value: "raw", label: "RAW", desc: "Uncompressed frames" },
  { value: "hls", label: "HLS Stream", desc: "Adaptive bitrate" },
] as const;

const createVideoSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  inputType: z.enum(["story", "script", "image"] as const),
  inputContent: z.string().min(1, "Content is required"),
  style: z.enum(["cinematic", "documentary", "dramatic", "action", "romantic", "horror", "comedy"] as const),
  durationSeconds: z.number().min(10).max(10800),
  projectId: z.string().optional(),
  // Cinema Output
  aspectRatio: z.enum(["16:9", "9:16", "21:9", "2.39:1"]).default("16:9"),
  resolution: z.enum(["1080p", "2K", "4K", "8K"]).default("1080p"),
  colorGrade: z.enum(["natural", "warm", "cold", "noir", "vibrant", "indian-vivid"]).default("natural"),
  filmGrain: z.boolean().default(false),
  depthOfField: z.boolean().default(true),
  audioMastering: z.enum(["stereo", "surround-ready"]).default("stereo"),
  exportFormats: z.array(z.string()).min(1, "Select at least one export format").default(["youtube"]),
});

type ProductionMode = "default" | "cinema";

const CINEMA_PRESETS = {
  aspectRatio: "21:9" as const,
  resolution: "4K" as const,
  colorGrade: "natural" as const,
  filmGrain: true,
  depthOfField: true,
  audioMastering: "surround-ready" as const,
  exportFormats: ["youtube", "dcp", "prores"],
};

const DEFAULT_PRESETS = {
  aspectRatio: "16:9" as const,
  resolution: "1080p" as const,
  colorGrade: "natural" as const,
  filmGrain: false,
  depthOfField: true,
  audioMastering: "stereo" as const,
  exportFormats: ["youtube"],
};

type CharacterMapping = { scriptName: string; characterId: string };

export function NewVideoPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [productionMode, setProductionMode] = useState<ProductionMode>("default");
  const [characterMappings, setCharacterMappings] = useState<CharacterMapping[]>([]);
  const [newScriptName, setNewScriptName] = useState("");
  const [newCharacterId, setNewCharacterId] = useState("");
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";

  const { data: accessData, isLoading: isAccessLoading } = useGetMySpecialAccess({
    query: { queryKey: ["getMySpecialAccess"], enabled: !isSuperAdmin },
  });

  const now = new Date();
  const entry = accessData?.entry;
  const isAccessLive = entry?.isActive && (!entry.expiresAt || new Date(entry.expiresAt) > now);
  const canGenerate = isSuperAdmin || (isAccessLive && entry?.canGenerateVideos);
  const canCinema = isSuperAdmin || (isAccessLive && entry?.canCinemaMode === true);
  const canUseCharacterIdentity = isSuperAdmin || (isAccessLive && (entry as any)?.canUseCharacterIdentity === true);

  const createVideo = useCreateVideo();
  const { data: projectsData } = useListProjects();
  const projects = projectsData?.projects || [];

  const { data: charactersData } = useListCharacters({
    query: { queryKey: ["listCharacters"], enabled: canUseCharacterIdentity },
  });
  const myCharacters = (charactersData?.characters ?? []).filter((c: any) => c.status === "ready" || c.frontFaceUrl);

  const form = useForm<z.infer<typeof createVideoSchema>>({
    resolver: zodResolver(createVideoSchema),
    defaultValues: {
      title: "",
      description: "",
      inputType: "story",
      inputContent: "",
      style: "cinematic",
      durationSeconds: 60,
      aspectRatio: "16:9",
      resolution: "1080p",
      colorGrade: "natural",
      filmGrain: false,
      depthOfField: true,
      audioMastering: "stereo",
      exportFormats: ["youtube"],
    },
  });

  const inputType = form.watch("inputType");
  const duration = form.watch("durationSeconds");
  const resolution = form.watch("resolution");
  const exportFormats = form.watch("exportFormats");
  const isCinemaMode = productionMode === "cinema" || resolution === "4K" || resolution === "8K";

  const switchMode = (mode: ProductionMode) => {
    setProductionMode(mode);
    const presets = mode === "cinema" ? CINEMA_PRESETS : DEFAULT_PRESETS;
    form.setValue("aspectRatio", presets.aspectRatio, { shouldValidate: true });
    form.setValue("resolution", presets.resolution, { shouldValidate: true });
    form.setValue("colorGrade", presets.colorGrade, { shouldValidate: true });
    form.setValue("filmGrain", presets.filmGrain, { shouldValidate: true });
    form.setValue("depthOfField", presets.depthOfField, { shouldValidate: true });
    form.setValue("audioMastering", presets.audioMastering, { shouldValidate: true });
    form.setValue("exportFormats", presets.exportFormats, { shouldValidate: true });
  };

  const toggleExportFormat = (fmt: string) => {
    const current = form.getValues("exportFormats");
    if (current.includes(fmt)) {
      if (current.length === 1) return;
      form.setValue("exportFormats", current.filter((f) => f !== fmt), { shouldValidate: true });
    } else {
      form.setValue("exportFormats", [...current, fmt], { shouldValidate: true });
    }
  };

  const onSubmit = async (data: z.infer<typeof createVideoSchema>) => {
    setIsSubmitting(true);
    try {
      const result = await createVideo.mutateAsync({
        data: {
          title: data.title,
          description: data.description,
          inputType: data.inputType as CreateVideoBodyInputType,
          inputContent: data.inputContent,
          style: data.style as CreateVideoBodyStyle,
          durationSeconds: data.durationSeconds,
          projectId: data.projectId && data.projectId !== "none" ? data.projectId : undefined,
          aspectRatio: data.aspectRatio,
          resolution: data.resolution,
          colorGrade: data.colorGrade,
          filmGrain: data.filmGrain,
          depthOfField: data.depthOfField,
          audioMastering: data.audioMastering,
          exportFormats: data.exportFormats,
          characterMappings: characterMappings.length > 0 ? characterMappings : undefined,
        } as any,
      });
      toast({ title: "Production started successfully!" });
      setLocation(`/videos/${result.id}`);
    } catch (err: any) {
      toast({ title: "Failed to start production", description: err.message, variant: "destructive" });
      setIsSubmitting(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m ${s}s`;
  };

  if (!isSuperAdmin && isAccessLoading) {
    return (
      <div className="max-w-4xl mx-auto flex items-center justify-center py-32">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!canGenerate) {
    return (
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight">New Production</h1>
          <p className="text-muted-foreground mt-1">Configure your cinematic parameters and initialize rendering.</p>
        </div>
        <div className="flex flex-col items-center justify-center py-24 text-center bg-card rounded-2xl border border-white/5 shadow-2xl">
          <div className="w-20 h-20 rounded-full bg-zinc-800/60 flex items-center justify-center mb-6 ring-1 ring-white/10">
            <ShieldOff className="w-9 h-9 text-zinc-500" />
          </div>
          <h2 className="text-2xl font-bold mb-3 text-zinc-100">Access Restricted</h2>
          <p className="text-muted-foreground max-w-md mb-2">
            Video generation permission has not been granted to your account.
          </p>
          <p className="text-sm text-zinc-500 max-w-sm mb-8">
            Contact your Super Admin to enable video generation access for your account.
          </p>
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-zinc-800/50 border border-white/5 text-zinc-400 text-sm">
            <Lock className="w-4 h-4" />
            <span>No Permission &mdash; No Access</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold tracking-tight">New Production</h1>
        <p className="text-muted-foreground mt-1">Configure your cinematic parameters and initialize rendering.</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">

          {/* ── Production Mode Selector ── */}
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => switchMode("default")}
              className={cn(
                "relative flex flex-col items-start gap-2 p-5 rounded-2xl border-2 transition-all text-left",
                productionMode === "default"
                  ? "border-primary bg-primary/10 shadow-[0_0_30px_-8px_rgba(234,179,8,0.35)]"
                  : "border-white/10 bg-card hover:bg-white/5 hover:border-white/20"
              )}
            >
              <div className="flex items-center gap-2.5">
                <div className={cn(
                  "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors",
                  productionMode === "default" ? "border-primary bg-primary" : "border-white/30"
                )}>
                  {productionMode === "default" && <div className="w-2 h-2 rounded-full bg-black" />}
                </div>
                <span className={cn("font-bold text-base", productionMode === "default" ? "text-primary" : "text-foreground")}>
                  Default
                  <span className="ml-1.5 text-[11px] font-normal text-muted-foreground">(Up to 4K)</span>
                </span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed pl-7">
                16:9 · 1080p · Stereo audio. Fast render, clean output for standard digital distribution.
              </p>
              <div className="pl-7 flex gap-1.5 flex-wrap">
                {["YouTube", "Instagram", "Stereo"].map(tag => (
                  <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-muted-foreground">{tag}</span>
                ))}
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                if (!canCinema) {
                  toast({ title: "Cinema Mode Locked", description: "Contact support or upgrade your account to unlock 4K–8K cinema output.", variant: "destructive" });
                  return;
                }
                switchMode("cinema");
              }}
              className={cn(
                "relative flex flex-col items-start gap-2 p-5 rounded-2xl border-2 transition-all text-left",
                !canCinema
                  ? "border-white/10 bg-card cursor-not-allowed opacity-70"
                  : productionMode === "cinema"
                    ? "border-primary bg-primary/10 shadow-[0_0_30px_-8px_rgba(234,179,8,0.5)]"
                    : "border-white/10 bg-card hover:bg-white/5 hover:border-white/20"
              )}
            >
              {/* Top-right badge: Active / Available / Locked */}
              <div className="absolute -top-3 right-4">
                {productionMode === "cinema" ? (
                  <span className="text-[10px] font-black uppercase tracking-widest bg-primary text-black px-2.5 py-1 rounded-full flex items-center gap-1">
                    <Star className="w-2.5 h-2.5" /> Cinema Grade
                  </span>
                ) : canCinema ? (
                  <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-1 rounded-full">
                    Available
                  </span>
                ) : (
                  <span className="text-[10px] font-semibold bg-white/8 text-muted-foreground border border-white/15 px-2.5 py-1 rounded-full flex items-center gap-1">
                    <Lock className="w-2.5 h-2.5" /> Locked
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2.5">
                <div className={cn(
                  "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors",
                  productionMode === "cinema" ? "border-primary bg-primary" : "border-white/30"
                )}>
                  {productionMode === "cinema" && <div className="w-2 h-2 rounded-full bg-black" />}
                </div>
                <span className={cn("font-bold text-base flex items-center gap-1.5", productionMode === "cinema" ? "text-primary" : "text-foreground")}>
                  Cinema
                  <Film className="w-4 h-4" />
                  <span className="ml-0.5 text-[11px] font-normal text-muted-foreground">(4K–8K)</span>
                </span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed pl-7">
                21:9 anamorphic · 4K minimum · Surround audio. Suitable for cinema hall, OTT, and film festivals.
              </p>
              <div className="pl-7 flex gap-1.5 flex-wrap">
                {["4K+", "21:9", "DCP", "ProRes", "Surround"].map(tag => (
                  <span key={tag} className={cn(
                    "text-[10px] px-2 py-0.5 rounded-full border",
                    productionMode === "cinema" ? "bg-primary/10 border-primary/30 text-primary" : "bg-white/5 border-white/10 text-muted-foreground"
                  )}>{tag}</span>
                ))}
              </div>
            </button>
          </div>

          {/* Cinema mode indicator banner */}
          {productionMode === "cinema" && (
            <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-primary/8 border border-primary/25">
              <Zap className="w-4 h-4 text-primary flex-shrink-0" />
              <p className="text-sm text-primary/90">
                <span className="font-bold">Cinema Mode active.</span> All cinema-grade settings are pre-configured below.
                Minimum 4K · Theatrical color science · DCP + ProRes export enabled.
              </p>
            </div>
          )}

          {/* Basic Metadata */}
          <Card className="bg-card border-white/5 shadow-2xl">
            <CardHeader>
              <CardTitle>Basic Metadata</CardTitle>
              <CardDescription>Identity and organization for your video</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="E.g. Neon Horizon Trailer" {...field} className="bg-background/50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="projectId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project (Optional)</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background/50">
                            <SelectValue placeholder="Select a project" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">No Project</SelectItem>
                          {projects.map((p) => (
                            <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Brief notes or synopsis..." {...field} className="bg-background/50 resize-none h-20" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Source Material */}
          <Card className="bg-card border-white/5 shadow-2xl">
            <CardHeader>
              <CardTitle>Source Material</CardTitle>
              <CardDescription>What will the AI base the video on?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="inputType"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Input Type</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="grid grid-cols-1 md:grid-cols-3 gap-4"
                      >
                        <FormItem>
                          <FormControl>
                            <RadioGroupItem value="story" className="peer sr-only" />
                          </FormControl>
                          <FormLabel className="flex flex-col items-center justify-center p-4 border border-white/10 rounded-xl cursor-pointer bg-background/50 hover:bg-white/5 peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 transition-all">
                            <Type className="w-6 h-6 mb-2 text-primary" />
                            <span className="font-semibold">Story Prompt</span>
                            <span className="text-xs text-muted-foreground mt-1 text-center">Narrative text prompt</span>
                          </FormLabel>
                        </FormItem>
                        <FormItem>
                          <FormControl>
                            <RadioGroupItem value="script" className="peer sr-only" />
                          </FormControl>
                          <FormLabel className="flex flex-col items-center justify-center p-4 border border-white/10 rounded-xl cursor-pointer bg-background/50 hover:bg-white/5 peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 transition-all">
                            <FileText className="w-6 h-6 mb-2 text-primary" />
                            <span className="font-semibold">Screenplay</span>
                            <span className="text-xs text-muted-foreground mt-1 text-center">Detailed scene script</span>
                          </FormLabel>
                        </FormItem>
                        <FormItem>
                          <FormControl>
                            <RadioGroupItem value="image" className="peer sr-only" />
                          </FormControl>
                          <FormLabel className="flex flex-col items-center justify-center p-4 border border-white/10 rounded-xl cursor-pointer bg-background/50 hover:bg-white/5 peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 transition-all">
                            <ImageIcon className="w-6 h-6 mb-2 text-primary" />
                            <span className="font-semibold">Image URL</span>
                            <span className="text-xs text-muted-foreground mt-1 text-center">Animate an existing image</span>
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="inputContent"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    <FormControl>
                      {inputType === "image" ? (
                        <Input placeholder="https://example.com/image.jpg" {...field} className="bg-background/50" />
                      ) : (
                        <Textarea
                          placeholder={inputType === "story" ? "Describe your scene in detail..." : "INT. NEON CITY - NIGHT\n\nRain falls on..."}
                          {...field}
                          className="bg-background/50 min-h-[150px]"
                        />
                      )}
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Character Identity Mapping — only shown if user has access */}
          {canUseCharacterIdentity && (
            <Card className="bg-card border-white/5 shadow-2xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-primary" />
                  Character Identity
                  <span className="ml-1 text-xs font-normal text-primary bg-primary/10 border border-primary/20 px-2 py-0.5 rounded-full">Optional</span>
                </CardTitle>
                <CardDescription>
                  Map character names from your script to saved characters for face &amp; voice personalization.
                  Leave empty to use AI-generated faces.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Existing mappings */}
                {characterMappings.length > 0 && (
                  <div className="space-y-2">
                    {characterMappings.map((m, i) => {
                      const char = myCharacters.find((c: any) => c.id === m.characterId);
                      return (
                        <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-background/50 border border-white/10">
                          <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center overflow-hidden flex-shrink-0">
                            {char?.frontFaceUrl ? (
                              <img src={char.frontFaceUrl} alt={char.name} className="w-full h-full object-cover" />
                            ) : (
                              <User className="w-4 h-4 text-primary" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <span className="text-xs text-zinc-400">Script character: </span>
                            <span className="text-sm font-semibold">{m.scriptName}</span>
                            <span className="text-xs text-zinc-400 mx-2">→</span>
                            <span className="text-sm text-primary">{char?.name ?? m.characterId}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setCharacterMappings(prev => prev.filter((_, idx) => idx !== i))}
                            className="p-1.5 rounded-md hover:bg-red-500/10 text-zinc-500 hover:text-red-400 transition-colors"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Add new mapping */}
                {myCharacters.length === 0 ? (
                  <div className="flex items-center gap-3 p-4 rounded-lg bg-background/50 border border-white/10 text-sm text-zinc-500">
                    <User className="w-4 h-4 flex-shrink-0" />
                    No ready characters yet. Go to{" "}
                    <a href="/characters" className="text-primary underline underline-offset-2">Character Studio</a>{" "}
                    to create and train characters first.
                  </div>
                ) : (
                  <div className="flex items-end gap-2 p-3 rounded-lg bg-background/50 border border-dashed border-white/10">
                    <div className="flex-1 min-w-0">
                      <label className="text-xs text-zinc-400 mb-1 block">Character name in script</label>
                      <Input
                        value={newScriptName}
                        onChange={(e) => setNewScriptName(e.target.value)}
                        placeholder="e.g. Detective Maya, John, Hero"
                        className="bg-background/50 h-9"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <label className="text-xs text-zinc-400 mb-1 block">Map to saved character</label>
                      <select
                        value={newCharacterId}
                        onChange={(e) => setNewCharacterId(e.target.value)}
                        className="w-full h-9 rounded-md border border-white/10 bg-background/50 text-sm px-2 text-foreground"
                      >
                        <option value="">Select character…</option>
                        {myCharacters.map((c: any) => (
                          <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-9 px-3 border-white/10 gap-1.5 flex-shrink-0"
                      disabled={!newScriptName.trim() || !newCharacterId}
                      onClick={() => {
                        if (!newScriptName.trim() || !newCharacterId) return;
                        if (characterMappings.some(m => m.scriptName.toLowerCase() === newScriptName.trim().toLowerCase())) {
                          toast({ title: "Duplicate script character name", variant: "destructive" });
                          return;
                        }
                        setCharacterMappings(prev => [...prev, { scriptName: newScriptName.trim(), characterId: newCharacterId }]);
                        setNewScriptName("");
                        setNewCharacterId("");
                      }}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add
                    </Button>
                  </div>
                )}

                {characterMappings.length > 0 && (
                  <p className="text-xs text-zinc-500">
                    AI will use the face and voice of your saved characters for these roles. All other characters will be AI-generated.
                  </p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Cinematography */}
          <Card className="bg-card border-white/5 shadow-2xl">
            <CardHeader>
              <CardTitle>Cinematography</CardTitle>
              <CardDescription>Visual style and length</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              <FormField
                control={form.control}
                name="style"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Visual Style</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-background/50">
                          <SelectValue placeholder="Select a style" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="cinematic">Cinematic - High contrast, anamorphic lenses</SelectItem>
                        <SelectItem value="documentary">Documentary - Handheld, realistic grading</SelectItem>
                        <SelectItem value="dramatic">Dramatic - Moody lighting, slow movement</SelectItem>
                        <SelectItem value="action">Action - High shutter speed, dynamic</SelectItem>
                        <SelectItem value="romantic">Romantic - Soft focus, warm palette</SelectItem>
                        <SelectItem value="horror">Horror - Under-lit, desaturated, tense</SelectItem>
                        <SelectItem value="comedy">Comedy - Bright, high key lighting, sharp</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="durationSeconds"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center justify-between">
                      <FormLabel>Duration</FormLabel>
                      <span className="text-sm font-mono font-bold text-primary">{formatDuration(duration)}</span>
                    </div>
                    <FormControl>
                      <div className="space-y-4 pt-2">
                        <div className="flex items-center gap-4">
                          <Clock className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                          <Slider
                            min={10}
                            max={10800}
                            step={10}
                            defaultValue={[field.value]}
                            onValueChange={(vals) => field.onChange(vals[0])}
                            className="flex-1"
                          />
                        </div>
                        {/* Quick presets */}
                        <div className="flex flex-wrap gap-1.5">
                          {[
                            { label: "10s", v: 10 }, { label: "30s", v: 30 },
                            { label: "1m", v: 60 }, { label: "2m", v: 120 },
                            { label: "5m", v: 300 }, { label: "10m", v: 600 },
                            { label: "30m", v: 1800 }, { label: "1h", v: 3600 },
                            { label: "1.5h", v: 5400 }, { label: "2h", v: 7200 },
                            { label: "3h", v: 10800 },
                          ].map(({ label, v }) => (
                            <button
                              key={v}
                              type="button"
                              onClick={() => field.onChange(v)}
                              className={cn(
                                "px-2.5 py-1 rounded-md text-xs font-medium border transition-colors",
                                field.value === v
                                  ? "bg-primary/20 border-primary/50 text-primary"
                                  : "bg-background/50 border-white/10 text-muted-foreground hover:border-white/20 hover:text-foreground"
                              )}
                            >
                              {label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </FormControl>
                    <FormDescription>
                      Min 10 seconds · Max 3 hours. Longer videos take significantly more time to render.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Cinema Output — shown for both modes, but with different prominence */}
          <Card className={cn(
            "shadow-2xl transition-all",
            productionMode === "cinema"
              ? "bg-card border-primary/25 shadow-[0_0_40px_-10px_rgba(234,179,8,0.2)]"
              : "bg-card border-white/5"
          )}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Clapperboard className={cn("w-5 h-5", productionMode === "cinema" ? "text-primary" : "text-muted-foreground")} />
                    {productionMode === "cinema" ? "Cinema Output" : "Output Settings"}
                  </CardTitle>
                  <CardDescription>
                    {productionMode === "cinema"
                      ? "Theatrical aspect ratio, 4K+ resolution, color science, and cinema export formats"
                      : "Aspect ratio, resolution, and export configuration"}
                  </CardDescription>
                </div>
                {isCinemaMode && (
                  <Badge className="bg-primary/20 text-primary border-primary/30 font-semibold px-3 py-1 text-sm">
                    <Film className="w-3.5 h-3.5 mr-1.5" />
                    Cinema Mode
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-8">

              {/* Aspect Ratio */}
              <FormField
                control={form.control}
                name="aspectRatio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Aspect Ratio</FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {ASPECT_RATIOS.map((ar) => {
                          const scale = 60;
                          const pw = ar.value === "9:16" ? scale * 0.5625 : ar.value === "21:9" ? scale * (21/9) : ar.value === "2.39:1" ? scale * 2.39 : scale;
                          const ph = ar.value === "9:16" ? scale : ar.value === "21:9" ? scale * (9/21) : ar.value === "2.39:1" ? scale * (1/2.39) : scale * (9/16);
                          const isSelected = field.value === ar.value;
                          return (
                            <button
                              key={ar.value}
                              type="button"
                              onClick={() => field.onChange(ar.value)}
                              className={cn(
                                "flex flex-col items-center gap-2 p-3 rounded-xl border transition-all",
                                isSelected
                                  ? "border-primary bg-primary/10 shadow-[0_0_15px_-5px_rgba(234,179,8,0.4)]"
                                  : "border-white/10 bg-background/50 hover:bg-white/5 hover:border-white/20"
                              )}
                            >
                              <div className="flex items-center justify-center h-12">
                                <div
                                  className={cn(
                                    "rounded-sm border-2 transition-colors",
                                    isSelected ? "border-primary bg-primary/20" : "border-muted-foreground/40 bg-muted/20"
                                  )}
                                  style={{
                                    width: `${Math.min(pw, 70)}px`,
                                    height: `${Math.min(ph, 48)}px`,
                                  }}
                                />
                              </div>
                              <span className="text-xs font-bold">{ar.label}</span>
                              <span className="text-[10px] text-muted-foreground">{ar.desc}</span>
                            </button>
                          );
                        })}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Resolution */}
              <FormField
                control={form.control}
                name="resolution"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <MonitorPlay className="w-4 h-4 text-muted-foreground" />
                      Resolution
                    </FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {RESOLUTIONS.map((res) => {
                          const isSelected = field.value === res.value;
                          return (
                            <button
                              key={res.value}
                              type="button"
                              onClick={() => field.onChange(res.value)}
                              className={cn(
                                "relative flex flex-col items-center gap-1 p-3 rounded-xl border transition-all",
                                isSelected
                                  ? "border-primary bg-primary/10 shadow-[0_0_15px_-5px_rgba(234,179,8,0.4)]"
                                  : "border-white/10 bg-background/50 hover:bg-white/5"
                              )}
                            >
                              {'cinema' in res && res.cinema && (
                                <span className="absolute -top-2 right-2 text-[9px] font-bold bg-primary text-black px-1.5 py-0.5 rounded-full uppercase tracking-wide">
                                  Cinema
                                </span>
                              )}
                              <span className={cn("text-xl font-display font-black", isSelected ? "text-primary" : "text-foreground")}>{res.label}</span>
                              <span className="text-[10px] text-muted-foreground">{res.sub}</span>
                            </button>
                          );
                        })}
                      </div>
                    </FormControl>
                    {isCinemaMode && (
                      <FormDescription className="text-primary/80">
                        Cinema Mode auto-enabled at {resolution}. AI will apply theatrical mastering directives to every scene.
                      </FormDescription>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Color Grade */}
              <FormField
                control={form.control}
                name="colorGrade"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Palette className="w-4 h-4 text-muted-foreground" />
                      Color Grade
                    </FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {COLOR_GRADES.map((cg) => {
                          const isSelected = field.value === cg.value;
                          return (
                            <button
                              key={cg.value}
                              type="button"
                              onClick={() => field.onChange(cg.value)}
                              className={cn(
                                "flex items-center gap-3 p-3 rounded-xl border transition-all text-left",
                                isSelected
                                  ? "border-primary bg-primary/10"
                                  : "border-white/10 bg-background/50 hover:bg-white/5"
                              )}
                            >
                              <div className={cn("w-8 h-8 rounded-lg bg-gradient-to-br flex-shrink-0", cg.swatch)} />
                              <div>
                                <div className="text-sm font-semibold">{cg.label}</div>
                                <div className="text-[10px] text-muted-foreground leading-tight">{cg.desc}</div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Toggles Row */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="filmGrain"
                  render={({ field }) => (
                    <FormItem className="flex items-center justify-between p-4 rounded-xl border border-white/10 bg-background/50">
                      <div>
                        <FormLabel className="text-sm font-semibold cursor-pointer">Film Grain</FormLabel>
                        <FormDescription className="text-[11px]">35mm analog texture</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="depthOfField"
                  render={({ field }) => (
                    <FormItem className="flex items-center justify-between p-4 rounded-xl border border-white/10 bg-background/50">
                      <div>
                        <FormLabel className="text-sm font-semibold cursor-pointer">Depth of Field</FormLabel>
                        <FormDescription className="text-[11px]">Rack focus / bokeh</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <div className={cn(
                  "flex items-center justify-between p-4 rounded-xl border",
                  isCinemaMode ? "border-primary/40 bg-primary/5" : "border-white/10 bg-background/50 opacity-50"
                )}>
                  <div>
                    <div className="text-sm font-semibold">Cinema Mode</div>
                    <div className="text-[11px] text-muted-foreground">Auto at 4K+</div>
                  </div>
                  <div className={cn(
                    "w-10 h-6 rounded-full flex items-center px-1 transition-colors",
                    isCinemaMode ? "bg-primary" : "bg-muted"
                  )}>
                    <div className={cn(
                      "w-4 h-4 rounded-full bg-white shadow-sm transition-transform",
                      isCinemaMode ? "translate-x-4" : "translate-x-0"
                    )} />
                  </div>
                </div>
              </div>

              {/* Audio Mastering */}
              <FormField
                control={form.control}
                name="audioMastering"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Volume2 className="w-4 h-4 text-muted-foreground" />
                      Audio Mastering
                    </FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { value: "stereo", label: "Stereo", desc: "Balanced L/R mix" },
                          { value: "surround-ready", label: "Surround Ready", desc: "5.1 / 7.1 spatial mix" },
                        ].map((opt) => {
                          const isSelected = field.value === opt.value;
                          return (
                            <button
                              key={opt.value}
                              type="button"
                              onClick={() => field.onChange(opt.value)}
                              className={cn(
                                "flex items-center gap-3 p-4 rounded-xl border transition-all text-left",
                                isSelected
                                  ? "border-primary bg-primary/10"
                                  : "border-white/10 bg-background/50 hover:bg-white/5"
                              )}
                            >
                              <Volume2 className={cn("w-5 h-5 flex-shrink-0", isSelected ? "text-primary" : "text-muted-foreground")} />
                              <div>
                                <div className="text-sm font-semibold">{opt.label}</div>
                                <div className="text-[11px] text-muted-foreground">{opt.desc}</div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Export Formats */}
              <FormField
                control={form.control}
                name="exportFormats"
                render={() => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Download className="w-4 h-4 text-muted-foreground" />
                      Export Formats
                    </FormLabel>
                    <FormControl>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {EXPORT_FORMATS.map((fmt) => {
                          const isSelected = exportFormats.includes(fmt.value);
                          return (
                            <button
                              key={fmt.value}
                              type="button"
                              onClick={() => toggleExportFormat(fmt.value)}
                              className={cn(
                                "flex items-center gap-3 p-3 rounded-xl border transition-all text-left",
                                isSelected
                                  ? "border-primary bg-primary/10"
                                  : "border-white/10 bg-background/50 hover:bg-white/5"
                              )}
                            >
                              <CheckSquare className={cn("w-4 h-4 flex-shrink-0", isSelected ? "text-primary" : "text-muted-foreground/40")} />
                              <div>
                                <div className="text-sm font-semibold">{fmt.label}</div>
                                <div className="text-[10px] text-muted-foreground">{fmt.desc}</div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

            </CardContent>
          </Card>

          <div className="flex items-center justify-between gap-4">
            <div className="text-xs text-muted-foreground">
              {productionMode === "cinema" ? (
                <span className="flex items-center gap-1.5 text-primary/70">
                  <Film className="w-3.5 h-3.5" />
                  Cinema mode · {form.watch("resolution")} · {form.watch("aspectRatio")} · {form.watch("audioMastering")}
                </span>
              ) : (
                <span className="flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5" />
                  Default mode · {form.watch("resolution")} · {form.watch("aspectRatio")}
                </span>
              )}
            </div>
            <div className="flex gap-3">
              <Link href="/videos">
                <Button variant="outline" type="button" disabled={isSubmitting} className="border-white/10">
                  Cancel
                </Button>
              </Link>
              <Button
                type="submit"
                disabled={isSubmitting}
                className={cn(
                  "font-bold px-8 transition-all",
                  productionMode === "cinema"
                    ? "bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_40px_-5px_rgba(234,179,8,0.7)]"
                    : "bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_-5px_rgba(234,179,8,0.4)]"
                )}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {productionMode === "cinema" ? "Mastering Cinema..." : "Initializing..."}
                  </>
                ) : productionMode === "cinema" ? (
                  <>
                    <Film className="w-4 h-4 mr-2" />
                    Generate Cinema Video
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Video
                  </>
                )}
              </Button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
