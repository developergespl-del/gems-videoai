import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListLanguages,
  usePurchaseLanguage,
  useListVideoPlans,
  useSubscribeVideoPlan,
  useGetMyVideoPlan,
  useGetCinemaPrice,
  usePurchaseCinemaMode,
  useGetMySpecialAccess,
  getListLanguagesQueryKey,
  getListVideoPlansQueryKey,
  getGetMyVideoPlanQueryKey,
  getGetMySpecialAccessQueryKey,
} from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Languages,
  Clapperboard,
  Sparkles,
  CheckCircle2,
  Lock,
  ShoppingBag,
  Crown,
  Zap,
  Star,
  Clock,
  Film,
  Globe,
  Check,
} from "lucide-react";

// ---------------------------------------------------------------------------
// Language Store Section
// ---------------------------------------------------------------------------
function LanguageStore() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: languages, isLoading } = useListLanguages();
  const purchase = usePurchaseLanguage();
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";

  const [buying, setBuying] = useState<string | null>(null);

  const handleBuy = async (id: string, name: string) => {
    setBuying(id);
    try {
      await purchase.mutateAsync({ id });
      toast({
        title: `${name} unlocked!`,
        description: "Language has been added to your account.",
      });
      queryClient.invalidateQueries({ queryKey: getListLanguagesQueryKey() });
    } catch (e: any) {
      toast({ title: "Purchase failed", description: e?.response?.data?.error ?? "Try again", variant: "destructive" });
    } finally {
      setBuying(null);
    }
  };

  const indian = (languages ?? []).filter((l) => l.region === "indian");
  const global_ = (languages ?? []).filter((l) => l.region === "global");

  const renderLangGroup = (title: string, icon: React.ReactNode, langs: typeof languages) => (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold text-white/60 flex items-center gap-2">
        {icon}{title}
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {langs?.map((lang) => {
          const owned = isSuperAdmin || lang.purchased || lang.isDefault;
          return (
            <Card key={lang.id} className={`bg-card border-white/5 transition-all ${!owned ? "hover:border-primary/30" : ""}`}>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="text-2xl">{lang.flag}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-medium text-sm">{lang.name}</span>
                    {lang.isDefault && <Badge className="bg-amber-500/10 text-amber-400 border-0 text-[10px] px-1.5">Free</Badge>}
                    {owned && !lang.isDefault && <Badge className="bg-green-500/10 text-green-400 border-0 text-[10px] px-1.5">Owned</Badge>}
                  </div>
                  <div className="text-xs text-white/40">{lang.nativeName} · {lang.dialects} dialects</div>
                </div>
                {!owned ? (
                  <Button
                    size="sm"
                    variant="outline"
                    className="shrink-0 border-primary/30 text-primary hover:bg-primary/10 text-xs"
                    onClick={() => handleBuy(lang.id, lang.name)}
                    disabled={buying === lang.id}
                  >
                    {buying === lang.id ? "..." : `$${lang.priceUsd}`}
                  </Button>
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );

  if (isLoading) {
    return <div className="space-y-3">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>;
  }

  return (
    <div className="space-y-8">
      {renderLangGroup("Indian Languages", <span>🇮🇳</span>, indian)}
      {renderLangGroup("Global Languages", <Globe className="w-4 h-4" />, global_)}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Video Plans Section
// ---------------------------------------------------------------------------
function VideoPlansSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: plans, isLoading: plansLoading } = useListVideoPlans();
  const { data: myPlan, isLoading: myPlanLoading } = useGetMyVideoPlan();
  const subscribe = useSubscribeVideoPlan();
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";

  const [buying, setBuying] = useState<string | null>(null);

  const handleSubscribe = async (id: string, name: string) => {
    setBuying(id);
    try {
      await subscribe.mutateAsync({ id });
      toast({
        title: `${name} plan activated!`,
        description: "Your video plan has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: getListVideoPlansQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetMyVideoPlanQueryKey() });
    } catch (e: any) {
      toast({ title: "Subscription failed", description: e?.response?.data?.error ?? "Try again", variant: "destructive" });
    } finally {
      setBuying(null);
    }
  };

  const PLAN_ICONS = [Film, Zap, Crown];
  const PLAN_GRADIENTS = [
    "from-slate-500/10 to-slate-600/5",
    "from-primary/10 to-primary/5",
    "from-amber-500/10 to-amber-600/5",
  ];
  const PLAN_BORDERS = ["border-white/5", "border-primary/30", "border-amber-500/20"];

  if (plansLoading || myPlanLoading) {
    return <div className="grid md:grid-cols-3 gap-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-72 w-full" />)}</div>;
  }

  return (
    <div className="space-y-6">
      {/* Super Admin unlimited banner */}
      {isSuperAdmin && (
        <div className="flex items-center gap-3 bg-gradient-to-r from-primary/10 to-amber-500/10 border border-primary/20 rounded-xl px-4 py-3">
          <Crown className="w-5 h-5 text-amber-400 shrink-0" />
          <div>
            <div className="text-sm font-semibold text-white">Super Admin — Unlimited Access</div>
            <div className="text-xs text-white/50">All plans are free and unrestricted. No quotas, no limits.</div>
          </div>
          <Badge className="ml-auto bg-amber-500/10 text-amber-400 border-amber-500/20 shrink-0">Owner</Badge>
        </div>
      )}

      {/* Current usage */}
      {!isSuperAdmin && myPlan && (
        <Card className="bg-card border-white/5">
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-sm font-medium">This Month's Usage</div>
                <div className="text-xs text-white/40">
                  {myPlan.videosThisMonth} of {myPlan.plan?.monthlyQuota ?? 3} videos used
                </div>
              </div>
              {myPlan.plan ? (
                <Badge className="bg-primary/10 text-primary border-0">{myPlan.plan.name} Plan</Badge>
              ) : (
                <Badge className="bg-white/5 text-white/60 border-0">Free Plan</Badge>
              )}
            </div>
            <Progress
              value={Math.min(100, ((myPlan.videosThisMonth) / (myPlan.plan?.monthlyQuota ?? 3)) * 100)}
              className="h-1.5"
            />
            {!myPlan.canCreate && (
              <p className="text-xs text-red-400 mt-2">{myPlan.limitReason}</p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Plan cards */}
      <div className="grid md:grid-cols-3 gap-4">
        {(plans ?? []).map((plan, idx) => {
          const PlanIcon = PLAN_ICONS[idx % 3];
          const isCurrentPlan = isSuperAdmin ? plan.isDefault : (plan.subscribed && !plan.isDefault);
          const isDefault = plan.isDefault;
          const isActive = isSuperAdmin ? true : plan.subscribed;

          return (
            <Card key={plan.id} className={`bg-gradient-to-br ${PLAN_GRADIENTS[idx % 3]} border ${PLAN_BORDERS[idx % 3]} relative`}>
              {idx === 1 && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-white border-0 px-3">Most Popular</Badge>
                </div>
              )}
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2 mb-1">
                  <PlanIcon className="w-4 h-4 text-primary" />
                  <CardTitle className="text-base">{plan.name}</CardTitle>
                </div>
                <div className="flex items-baseline gap-1">
                  {isSuperAdmin ? (
                    <span className="text-2xl font-bold text-white">Free</span>
                  ) : plan.priceUsd === 0 ? (
                    <span className="text-2xl font-bold text-white">Free</span>
                  ) : (
                    <>
                      <span className="text-2xl font-bold text-white">${plan.priceUsd}</span>
                      <span className="text-xs text-white/40">/month</span>
                    </>
                  )}
                </div>
                {plan.description && (
                  <CardDescription className="text-xs text-white/50">{plan.description}</CardDescription>
                )}
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {((plan.features as string[]) ?? []).map((f, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                      <Check className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <div className="text-xs text-white/40 space-y-1 border-t border-white/5 pt-3">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3 h-3" />
                    Max {plan.maxLengthSeconds >= 60 ? `${Math.round(plan.maxLengthSeconds / 60)} min` : `${plan.maxLengthSeconds}s`} per video
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Film className="w-3 h-3" />
                    {plan.monthlyQuota} videos/month
                  </div>
                </div>

                {isActive || isDefault ? (
                  <Button disabled className="w-full bg-green-500/10 text-green-400 border border-green-500/20 hover:bg-green-500/10">
                    <CheckCircle2 className="w-3.5 h-3.5 mr-2" />
                    {isSuperAdmin ? "Owner Access" : isDefault ? "Current Plan" : "Subscribed"}
                  </Button>
                ) : (
                  <Button
                    className="w-full"
                    variant={idx === 1 ? "default" : "outline"}
                    onClick={() => handleSubscribe(plan.id, plan.name)}
                    disabled={buying === plan.id}
                  >
                    {buying === plan.id ? "Processing..." : `Subscribe — $${plan.priceUsd}/mo`}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Cinema Mode Section
// ---------------------------------------------------------------------------
function CinemaModeSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: priceData, isLoading: priceLoading } = useGetCinemaPrice();
  const { data: specialAccess, isLoading: accessLoading } = useGetMySpecialAccess();
  const purchase = usePurchaseCinemaMode();
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";

  const [buying, setBuying] = useState(false);
  const hasAccess = isSuperAdmin || specialAccess?.entry?.canCinemaMode;

  const handleBuy = async () => {
    setBuying(true);
    try {
      await purchase.mutateAsync();
      toast({
        title: "Cinema Mode Activated! 🎬",
        description: "You can now create 4K–8K cinematic videos with DCP & ProRes export.",
      });
      queryClient.invalidateQueries({ queryKey: getGetMySpecialAccessQueryKey() });
    } catch (e: any) {
      toast({ title: "Purchase failed", description: e?.response?.data?.error ?? "Try again", variant: "destructive" });
    } finally {
      setBuying(false);
    }
  };

  if (priceLoading || accessLoading) {
    return <Skeleton className="h-64 w-full" />;
  }

  const CINEMA_FEATURES = [
    "4K Ultra HD resolution (3840×2160)",
    "8K resolution support (7680×4320)",
    "DCP (Digital Cinema Package) export",
    "ProRes 4444 export format",
    "Cinema 2.39:1 widescreen aspect ratio",
    "Advanced Dolby Atmos-ready audio mix",
    "HDR color grading pipeline",
    "Frame rates up to 60fps",
  ];

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/5 border-amber-500/20">
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
              <Clapperboard className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <CardTitle className="text-xl">Cinema Mode</CardTitle>
              <CardDescription className="text-white/50">Professional 4K–8K cinematic video generation</CardDescription>
            </div>
            {hasAccess && (
              <Badge className="ml-auto bg-amber-500/10 text-amber-400 border-amber-500/20">
                <CheckCircle2 className="w-3 h-3 mr-1" /> Active
              </Badge>
            )}
          </div>

          <div className="flex items-baseline gap-1 mt-2">
            {isSuperAdmin ? (
              <span className="text-3xl font-bold text-white">Free</span>
            ) : priceData?.priceUsd === 0 ? (
              <span className="text-3xl font-bold text-white">Free</span>
            ) : (
              <>
                <span className="text-3xl font-bold text-white">${priceData?.priceUsd ?? 29.99}</span>
                <span className="text-sm text-white/40">one-time purchase</span>
              </>
            )}
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {CINEMA_FEATURES.map((f, i) => (
              <div key={i} className="flex items-start gap-2 text-sm text-white/70">
                <Star className="w-3.5 h-3.5 text-amber-400 mt-0.5 shrink-0" />
                {f}
              </div>
            ))}
          </div>

          <div className="border-t border-white/5 pt-4">
            {hasAccess ? (
              <div className="flex items-center gap-3 text-sm text-green-400">
                <CheckCircle2 className="w-5 h-5" />
                <div>
                  <div className="font-medium">Cinema Mode is active on your account</div>
                  <div className="text-xs text-white/40">Access Cinema Mode when creating a new video</div>
                </div>
              </div>
            ) : (
              <Button
                className="w-full bg-amber-500 hover:bg-amber-400 text-black font-semibold"
                size="lg"
                onClick={handleBuy}
                disabled={buying}
              >
                {buying ? (
                  "Processing..."
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Unlock Cinema Mode — ${priceData?.priceUsd ?? 29.99}
                  </>
                )}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main Store Page
// ---------------------------------------------------------------------------
export function StorePage() {
  const { data: myPlan } = useGetMyVideoPlan();
  const { data: specialAccess } = useGetMySpecialAccess();
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";

  const ownedCount = [
    specialAccess?.entry?.canCinemaMode || isSuperAdmin,
    myPlan?.plan != null || isSuperAdmin,
  ].filter(Boolean).length;

  return (
    <div className="space-y-8 max-w-5xl">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
            <ShoppingBag className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold">GEMS Store</h1>
            <p className="text-sm text-muted-foreground">Unlock languages, plans, and premium features</p>
          </div>
        </div>
      </div>

      {/* Quick status bar */}
      {!isSuperAdmin && (
        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-2 bg-card border border-white/5 rounded-lg px-3 py-2 text-sm">
            <Film className="w-4 h-4 text-primary" />
            <span className="text-white/60">Plan:</span>
            <span className="font-medium">{myPlan?.plan?.name ?? "Free"}</span>
          </div>
          <div className="flex items-center gap-2 bg-card border border-white/5 rounded-lg px-3 py-2 text-sm">
            <Clapperboard className="w-4 h-4 text-amber-400" />
            <span className="text-white/60">Cinema Mode:</span>
            {specialAccess?.entry?.canCinemaMode ? (
              <span className="text-green-400 font-medium">Active</span>
            ) : (
              <span className="text-white/40 font-medium">Locked</span>
            )}
          </div>
          {myPlan && (
            <div className="flex items-center gap-2 bg-card border border-white/5 rounded-lg px-3 py-2 text-sm">
              <Clock className="w-4 h-4 text-white/40" />
              <span className="text-white/60">Videos this month:</span>
              <span className="font-medium">{myPlan.videosThisMonth}</span>
              {myPlan.quotaRemaining != null && (
                <span className="text-white/40">/ {myPlan.plan?.monthlyQuota ?? 3}</span>
              )}
            </div>
          )}
        </div>
      )}

      {/* Tabs */}
      <Tabs defaultValue="plans">
        <TabsList className="bg-background/50 border border-white/10">
          <TabsTrigger value="plans" className="gap-2">
            <Zap className="w-3.5 h-3.5" />Video Plans
          </TabsTrigger>
          <TabsTrigger value="cinema" className="gap-2">
            <Clapperboard className="w-3.5 h-3.5" />Cinema Mode
          </TabsTrigger>
          <TabsTrigger value="languages" className="gap-2">
            <Languages className="w-3.5 h-3.5" />Languages
          </TabsTrigger>
        </TabsList>

        <TabsContent value="plans" className="mt-6">
          <VideoPlansSection />
        </TabsContent>

        <TabsContent value="cinema" className="mt-6">
          <CinemaModeSection />
        </TabsContent>

        <TabsContent value="languages" className="mt-6">
          <LanguageStore />
        </TabsContent>
      </Tabs>
    </div>
  );
}
