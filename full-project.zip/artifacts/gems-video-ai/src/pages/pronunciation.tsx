import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useAnalyzeScriptPronunciation,
  useSubmitVoiceCorrection,
  useListMyVoiceCorrections,
  useDeleteMyVoiceCorrection,
  getListMyVoiceCorrectionsQueryKey,
} from "@workspace/api-client-react";
import type { FlaggedWord, PronunciationAnalysis } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  AudioLines, Mic2, Volume2, AlertTriangle, CheckCircle2, Loader2,
  Sparkles, Upload, Trash2, FileAudio,
} from "lucide-react";

const LANGUAGES = [
  { code: "en-US", label: "English (US)" },
  { code: "en-GB", label: "English (UK)" },
  { code: "en-IN", label: "English (India)" },
  { code: "hi-IN", label: "Hindi (India)" },
  { code: "ta-IN", label: "Tamil (India)" },
  { code: "te-IN", label: "Telugu (India)" },
  { code: "bn-IN", label: "Bengali (India)" },
  { code: "mr-IN", label: "Marathi (India)" },
  { code: "es-ES", label: "Spanish (Spain)" },
  { code: "es-MX", label: "Spanish (Mexico)" },
  { code: "fr-FR", label: "French (France)" },
  { code: "de-DE", label: "German" },
  { code: "ja-JP", label: "Japanese" },
  { code: "ko-KR", label: "Korean" },
  { code: "zh-CN", label: "Chinese (Mandarin)" },
  { code: "ar-SA", label: "Arabic" },
  { code: "pt-BR", label: "Portuguese (Brazil)" },
  { code: "ru-RU", label: "Russian" },
  { code: "it-IT", label: "Italian" },
];

export function PronunciationPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [text, setText] = useState("");
  const [languageCode, setLanguageCode] = useState("en-US");
  const [region, setRegion] = useState("");
  const [analysis, setAnalysis] = useState<PronunciationAnalysis | null>(null);
  const [correctionWord, setCorrectionWord] = useState<FlaggedWord | null>(null);

  const { data: myCorrections } = useListMyVoiceCorrections(undefined, {
    query: { queryKey: getListMyVoiceCorrectionsQueryKey() },
  });

  const analyzeMutation = useAnalyzeScriptPronunciation({
    mutation: {
      onSuccess: (data) => {
        setAnalysis(data);
        toast({
          title: "Analysis complete",
          description: `${data.flaggedCount} word(s) flagged · overall confidence ${data.overallConfidence}%`,
        });
      },
      onError: (e) => toast({ title: "Analysis failed", description: String(e), variant: "destructive" }),
    },
  });

  const submitCorrectionMutation = useSubmitVoiceCorrection({
    mutation: {
      onSuccess: () => {
        toast({ title: "Voice correction submitted", description: "We'll denoise, extract the pattern, and blend it into your audio." });
        setCorrectionWord(null);
        queryClient.invalidateQueries({ queryKey: getListMyVoiceCorrectionsQueryKey() });
        // Re-run analyze to refresh hasUserCorrection flags
        if (text && languageCode) handleAnalyze();
      },
      onError: (e) => toast({ title: "Submit failed", description: String(e), variant: "destructive" }),
    },
  });

  const deleteCorrectionMutation = useDeleteMyVoiceCorrection({
    mutation: {
      onSuccess: () => {
        toast({ title: "Correction removed" });
        queryClient.invalidateQueries({ queryKey: getListMyVoiceCorrectionsQueryKey() });
      },
    },
  });

  const handleAnalyze = () => {
    if (!text.trim() || !languageCode) return;
    analyzeMutation.mutate({
      data: {
        text: text.trim(),
        languageCode,
        ...(region ? { region } : {}),
      },
    });
  };

  const confidenceColor = (c: number) =>
    c >= 90 ? "text-emerald-400" :
    c >= 75 ? "text-yellow-400" :
    c >= 60 ? "text-orange-400" : "text-red-400";

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl space-y-6">
      {/* Hero */}
      <div className="flex items-start gap-4">
        <div className="h-14 w-14 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center flex-shrink-0">
          <AudioLines className="w-7 h-7 text-purple-300" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold">Pronunciation Studio</h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Analyze your script for tricky words, hear the AI's intended pronunciation, and upload your own voice for any word the AI is unsure about. Zero robotic feel.
          </p>
        </div>
      </div>

      {/* Input panel */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Sparkles className="w-4 h-4" />Analyze a Script</CardTitle>
          <CardDescription>Paste any script. We'll flag every word that needs pronunciation review.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <Label>Language *</Label>
              <Select value={languageCode} onValueChange={setLanguageCode}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map(l => <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Region / Dialect (optional)</Label>
              <Input value={region} onChange={(e) => setRegion(e.target.value)} placeholder="e.g. IN-DL, US-NY" />
            </div>
          </div>
          <div>
            <Label>Script</Label>
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste your video script, narration, or dialogue here..."
              rows={6}
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground mt-1">{text.trim().split(/\s+/).filter(Boolean).length} words</p>
          </div>
          <Button
            onClick={handleAnalyze}
            disabled={!text.trim() || analyzeMutation.isPending}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white"
          >
            {analyzeMutation.isPending
              ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing with AI...</>
              : <><Sparkles className="w-4 h-4 mr-2" />Analyze Pronunciation</>}
          </Button>
        </CardContent>
      </Card>

      {/* Analysis result */}
      {analysis && (
        <Card className="border-purple-500/30">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-400" />
                  Analysis Result
                </CardTitle>
                <CardDescription className="mt-1">{analysis.recommendation}</CardDescription>
              </div>
              <div className="text-right">
                <div className={`text-3xl font-bold ${confidenceColor(analysis.overallConfidence)}`}>{analysis.overallConfidence}%</div>
                <div className="text-xs text-muted-foreground">overall confidence</div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 grid-cols-3 mb-4">
              <Stat label="Words" value={analysis.wordCount} />
              <Stat label="Flagged" value={analysis.flaggedCount} accent={analysis.flaggedCount > 0 ? "yellow" : "emerald"} />
              <Stat label="Language" value={analysis.languageCode} mono />
            </div>

            {analysis.flaggedWords.length === 0 ? (
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-emerald-300 font-medium">Script is clean.</p>
                  <p className="text-sm text-muted-foreground mt-0.5">Voice generation will produce natural, native-sounding speech.</p>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3 flex items-start gap-2 mb-3">
                  <AlertTriangle className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <p className="text-yellow-300 text-sm">
                    Review the flagged words below. For any uncertain pronunciation, upload your own voice — we'll denoise it, extract the pattern, and blend it naturally with the AI voice.
                  </p>
                </div>

                {analysis.flaggedWords.map((fw, i) => (
                  <div key={i} className="border border-white/10 rounded-lg p-4 hover:border-white/20 transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-lg font-semibold">{fw.word}</span>
                          {fw.suggestedPhonetic && (
                            <Badge className="bg-purple-500/15 text-purple-300 border-0 font-mono">{fw.suggestedPhonetic}</Badge>
                          )}
                          <span className={`text-xs font-medium ${confidenceColor(fw.confidence)}`}>{fw.confidence}% confident</span>
                          {fw.hasDictionaryEntry && (
                            <Badge className="bg-blue-500/15 text-blue-300 border-0 text-xs"><Volume2 className="w-3 h-3 mr-1" />In Dictionary</Badge>
                          )}
                          {fw.hasUserCorrection && (
                            <Badge className="bg-pink-500/15 text-pink-300 border-0 text-xs"><CheckCircle2 className="w-3 h-3 mr-1" />Your Voice</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1.5">{fw.reason}</p>
                        {fw.prosody && (fw.prosody.tone || fw.prosody.pitch || fw.prosody.stress || fw.prosody.syllables || fw.prosody.nativeAccentNote) && (
                          <div className="mt-2.5 grid gap-1.5 grid-cols-1 sm:grid-cols-2 text-xs">
                            {fw.prosody.syllables && (
                              <div className="flex items-start gap-1.5"><span className="text-purple-300/70 font-medium min-w-[60px]">Syllables</span><span className="font-mono">{fw.prosody.syllables}</span></div>
                            )}
                            {fw.prosody.stress && (
                              <div className="flex items-start gap-1.5"><span className="text-purple-300/70 font-medium min-w-[60px]">Stress</span><span>{fw.prosody.stress}</span></div>
                            )}
                            {fw.prosody.pitch && (
                              <div className="flex items-start gap-1.5"><span className="text-purple-300/70 font-medium min-w-[60px]">Pitch</span><span className="capitalize">{fw.prosody.pitch}</span></div>
                            )}
                            {fw.prosody.tone && (
                              <div className="flex items-start gap-1.5"><span className="text-purple-300/70 font-medium min-w-[60px]">Tone</span><span>{fw.prosody.tone}</span></div>
                            )}
                            {fw.prosody.nativeAccentNote && (
                              <div className="flex items-start gap-1.5 sm:col-span-2"><span className="text-purple-300/70 font-medium min-w-[60px]">Native</span><span className="text-muted-foreground">{fw.prosody.nativeAccentNote}</span></div>
                            )}
                          </div>
                        )}
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setCorrectionWord(fw)}
                        className="flex-shrink-0"
                      >
                        <Mic2 className="w-3.5 h-3.5 mr-1.5" />
                        {fw.hasUserCorrection ? "Update Voice" : "Upload Voice"}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* My corrections */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><FileAudio className="w-4 h-4" />My Voice Corrections</CardTitle>
          <CardDescription>Voice samples you've uploaded. We denoise, extract the pronunciation pattern, and blend with the AI voice.</CardDescription>
        </CardHeader>
        <CardContent>
          {!myCorrections || myCorrections.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileAudio className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No corrections yet. Analyze a script and upload your voice for any flagged word.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {myCorrections.map((c) => (
                <div key={c.id} className="flex items-center justify-between border border-white/10 rounded-lg p-3">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="h-9 w-9 rounded bg-pink-500/15 flex items-center justify-center flex-shrink-0">
                      <Mic2 className="w-4 h-4 text-pink-300" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium">{c.word}</span>
                        <span className="text-xs font-mono text-muted-foreground">{c.languageCode}</span>
                        <Badge className={
                          c.status === "applied" ? "bg-purple-500/15 text-purple-300 border-0" :
                          c.status === "approved" ? "bg-emerald-500/15 text-emerald-300 border-0" :
                          c.status === "rejected" ? "bg-red-500/15 text-red-300 border-0" :
                          "bg-orange-500/15 text-orange-300 border-0"
                        }>{c.status}</Badge>
                      </div>
                      <a href={c.audioUrl} target="_blank" rel="noreferrer" className="text-xs text-blue-400 hover:underline">{c.audioUrl}</a>
                    </div>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => deleteCorrectionMutation.mutate({ id: c.id })} className="text-red-400 hover:text-red-300">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Voice correction submission dialog */}
      {correctionWord && (
        <SubmitCorrectionDialog
          word={correctionWord.word}
          languageCode={languageCode}
          onClose={() => setCorrectionWord(null)}
          onSubmit={(audioUrl, notes) => submitCorrectionMutation.mutate({
            data: { word: correctionWord.word, languageCode, audioUrl, notes },
          })}
          loading={submitCorrectionMutation.isPending}
        />
      )}
    </div>
  );
}

function Stat({ label, value, accent, mono }: { label: string; value: number | string; accent?: "yellow" | "emerald"; mono?: boolean }) {
  const color = accent === "yellow" ? "text-yellow-400" : accent === "emerald" ? "text-emerald-400" : "text-white";
  return (
    <div className="bg-white/5 border border-white/10 rounded-lg p-3">
      <div className={`text-2xl font-bold ${color} ${mono ? "font-mono" : ""}`}>{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}

function SubmitCorrectionDialog({
  word, languageCode, onClose, onSubmit, loading,
}: {
  word: string;
  languageCode: string;
  onClose: () => void;
  onSubmit: (audioUrl: string, notes?: string) => void;
  loading: boolean;
}) {
  const [audioUrl, setAudioUrl] = useState("");
  const [notes, setNotes] = useState("");

  return (
    <Dialog open={true} onOpenChange={(v) => !v && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mic2 className="w-4 h-4 text-pink-400" />
            Upload Voice for "{word}"
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-3 text-sm text-purple-200 flex items-start gap-2">
            <Sparkles className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium">How it works</p>
              <p className="text-xs text-purple-300/80 mt-1">
                We auto-clean noise, enhance clarity, extract your pronunciation pattern, and blend it naturally with the AI voice across the entire video. No mismatch, no sudden tone change.
              </p>
            </div>
          </div>
          <div>
            <Label>Word</Label>
            <Input value={word} disabled className="font-medium" />
          </div>
          <div>
            <Label>Language</Label>
            <Input value={languageCode} disabled className="font-mono" />
          </div>
          <div>
            <Label>Audio URL *</Label>
            <Input
              value={audioUrl}
              onChange={(e) => setAudioUrl(e.target.value)}
              placeholder="https://...your-recording.wav or .mp3"
            />
            <p className="text-xs text-muted-foreground mt-1">Upload a clear recording of you saying just this word. Max 10 seconds recommended.</p>
          </div>
          <div>
            <Label>Notes (optional)</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Any context the system should know..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button
            onClick={() => onSubmit(audioUrl, notes || undefined)}
            disabled={loading || !audioUrl}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white"
          >
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
            Submit Voice Correction
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default PronunciationPage;
