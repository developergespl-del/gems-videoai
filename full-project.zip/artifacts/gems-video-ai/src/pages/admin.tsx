import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useGetAdminStats, 
  useAdminListUsers,
  useListAllVideos,
  useUpdateUserRole,
  useAdminDeleteUser,
  useAdminCreateUser,
  useAdminUpdateUserStatus,
  useGetRealtimeAnalytics,
  useGetPlatformSettings,
  useUpdatePlatformSettings,
  getAdminListUsersQueryKey,
  getGetAdminStatsQueryKey,
  getListAllVideosQueryKey,
  getGetPlatformSettingsQueryKey,
  getGetRealtimeAnalyticsQueryKey,
  useAdminListLanguages,
  useAdminUpdateLanguage,
  getAdminListLanguagesQueryKey,
  useAdminListVideoPlans,
  useAdminCreateVideoPlan,
  useAdminUpdateVideoPlan,
  useAdminDeleteVideoPlan,
  useAdminGrantVideoPlan,
  getAdminListVideoPlansQueryKey,
  useAdminSetCinemaPrice,
  useGetCinemaPrice,
  getGetCinemaPriceQueryKey,
  useAdminListAds,
  useAdminCreateAd,
  useAdminUpdateAd,
  useAdminDeleteAd,
  useAdminGetAdAnalytics,
  getAdminListAdsQueryKey,
  useListApiClients,
  useCreateApiClient,
  useUpdateApiClientStatus,
  useDeleteApiClient,
  useListApiKeys,
  useCreateApiKey,
  useUpdateApiKeyStatus,
  useDeleteApiKey,
  useGetApiPlatformStats,
  useRenewApiKey,
  useListApiClientUsers,
  useUpdateApiClientUserStatus,
  useTransferApiClientUser,
  useDeleteApiClientUser,
  useGetApiClientLogs,
  getListApiClientsQueryKey,
  getListApiKeysQueryKey,
  getGetApiPlatformStatsQueryKey,
  getListApiClientUsersQueryKey,
  getGetApiClientLogsQueryKey,
  useListDictionaryEntries,
  useCreateDictionaryEntry,
  useUpdateDictionaryEntry,
  useDeleteDictionaryEntry,
  useListAllVoiceCorrections,
  useReviewVoiceCorrection,
  useGetPronunciationStats,
  getListDictionaryEntriesQueryKey,
  getListAllVoiceCorrectionsQueryKey,
  getGetPronunciationStatsQueryKey,
  useListOffers,
  useCreateOffer,
  useUpdateOffer,
  useDeleteOffer,
  useGetOffersStats,
  getListOffersQueryKey,
  getGetOffersStatsQueryKey,
  useListSpecialAccess,
  useGrantSpecialAccess,
  useUpdateSpecialAccess,
  useRevokeSpecialAccess,
  useGetSpecialAccessStats,
  getListSpecialAccessQueryKey,
  getGetSpecialAccessStatsQueryKey,
  useAdminListSoundLibrary,
  useAdminCreateSoundLibraryEntry,
  useAdminUpdateSoundLibraryEntry,
  useAdminDeleteSoundLibraryEntry,
  useAdminGetSoundDesignStats,
  getAdminListSoundLibraryQueryKey,
  getAdminGetSoundDesignStatsQueryKey,
  useGetAnalyticsUsers,
  useGetAnalyticsRevenue,
  useGetAnalyticsVideos,
  useGetAnalyticsGpu,
  getGetAnalyticsUsersQueryKey,
  getGetAnalyticsRevenueQueryKey,
  getGetAnalyticsVideosQueryKey,
  getGetAnalyticsGpuQueryKey,
  useGetMyAdminPermissions,
  useGetAdminPermissions,
  useSetAdminPermissions,
  useGetAdminAuditLogs,
  getGetAdminPermissionsQueryKey,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { 
  ShieldAlert, 
  Users, 
  Film, 
  Database, 
  Activity, 
  HardDrive,
  MoreVertical,
  Shield,
  ShieldOff,
  Trash2,
  Loader2,
  Languages,
  ToggleLeft,
  ToggleRight,
  DollarSign,
  CheckCircle2,
  Globe,
  Megaphone,
  Plus,
  Edit2,
  BarChart2,
  BarChart3,
  ExternalLink,
  X,
  Eye,
  MousePointer,
  UserX,
  UserCheck,
  Ban,
  Server,
  RefreshCw,
  AlertTriangle,
  Wifi,
  Clock,
  UserPlus,
  TrendingUp,
  Layers,
  Zap,
  Key,
  Network,
  Code2,
  Copy,
  CheckCheck,
  Mic2,
  Volume2,
  AudioLines,
  Tag,
  Crown,
  Gift,
  Calendar as CalendarIcon,
  Percent,
  Cpu,
  Gauge,
  CircuitBoard,
  TrendingDown,
  DollarSign as DollarSignIcon,
  BarChart as BarChartIcon,
  PieChart as PieChartIcon,
  RefreshCcw,
  ShieldCheck,
  FileText,
  Palette,
  Video,
  Lock,
  History,
  ListFilter,
  Clapperboard,
  Check,
  Pencil,
  AlertCircle,
  LifeBuoy,
  MessageCircle,
  Mail,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import type { Ad, User } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import type { UpdateRoleBodyRole, AdType, AdPlacement, AdStatus, AdminUpdateUserStatusBodyStatus } from "@workspace/api-client-react";

function formatStorage(mb: number) {
  if (mb > 1024) return `${(mb / 1024).toFixed(2)} GB`;
  return `${mb.toFixed(1)} MB`;
}

const STATUS_BADGE: Record<string, { className: string; label: string }> = {
  active: { className: "bg-emerald-500/15 text-emerald-400 border-0", label: "Active" },
  blocked: { className: "bg-yellow-500/15 text-yellow-400 border-0", label: "Blocked" },
  terminated: { className: "bg-red-500/15 text-red-400 border-0", label: "Terminated" },
  blacklisted: { className: "bg-red-900/40 text-red-300 border-0", label: "Blacklisted" },
};

// ── Permission system ────────────────────────────────────────────────────────

const ALL_ADMIN_PERMISSIONS = [
  { key: "users.view", label: "View Users", group: "Users" },
  { key: "users.create", label: "Create Users", group: "Users" },
  { key: "users.status", label: "Change User Status", group: "Users" },
  { key: "users.role", label: "Change User Role", group: "Users" },
  { key: "users.delete", label: "Delete Users", group: "Users" },
  { key: "videos.view", label: "View Videos", group: "Videos" },
  { key: "videos.delete", label: "Delete Videos", group: "Videos" },
  { key: "pricing.view", label: "View Pricing", group: "Pricing" },
  { key: "pricing.manage", label: "Manage Pricing", group: "Pricing" },
  { key: "ads.view", label: "View Ads", group: "Ads" },
  { key: "ads.manage", label: "Manage Ads", group: "Ads" },
  { key: "analytics.view", label: "View Analytics", group: "Analytics" },
  { key: "api_platform.view", label: "View API Platform", group: "API Platform" },
  { key: "api_platform.manage", label: "Manage API Platform", group: "API Platform" },
  { key: "pronunciation.view", label: "View Pronunciation", group: "Pronunciation" },
  { key: "pronunciation.manage", label: "Manage Pronunciation", group: "Pronunciation" },
  { key: "settings.view", label: "View Settings", group: "Settings" },
  { key: "settings.manage", label: "Manage Settings", group: "Settings" },
  { key: "audit.view", label: "View Audit Logs", group: "Security" },
];

type PermGroup = { label: string; permissions: Array<{ key: string; label: string }> };
const PERMISSION_GROUPS: PermGroup[] = ALL_ADMIN_PERMISSIONS.reduce<PermGroup[]>((acc, p) => {
  const g = acc.find(x => x.label === p.group);
  if (g) g.permissions.push({ key: p.key, label: p.label });
  else acc.push({ label: p.group, permissions: [{ key: p.key, label: p.label }] });
  return acc;
}, []);

const AdminPermissionsCtx = React.createContext<{
  myPermissions: Set<string>;
  isSuperAdmin: boolean;
  has: (p: string) => boolean;
}>({ myPermissions: new Set(), isSuperAdmin: false, has: () => false });

function useAdminPerms() {
  return React.useContext(AdminPermissionsCtx);
}

export function AdminPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const isSuperAdmin = user?.role === "super_admin";

  const { data: stats, isLoading: statsLoading } = useGetAdminStats();

  const { data: myPermsData } = useGetMyAdminPermissions();

  const myPermissions = React.useMemo(() => {
    if (isSuperAdmin) return new Set(["*"]);
    return new Set(myPermsData?.permissions ?? []);
  }, [isSuperAdmin, myPermsData]);

  const has = React.useCallback((p: string) => {
    if (isSuperAdmin) return true;
    return myPermissions.has(p);
  }, [isSuperAdmin, myPermissions]);

  return (
    <AdminPermissionsCtx.Provider value={{ myPermissions, isSuperAdmin, has }}>
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold tracking-tight text-primary flex items-center gap-3">
          <ShieldAlert className="w-8 h-8" />
          Admin Control Center
        </h1>
        <p className="text-muted-foreground mt-1">Platform-wide management, analytics and system configuration.</p>
      </div>

      {/* Platform Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-primary/20 shadow-[0_0_15px_-5px_rgba(234,179,8,0.2)]">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-primary">Total Users</CardTitle>
            <Users className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            {statsLoading ? <Skeleton className="h-8 w-16" /> : (
              <div className="text-3xl font-display font-bold">{stats?.totalUsers || 0}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">+{stats?.newUsersThisWeek || 0} this week</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-white/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Videos</CardTitle>
            <Film className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {statsLoading ? <Skeleton className="h-8 w-16" /> : (
              <div className="text-3xl font-display font-bold">{stats?.totalVideos || 0}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">+{stats?.videosCreatedToday || 0} today</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-white/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Render Jobs</CardTitle>
            <Activity className="w-4 h-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            {statsLoading ? <Skeleton className="h-8 w-16" /> : (
              <div className="text-3xl font-display font-bold text-blue-500">{stats?.activeProcessingJobs || 0}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">Currently utilizing GPU nodes</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-white/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Storage Used</CardTitle>
            <HardDrive className="w-4 h-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            {statsLoading ? <Skeleton className="h-8 w-16" /> : (
              <div className="text-3xl font-display font-bold">{formatStorage(stats?.totalStorageUsedMb || 0)}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">Across {stats?.totalProjects || 0} projects</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue={isSuperAdmin ? "users" : "overview"} className="w-full">
        <TabsList className="flex flex-wrap bg-background/50 border border-white/10 h-auto gap-0.5 p-1 max-w-full">
          {/* Overview — always visible to all admins, read-only */}
          <TabsTrigger value="overview"><BarChart3 className="w-3.5 h-3.5 mr-1.5" />Overview</TabsTrigger>
          {/* Super-admin-only action tabs */}
          {isSuperAdmin && <TabsTrigger value="users"><Users className="w-3.5 h-3.5 mr-1.5" />Users</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="videos"><Film className="w-3.5 h-3.5 mr-1.5" />Videos</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="languages"><Languages className="w-3.5 h-3.5 mr-1.5" />Languages</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="system"><Server className="w-3.5 h-3.5 mr-1.5" />System</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="offers"><Tag className="w-3.5 h-3.5 mr-1.5" />Offers</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="vip"><Crown className="w-3.5 h-3.5 mr-1.5" />VIP Access</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="sound-lib"><AudioLines className="w-3.5 h-3.5 mr-1.5" />Sound Lib</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="video-plans"><Film className="w-3.5 h-3.5 mr-1.5" />Plans</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="cinema-price"><Clapperboard className="w-3.5 h-3.5 mr-1.5" />Cinema</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="support-contact"><LifeBuoy className="w-3.5 h-3.5 mr-1.5" />Support</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="api-platform"><Key className="w-3.5 h-3.5 mr-1.5" />API Platform</TabsTrigger>}
          {/* Permission-granted tabs — visible to super_admin always, admins if granted */}
          {has("ads.view") && <TabsTrigger value="ads"><Megaphone className="w-3.5 h-3.5 mr-1.5" />Ads</TabsTrigger>}
          {isSuperAdmin && <TabsTrigger value="analytics"><BarChart3 className="w-3.5 h-3.5 mr-1.5" />Analytics</TabsTrigger>}
          {!isSuperAdmin && has("api_platform.view") && <TabsTrigger value="api-platform"><Key className="w-3.5 h-3.5 mr-1.5" />API</TabsTrigger>}
          {has("pronunciation.view") && <TabsTrigger value="pronunciation"><Mic2 className="w-3.5 h-3.5 mr-1.5" />Pronounce</TabsTrigger>}
          {has("audit.view") && <TabsTrigger value="audit"><History className="w-3.5 h-3.5 mr-1.5" />Audit Log</TabsTrigger>}
        </TabsList>

        {/* Overview — read-only for all admins */}
        <TabsContent value="overview" className="mt-6 space-y-4">
          <AdminOverviewTab isSuperAdmin={isSuperAdmin} />
        </TabsContent>

        {isSuperAdmin && (
          <TabsContent value="users" className="mt-6 space-y-4">
            <UsersTab isSuperAdmin={isSuperAdmin} />
          </TabsContent>
        )}

        {isSuperAdmin && (
          <>
            <TabsContent value="videos" className="mt-6 space-y-4">
              <VideosTab />
            </TabsContent>
            <TabsContent value="languages" className="mt-6 space-y-4">
              <LanguageManagement />
            </TabsContent>
            <TabsContent value="system" className="mt-6 space-y-4">
              <SystemTab />
            </TabsContent>
            <TabsContent value="offers" className="mt-6 space-y-4">
              <OffersTab />
            </TabsContent>
            <TabsContent value="vip" className="mt-6 space-y-4">
              <SpecialAccessTab />
            </TabsContent>
            <TabsContent value="sound-lib" className="mt-6 space-y-4">
              <SoundLibraryTab />
            </TabsContent>
            <TabsContent value="video-plans" className="mt-6 space-y-4">
              <VideoPlansAdminTab />
            </TabsContent>
            <TabsContent value="cinema-price" className="mt-6 space-y-4">
              <CinemaModeAdminTab />
            </TabsContent>
            <TabsContent value="support-contact" className="mt-6 space-y-4">
              <SupportContactAdminTab isSuperAdmin={isSuperAdmin} />
            </TabsContent>
            <TabsContent value="api-platform" className="mt-6 space-y-4">
              <ApiPlatformTab />
            </TabsContent>
          </>
        )}

        {/* Permission-controlled tab content — super_admin always has access */}
        {has("ads.view") && (
          <TabsContent value="ads" className="mt-6 space-y-4">
            <AdManagement />
          </TabsContent>
        )}
        {isSuperAdmin && (
          <TabsContent value="analytics" className="mt-6 space-y-4">
            <AnalyticsTab />
          </TabsContent>
        )}
        {!isSuperAdmin && has("api_platform.view") && (
          <TabsContent value="api-platform" className="mt-6 space-y-4">
            <ApiPlatformTab />
          </TabsContent>
        )}
        {has("pronunciation.view") && (
          <TabsContent value="pronunciation" className="mt-6 space-y-4">
            <PronunciationTab />
          </TabsContent>
        )}
        {has("audit.view") && (
          <TabsContent value="audit" className="mt-6 space-y-4">
            <AuditLogsTab />
          </TabsContent>
        )}
      </Tabs>
    </div>
    </AdminPermissionsCtx.Provider>
  );
}

// ---------------------------------------------------------------------------
// Permissions Modal
// ---------------------------------------------------------------------------
function PermissionsModal({ userId, userName, open, onClose }: {
  userId: string; userName: string; open: boolean; onClose: () => void;
}) {
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: permsData, isLoading } = useGetAdminPermissions(userId, {
    query: { enabled: open && !!userId, queryKey: getGetAdminPermissionsQueryKey(userId) },
  });

  const setPerms = useSetAdminPermissions();
  const [local, setLocal] = useState<Set<string>>(new Set());

  React.useEffect(() => {
    if (permsData) setLocal(new Set(permsData.permissions));
  }, [permsData]);

  const toggle = (p: string) => setLocal(prev => {
    const next = new Set(prev);
    if (next.has(p)) next.delete(p); else next.add(p);
    return next;
  });

  const grantAll = () => setLocal(new Set(ALL_ADMIN_PERMISSIONS.map(p => p.key)));
  const readOnly = () => setLocal(new Set(ALL_ADMIN_PERMISSIONS.filter(p => p.key.endsWith(".view")).map(p => p.key)));
  const clearAll = () => setLocal(new Set());

  const save = async () => {
    try {
      await setPerms.mutateAsync({ userId, data: { permissions: [...local] } });
      qc.invalidateQueries({ queryKey: getGetAdminPermissionsQueryKey(userId) });
      toast({ title: "Permissions saved", description: `${local.size} permission(s) granted to ${userName}` });
      onClose();
    } catch (err: any) {
      toast({ title: "Failed to save permissions", description: err.message, variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-card border-white/10 max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-yellow-400" />
            Permissions — <span className="text-primary">{userName}</span>
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="flex gap-2 mb-2">
              <Button size="sm" variant="outline" className="border-white/10 text-xs" onClick={grantAll}>
                <ShieldCheck className="w-3 h-3 mr-1" /> Grant All
              </Button>
              <Button size="sm" variant="outline" className="border-white/10 text-xs" onClick={readOnly}>
                <ListFilter className="w-3 h-3 mr-1" /> Read Only
              </Button>
              <Button size="sm" variant="ghost" className="text-xs text-destructive hover:bg-destructive/10" onClick={clearAll}>
                Clear All
              </Button>
            </div>

            <div className="space-y-4 max-h-80 overflow-y-auto pr-1 custom-scrollbar">
              {PERMISSION_GROUPS.map(group => (
                <div key={group.label}>
                  <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-1.5 px-1">{group.label}</div>
                  <div className="space-y-0.5">
                    {group.permissions.map(p => (
                      <div key={p.key} className="flex items-center justify-between py-1.5 px-2 rounded-md hover:bg-white/5 transition-colors">
                        <div>
                          <span className="text-sm">{p.label}</span>
                          <code className="text-[10px] text-muted-foreground ml-2 bg-white/5 px-1 py-0.5 rounded">{p.key}</code>
                        </div>
                        <Switch checked={local.has(p.key)} onCheckedChange={() => toggle(p.key)} />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="text-xs text-muted-foreground pt-1">
              {local.size} / {ALL_ADMIN_PERMISSIONS.length} permissions granted
            </div>
          </>
        )}

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button
            onClick={save}
            disabled={setPerms.isPending || isLoading}
            className="bg-yellow-500 hover:bg-yellow-400 text-black font-medium"
          >
            {setPerms.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ShieldCheck className="w-4 h-4 mr-2" />}
            Save Permissions
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------------------------------------------------------------------------
// Admin Overview Tab — read-only stats visible to all admins
// ---------------------------------------------------------------------------
function OverviewStatCard({
  title, value, sub, icon, accent, loading,
}: { title: string; value: React.ReactNode; sub?: string; icon: React.ReactNode; accent?: string; loading?: boolean }) {
  return (
    <Card className="bg-card border-white/5">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className={`text-sm font-medium ${accent ?? "text-muted-foreground"}`}>{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        {loading ? (
          <Skeleton className="h-8 w-20" />
        ) : (
          <div className={`text-3xl font-display font-bold ${accent ?? ""}`}>{value}</div>
        )}
        {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
      </CardContent>
    </Card>
  );
}

function AdminOverviewTab({ isSuperAdmin }: { isSuperAdmin: boolean }) {
  const { data: stats, isLoading: statsLoading } = useGetAdminStats();
  const { data: vipStats, isLoading: vipLoading } = useGetSpecialAccessStats({
    query: {
      queryKey: getGetSpecialAccessStatsQueryKey(),
      enabled: isSuperAdmin,
    },
  });
  const loading = statsLoading || (isSuperAdmin && vipLoading);

  return (
    <div className="space-y-6">
      {/* Read-only notice for non-super-admins */}
      {!isSuperAdmin && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground bg-white/5 border border-white/10 rounded-lg px-4 py-3">
          <Lock className="w-4 h-4 text-yellow-400 shrink-0" />
          <span>You have <span className="text-white font-medium">read-only</span> access. Contact your Super Admin to grant action permissions.</span>
        </div>
      )}

      {/* Users section */}
      <div>
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Users className="w-3.5 h-3.5" /> Users
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <OverviewStatCard
            title="Total Users"
            value={stats?.totalUsers ?? 0}
            sub={`+${stats?.newUsersThisWeek ?? 0} this week`}
            icon={<Users className="w-4 h-4 text-primary" />}
            accent="text-primary"
            loading={loading}
          />
          <OverviewStatCard
            title="Active Users"
            value={stats?.activeUsers ?? 0}
            sub="Currently not blocked"
            icon={<UserCheck className="w-4 h-4 text-emerald-400" />}
            accent="text-emerald-400"
            loading={loading}
          />
          <OverviewStatCard
            title="Blocked Users"
            value={stats?.blockedUsers ?? 0}
            sub="Suspended accounts"
            icon={<Ban className="w-4 h-4 text-yellow-500" />}
            accent="text-yellow-500"
            loading={loading}
          />
          <OverviewStatCard
            title="VIP Users"
            value={isSuperAdmin ? (vipStats?.totalUsersWithAccess ?? 0) : "—"}
            sub={isSuperAdmin ? "Super Admin granted access" : "Visible to Super Admin only"}
            icon={<Crown className="w-4 h-4 text-yellow-400" />}
            accent="text-yellow-400"
            loading={isSuperAdmin ? loading : false}
          />
        </div>
      </div>

      {/* Videos section */}
      <div>
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Film className="w-3.5 h-3.5" /> Videos
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <OverviewStatCard
            title="Total Videos"
            value={stats?.totalVideos ?? 0}
            sub="All time"
            icon={<Film className="w-4 h-4 text-muted-foreground" />}
            loading={loading}
          />
          <OverviewStatCard
            title="Videos Today"
            value={stats?.videosCreatedToday ?? 0}
            sub="Created since midnight"
            icon={<Activity className="w-4 h-4 text-blue-400" />}
            accent="text-blue-400"
            loading={loading}
          />
          <OverviewStatCard
            title="Rendering Now"
            value={stats?.activeProcessingJobs ?? 0}
            sub="Active GPU jobs"
            icon={<Activity className="w-4 h-4 text-purple-400" />}
            accent="text-purple-400"
            loading={loading}
          />
          <OverviewStatCard
            title="Storage Used"
            value={formatStorage(stats?.totalStorageUsedMb ?? 0)}
            sub={`Across ${stats?.totalProjects ?? 0} projects`}
            icon={<HardDrive className="w-4 h-4 text-muted-foreground" />}
            loading={loading}
          />
        </div>
      </div>

      {/* Info footer */}
      <Card className="bg-card border-white/5">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3 text-sm text-muted-foreground">
            <Shield className="w-4 h-4 mt-0.5 text-blue-400 shrink-0" />
            <div>
              <span className="text-white font-medium">Permission-based access:</span> This platform has no paid plans. All access is granted by the Super Admin through the VIP Access system. Admins can view these statistics but cannot perform any actions unless the Super Admin explicitly grants specific permissions.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Users Tab
// ---------------------------------------------------------------------------
function UsersTab({ isSuperAdmin }: { isSuperAdmin: boolean }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const canCreate = isSuperAdmin;

  const [userPage, setUserPage] = useState(1);
  const { data: usersData, isLoading: usersLoading } = useAdminListUsers({ page: userPage, limit: 20 });

  const updateRole = useUpdateUserRole();
  const deleteUser = useAdminDeleteUser();
  const updateStatus = useAdminUpdateUserStatus();

  const [createOpen, setCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState({ email: "", password: "", name: "", role: "user" as string });
  const createUser = useAdminCreateUser();

  const [permsModal, setPermsModal] = useState<{ userId: string; userName: string } | null>(null);

  const invalidateUsers = () => {
    queryClient.invalidateQueries({ queryKey: getAdminListUsersQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
  };

  const handleRoleChange = async (userId: string, newRole: UpdateRoleBodyRole) => {
    try {
      await updateRole.mutateAsync({ id: userId, data: { role: newRole } });
      toast({ title: "Role updated successfully" });
      invalidateUsers();
    } catch (err: any) {
      toast({ title: "Failed to update role", description: err.message, variant: "destructive" });
    }
  };

  const handleStatusChange = async (userId: string, status: AdminUpdateUserStatusBodyStatus) => {
    const labels: Record<string, string> = { active: "activated", blocked: "blocked", terminated: "terminated", blacklisted: "blacklisted" };
    try {
      await updateStatus.mutateAsync({ id: userId, data: { status } });
      toast({ title: `User ${labels[status] ?? status}` });
      invalidateUsers();
    } catch (err: any) {
      toast({ title: "Failed to update status", description: err.message, variant: "destructive" });
    }
  };

  const handleDeleteUser = async (userId: string) => {
    try {
      await deleteUser.mutateAsync({ id: userId });
      toast({ title: "User deleted permanently" });
      invalidateUsers();
    } catch (err: any) {
      toast({ title: "Failed to delete user", description: err.message, variant: "destructive" });
    }
  };

  const handleCreateUser = async () => {
    if (!createForm.email || !createForm.password || !createForm.name) {
      toast({ title: "Please fill in all required fields", variant: "destructive" });
      return;
    }
    try {
      await createUser.mutateAsync({ data: createForm as any });
      toast({ title: "User created successfully" });
      invalidateUsers();
      setCreateOpen(false);
      setCreateForm({ email: "", password: "", name: "", role: "user" });
    } catch (err: any) {
      toast({ title: "Failed to create user", description: err.message, variant: "destructive" });
    }
  };

  return (
    <>
      <Card className="bg-card border-white/5">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Platform Users</CardTitle>
            <CardDescription>
              {isSuperAdmin
                ? "Manage all users and admins. Role hierarchy enforced — you can manage admins and users."
                : "Create and manage users. Admins and super admins are protected."}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {canCreate && (
              <Button onClick={() => setCreateOpen(true)} size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
                <UserPlus className="w-4 h-4 mr-1.5" /> Create User
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {usersLoading ? (
            <div className="space-y-4">
              {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : (
            <div className="rounded-md border border-white/10 overflow-hidden">
              <Table>
                <TableHeader className="bg-white/5">
                  <TableRow className="border-white/10 hover:bg-transparent">
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead className="text-right">Usage</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {usersData?.users.map((user) => {
                    const sb = STATUS_BADGE[user.status ?? "active"] ?? STATUS_BADGE.active;
                    return (
                      <TableRow key={user.id} className="border-white/10 hover:bg-white/5">
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                              {user.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-medium">{user.name}</div>
                              <div className="text-xs text-muted-foreground">{user.email}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={
                            user.role === 'super_admin' ? 'border-primary text-primary' : 
                            user.role === 'admin' ? 'border-blue-500 text-blue-500' : 
                            'border-white/20 text-muted-foreground'
                          }>
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={sb.className}>{sb.label}</Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {new Date(user.createdAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right text-sm">
                          <div className="font-medium">{user.videoCount || 0} videos</div>
                          <div className="text-xs text-muted-foreground">{formatStorage(user.storageUsedMb || 0)}</div>
                        </TableCell>
                        <TableCell>
                          {isSuperAdmin && user.role !== "super_admin" ? (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreVertical className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-card border-white/10 min-w-[180px]">
                                <DropdownMenuLabel className="text-xs text-muted-foreground">Change Role</DropdownMenuLabel>
                                {user.role !== "user" && (
                                  <DropdownMenuItem className="cursor-pointer" onClick={() => handleRoleChange(user.id, "user")}>
                                    <Users className="w-3.5 h-3.5 mr-2 text-white/40" /> Demote to User
                                  </DropdownMenuItem>
                                )}
                                {user.role !== "admin" && (
                                  <DropdownMenuItem className="cursor-pointer" onClick={() => handleRoleChange(user.id, "admin")}>
                                    <Shield className="w-3.5 h-3.5 mr-2 text-blue-400" /> {user.role === "user" ? "Promote to Admin" : "Set to Admin"}
                                  </DropdownMenuItem>
                                )}
                                {user.role === "admin" && (
                                  <DropdownMenuItem
                                    className="cursor-pointer text-yellow-400 focus:bg-yellow-500/10 focus:text-yellow-400"
                                    onClick={() => setPermsModal({ userId: user.id, userName: user.name || user.email })}
                                  >
                                    <Lock className="w-3.5 h-3.5 mr-2" /> Manage Permissions
                                  </DropdownMenuItem>
                                )}
                                <DropdownMenuSeparator className="bg-white/10" />
                                <DropdownMenuLabel className="text-xs text-muted-foreground">Account Status</DropdownMenuLabel>
                                <DropdownMenuItem
                                  className="cursor-pointer text-emerald-400 focus:bg-emerald-500/10 focus:text-emerald-400"
                                  onClick={() => handleStatusChange(user.id, "active")}
                                  disabled={user.status === "active"}
                                >
                                  <UserCheck className="w-4 h-4 mr-2" /> Activate
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="cursor-pointer text-yellow-400 focus:bg-yellow-500/10 focus:text-yellow-400"
                                  onClick={() => handleStatusChange(user.id, "blocked")}
                                  disabled={user.status === "blocked"}
                                >
                                  <Ban className="w-4 h-4 mr-2" /> Block
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="cursor-pointer text-orange-400 focus:bg-orange-500/10 focus:text-orange-400"
                                  onClick={() => handleStatusChange(user.id, "terminated")}
                                  disabled={user.status === "terminated"}
                                >
                                  <UserX className="w-4 h-4 mr-2" /> Terminate
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="cursor-pointer text-red-400 focus:bg-red-500/10 focus:text-red-400"
                                  onClick={() => handleStatusChange(user.id, "blacklisted")}
                                  disabled={user.status === "blacklisted"}
                                >
                                  <ShieldOff className="w-4 h-4 mr-2" /> Blacklist
                                </DropdownMenuItem>
                                <DropdownMenuSeparator className="bg-white/10" />
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:bg-destructive/10 cursor-pointer">
                                      <Trash2 className="w-4 h-4 mr-2" /> Delete Permanently
                                    </DropdownMenuItem>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent className="bg-card border-white/10">
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Delete User Permanently</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will permanently delete {user.email} and all their data. This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel className="bg-transparent border-white/10">Cancel</AlertDialogCancel>
                                      <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => handleDeleteUser(user.id)}>
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          ) : (
                            <span className="text-xs text-muted-foreground/40 px-2">—</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {(!usersData?.users || usersData.users.length === 0) && (
                    <TableRow>
                      <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                        No users found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
          
          {usersData && usersData.total > 20 && (
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-muted-foreground">
                Showing {(userPage - 1) * 20 + 1} to {Math.min(userPage * 20, usersData.total)} of {usersData.total} users
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={userPage === 1} onClick={() => setUserPage(p => p - 1)} className="border-white/10">
                  Previous
                </Button>
                <Button variant="outline" size="sm" disabled={userPage * 20 >= usersData.total} onClick={() => setUserPage(p => p + 1)} className="border-white/10">
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create User Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-card border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Full Name *</label>
              <Input
                value={createForm.name}
                onChange={e => setCreateForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Jane Smith"
                className="bg-background/50 border-white/10"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Email *</label>
              <Input
                type="email"
                value={createForm.email}
                onChange={e => setCreateForm(f => ({ ...f, email: e.target.value }))}
                placeholder="jane@example.com"
                className="bg-background/50 border-white/10"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Password *</label>
              <Input
                type="password"
                value={createForm.password}
                onChange={e => setCreateForm(f => ({ ...f, password: e.target.value }))}
                placeholder="Min. 8 characters"
                className="bg-background/50 border-white/10"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Role</label>
              <Select value={createForm.role} onValueChange={v => setCreateForm(f => ({ ...f, role: v }))}>
                <SelectTrigger className="bg-background/50 border-white/10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">User</SelectItem>
                  {isSuperAdmin && <SelectItem value="admin">Admin</SelectItem>}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)} className="border-white/10">
              Cancel
            </Button>
            <Button onClick={handleCreateUser} disabled={createUser.isPending}>
              {createUser.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Create User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {permsModal && (
        <PermissionsModal
          userId={permsModal.userId}
          userName={permsModal.userName}
          open={true}
          onClose={() => setPermsModal(null)}
        />
      )}
    </>
  );
}

// ---------------------------------------------------------------------------
// Videos Tab
// ---------------------------------------------------------------------------
function VideosTab() {
  const [videoPage, setVideoPage] = useState(1);
  const { data: videosData, isLoading: videosLoading } = useListAllVideos({ page: videoPage, limit: 20 });

  return (
    <Card className="bg-card border-white/5">
      <CardHeader>
        <CardTitle>Global Video Feed</CardTitle>
        <CardDescription>View all video rendering activity across the platform.</CardDescription>
      </CardHeader>
      <CardContent>
        {videosLoading ? (
          <div className="space-y-4">
            {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-12 w-full" />)}
          </div>
        ) : (
          <div className="rounded-md border border-white/10 overflow-hidden">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/10 hover:bg-transparent">
                  <TableHead>Video</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Style</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead className="text-right">Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {videosData?.videos.map((video) => (
                  <TableRow key={video.id} className="border-white/10 hover:bg-white/5">
                    <TableCell>
                      <div className="font-medium truncate max-w-xs">{video.title}</div>
                      <div className="text-xs text-muted-foreground truncate max-w-xs font-mono">{video.id}</div>
                    </TableCell>
                    <TableCell>
                      {video.status === 'completed' && <Badge className="bg-green-500/10 text-green-500 border-green-500/20">Ready</Badge>}
                      {video.status === 'processing' && <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20">Rendering {video.progress}%</Badge>}
                      {video.status === 'pending' && <Badge variant="outline" className="text-muted-foreground">Queued</Badge>}
                      {video.status === 'failed' && <Badge variant="destructive" className="bg-destructive/10 text-destructive border-destructive/20">Failed</Badge>}
                    </TableCell>
                    <TableCell><span className="capitalize text-sm">{video.style}</span></TableCell>
                    <TableCell className="text-sm">
                      {Math.floor(video.durationSeconds / 60)}m {video.durationSeconds % 60}s
                    </TableCell>
                    <TableCell className="text-right text-sm text-muted-foreground">
                      {new Date(video.createdAt).toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))}
                {(!videosData?.videos || videosData.videos.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                      No videos found on the platform.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
        {videosData && videosData.total > 20 && (
          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-muted-foreground">
              Showing {(videoPage - 1) * 20 + 1} to {Math.min(videoPage * 20, videosData.total)} of {videosData.total} videos
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={videoPage === 1} onClick={() => setVideoPage(p => p - 1)} className="border-white/10">Previous</Button>
              <Button variant="outline" size="sm" disabled={videoPage * 20 >= videosData.total} onClick={() => setVideoPage(p => p + 1)} className="border-white/10">Next</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Chart helpers
// ---------------------------------------------------------------------------

const CHART_COLORS = ["#eab308", "#22c55e", "#3b82f6", "#a855f7", "#f97316", "#ec4899", "#06b6d4", "#84cc16", "#ef4444", "#f59e0b"];

function ChartCard({ title, icon, children, isLoading }: { title: string; icon: React.ReactNode; children: React.ReactNode; isLoading: boolean }) {
  return (
    <Card className="bg-card border-white/5">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-white/70 flex items-center gap-2">
          {icon}{title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? <Skeleton className="h-48 w-full" /> : children}
      </CardContent>
    </Card>
  );
}

function KpiRow({ items }: { items: { label: string; value: string | number | null | undefined; icon: React.ReactNode; sub?: string }[] }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {items.map((item, i) => (
        <div key={i} className="bg-background/50 border border-white/5 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-1">{item.icon}<span className="text-xs text-muted-foreground">{item.label}</span></div>
          <div className="text-2xl font-display font-bold text-white">{item.value ?? "—"}</div>
          {item.sub && <div className="text-xs text-white/30 mt-0.5">{item.sub}</div>}
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Analytics Sub-Tab — Users
// ---------------------------------------------------------------------------
function AnalyticsUsersTab() {
  const { data, isLoading } = useGetAnalyticsUsers({ query: { queryKey: getGetAnalyticsUsersQueryKey(), refetchInterval: 30000 } });
  const total = (data?.roleDistribution.user ?? 0) + (data?.roleDistribution.admin ?? 0) + (data?.roleDistribution.super_admin ?? 0);

  const rolePie = data ? [
    { name: "Users", value: data.roleDistribution.user },
    { name: "Admins", value: data.roleDistribution.admin },
    { name: "Super Admins", value: data.roleDistribution.super_admin },
  ] : [];

  const statusPie = data ? [
    { name: "Active", value: data.statusDistribution.active },
    { name: "Blocked", value: data.statusDistribution.blocked },
    { name: "Terminated", value: data.statusDistribution.terminated },
  ] : [];

  return (
    <div className="space-y-5">
      <KpiRow items={[
        { label: "Total Users", value: total, icon: <Users className="w-4 h-4 text-primary" /> },
        { label: "Active", value: data?.statusDistribution.active, icon: <UserCheck className="w-4 h-4 text-emerald-400" />, sub: total > 0 ? `${((data?.statusDistribution.active ?? 0) / total * 100).toFixed(0)}% of total` : undefined },
        { label: "Blocked", value: data?.statusDistribution.blocked, icon: <Ban className="w-4 h-4 text-yellow-400" /> },
        { label: "Terminated", value: data?.statusDistribution.terminated, icon: <UserX className="w-4 h-4 text-red-400" /> },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChartCard title="30-Day Registration Trend" icon={<TrendingUp className="w-3.5 h-3.5 text-primary" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={data?.registrationTrend ?? []} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
              <defs>
                <linearGradient id="regGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#eab308" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#eab308" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
              <XAxis dataKey="date" tick={{ fontSize: 9, fill: "#ffffff40" }} tickFormatter={(v: string) => v.slice(5)} interval={6} />
              <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} allowDecimals={false} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} labelStyle={{ color: "#ffffff60", fontSize: 11 }} itemStyle={{ color: "#eab308", fontSize: 11 }} />
              <Area type="monotone" dataKey="count" stroke="#eab308" fill="url(#regGrad)" strokeWidth={2} name="New Users" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Role Distribution" icon={<Shield className="w-3.5 h-3.5 text-blue-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={rolePie} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" nameKey="name"
                label={({ name, percent }: { name: string; percent: number }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                {rolePie.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <ChartCard title="Weekly Registration Trend (12 Weeks)" icon={<BarChartIcon className="w-3.5 h-3.5 text-cyan-400" />} isLoading={isLoading}>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={data?.weeklyTrend ?? []} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
            <XAxis dataKey="week" tick={{ fontSize: 9, fill: "#ffffff40" }} tickFormatter={(v: string) => v.slice(5)} />
            <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} allowDecimals={false} />
            <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} labelStyle={{ color: "#ffffff60", fontSize: 11 }} itemStyle={{ color: "#22d3ee", fontSize: 11 }} />
            <Bar dataKey="count" fill="#22d3ee" radius={[3, 3, 0, 0]} name="New Users" />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Top 10 Creators by Video Count" icon={<TrendingUp className="w-3.5 h-3.5 text-amber-400" />} isLoading={isLoading}>
        <Table>
          <TableHeader>
            <TableRow className="border-white/5">
              <TableHead className="text-white/40 text-xs">#</TableHead>
              <TableHead className="text-white/40 text-xs">User</TableHead>
              <TableHead className="text-white/40 text-xs">Role</TableHead>
              <TableHead className="text-white/40 text-xs text-right">Total</TableHead>
              <TableHead className="text-white/40 text-xs text-right">Done</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {(data?.topCreators ?? []).map((u, i) => (
              <TableRow key={u.id} className="border-white/5 hover:bg-white/5">
                <TableCell className="text-white/30 font-mono text-xs">{i + 1}</TableCell>
                <TableCell>
                  <div className="text-sm font-medium">{u.name}</div>
                  <div className="text-xs text-white/30">{u.email}</div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={u.role === "super_admin" ? "text-primary border-primary/40 text-xs" : u.role === "admin" ? "text-blue-400 border-blue-400/40 text-xs" : "text-white/40 border-white/10 text-xs"}>{u.role}</Badge>
                </TableCell>
                <TableCell className="text-right font-mono text-sm">{u.videoCount}</TableCell>
                <TableCell className="text-right font-mono text-sm text-emerald-400">{u.completedCount}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ChartCard>

      <ChartCard title="Status Distribution" icon={<Activity className="w-3.5 h-3.5 text-orange-400" />} isLoading={isLoading}>
        <ResponsiveContainer width="100%" height={160}>
          <PieChart>
            <Pie data={statusPie} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" nameKey="name"
              label={({ name, percent }: { name: string; percent: number }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
              <Cell fill="#22c55e" />
              <Cell fill="#eab308" />
              <Cell fill="#ef4444" />
            </Pie>
            <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
            <Legend iconType="circle" wrapperStyle={{ fontSize: 11, color: "#ffffff60" }} />
          </PieChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Analytics Sub-Tab — Revenue
// ---------------------------------------------------------------------------
function AnalyticsRevenueTab() {
  const { data, isLoading } = useGetAnalyticsRevenue({ query: { queryKey: getGetAnalyticsRevenueQueryKey(), refetchInterval: 60000 } });

  const regionalPie = data ? [
    { name: "Indian Languages", value: data.regionalBreakdown.indian },
    { name: "Global Languages", value: data.regionalBreakdown.global },
  ] : [];

  return (
    <div className="space-y-5">
      <KpiRow items={[
        { label: "Total Revenue", value: data ? `$${data.totalRevenue.toFixed(2)}` : null, icon: <DollarSign className="w-4 h-4 text-emerald-400" />, sub: "All-time language purchases" },
        { label: "MRR (30d)", value: data ? `$${data.mrr.toFixed(2)}` : null, icon: <TrendingUp className="w-4 h-4 text-primary" />, sub: "Last 30 days" },
        { label: "Purchases", value: data?.totalPurchases, icon: <BarChart2 className="w-4 h-4 text-blue-400" />, sub: "Language unlocks" },
        { label: "Languages", value: data?.perLanguage.length, icon: <Languages className="w-4 h-4 text-purple-400" />, sub: "With revenue" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChartCard title="30-Day Revenue Trend" icon={<TrendingUp className="w-3.5 h-3.5 text-emerald-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={data?.dailyTrend ?? []} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
              <XAxis dataKey="date" tick={{ fontSize: 9, fill: "#ffffff40" }} tickFormatter={(v: string) => v.slice(5)} interval={6} />
              <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} tickFormatter={(v: number) => `$${v}`} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} labelStyle={{ color: "#ffffff60", fontSize: 11 }} formatter={(v: unknown) => [`$${Number(v).toFixed(2)}`, "Revenue"]} />
              <Area type="monotone" dataKey="revenue" stroke="#22c55e" fill="url(#revGrad)" strokeWidth={2} name="Revenue" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Regional Split" icon={<Globe className="w-3.5 h-3.5 text-cyan-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={regionalPie} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" nameKey="name"
                label={({ name, percent }: { name: string; percent: number }) => `${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                <Cell fill="#f97316" />
                <Cell fill="#3b82f6" />
              </Pie>
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} formatter={(v: unknown) => [`$${Number(v).toFixed(2)}`, ""]} />
              <Legend iconType="circle" wrapperStyle={{ fontSize: 11, color: "#ffffff60" }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <ChartCard title="Revenue by Language" icon={<DollarSign className="w-3.5 h-3.5 text-amber-400" />} isLoading={isLoading}>
        <ResponsiveContainer width="100%" height={Math.max(160, (data?.perLanguage.length ?? 0) * 24)}>
          <BarChart layout="vertical" data={data?.perLanguage.slice(0, 12) ?? []} margin={{ top: 4, right: 8, left: 60, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" horizontal={false} />
            <XAxis type="number" tick={{ fontSize: 9, fill: "#ffffff40" }} tickFormatter={(v: number) => `$${v}`} />
            <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: "#ffffff60" }} width={60} />
            <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} formatter={(v: unknown) => [`$${Number(v).toFixed(2)}`, "Revenue"]} />
            <Bar dataKey="revenue" radius={[0, 3, 3, 0]} name="Revenue">
              {(data?.perLanguage.slice(0, 12) ?? []).map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Analytics Sub-Tab — Videos
// ---------------------------------------------------------------------------
function AnalyticsVideosTab() {
  const { data, isLoading } = useGetAnalyticsVideos({ query: { queryKey: getGetAnalyticsVideosQueryKey(), refetchInterval: 30000 } });

  const durationLabels: Record<string, string> = {
    under_1min: "< 1 min", "1_10min": "1–10 min", "10_30min": "10–30 min",
    "30min_1hr": "30m–1h", "1_3hr": "1–3 hr", over_3hr: "3+ hr",
  };

  return (
    <div className="space-y-5">
      <KpiRow items={[
        { label: "Total Videos", value: data?.totalVideos, icon: <Film className="w-4 h-4 text-blue-400" /> },
        { label: "Completion Rate", value: data?.completionRate != null ? `${data.completionRate}%` : null, icon: <CheckCircle2 className="w-4 h-4 text-emerald-400" />, sub: "Completed / (completed + failed)" },
        { label: "Avg Render Time", value: data?.avgRenderSeconds != null ? `${data.avgRenderSeconds}s` : null, icon: <Clock className="w-4 h-4 text-amber-400" /> },
        { label: "Cinema Mode Rate", value: data ? `${data.cinemaModeRate}%` : null, icon: <Activity className="w-4 h-4 text-primary" />, sub: `${data?.totalDurationHours ?? 0}h total duration` },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChartCard title="Style Distribution" icon={<Film className="w-3.5 h-3.5 text-blue-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={data?.styleDistribution ?? []} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
              <XAxis dataKey="style" tick={{ fontSize: 9, fill: "#ffffff40" }} />
              <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} allowDecimals={false} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
              <Bar dataKey="count" name="Videos" radius={[3, 3, 0, 0]}>
                {(data?.styleDistribution ?? []).map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Status Distribution" icon={<Activity className="w-3.5 h-3.5 text-orange-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={data?.statusDistribution ?? []} cx="50%" cy="50%" innerRadius={55} outerRadius={80} dataKey="count" nameKey="status"
                label={({ status, percent }: { status: string; percent: number }) => `${status} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                {(data?.statusDistribution ?? []).map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChartCard title="Resolution Distribution" icon={<Layers className="w-3.5 h-3.5 text-purple-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={data?.resolutionDistribution ?? []} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
              <XAxis dataKey="resolution" tick={{ fontSize: 10, fill: "#ffffff40" }} />
              <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} allowDecimals={false} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
              <Bar dataKey="count" name="Videos" fill="#a855f7" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Duration Buckets" icon={<Clock className="w-3.5 h-3.5 text-cyan-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={(data?.durationBuckets ?? []).map(b => ({ ...b, name: durationLabels[b.label] ?? b.label }))} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
              <XAxis dataKey="name" tick={{ fontSize: 9, fill: "#ffffff40" }} />
              <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} allowDecimals={false} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
              <Bar dataKey="count" name="Videos" fill="#06b6d4" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <ChartCard title="30-Day Video Creation Trend" icon={<TrendingUp className="w-3.5 h-3.5 text-primary" />} isLoading={isLoading}>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={data?.dailyCreationTrend ?? []} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
            <defs>
              <linearGradient id="vidGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
            <XAxis dataKey="date" tick={{ fontSize: 9, fill: "#ffffff40" }} tickFormatter={(v: string) => v.slice(5)} interval={6} />
            <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} allowDecimals={false} />
            <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
            <Area type="monotone" dataKey="count" stroke="#3b82f6" fill="url(#vidGrad)" strokeWidth={2} name="Videos Created" />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChartCard title="Color Grade Distribution" icon={<Palette className="w-3.5 h-3.5 text-pink-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={data?.colorGradeDistribution ?? []} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
              <XAxis dataKey="colorGrade" tick={{ fontSize: 9, fill: "#ffffff40" }} />
              <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} allowDecimals={false} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
              <Bar dataKey="count" name="Videos" fill="#ec4899" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Input Type Distribution" icon={<FileText className="w-3.5 h-3.5 text-amber-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={data?.inputTypeDistribution ?? []} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="count" nameKey="inputType"
                label={({ inputType, percent }: { inputType: string; percent: number }) => `${inputType} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                {(data?.inputTypeDistribution ?? []).map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Analytics Sub-Tab — GPU
// ---------------------------------------------------------------------------
function AnalyticsGpuTab() {
  const { data, isLoading } = useGetAnalyticsGpu({ query: { queryKey: getGetAnalyticsGpuQueryKey(), refetchInterval: 10000 } });

  const workerPie = data ? [
    { name: "GPU Workers", value: data.workerTypeDistribution.gpu },
    { name: "CPU Workers", value: data.workerTypeDistribution.cpu },
  ] : [];

  const queuePie = data ? [
    { name: "Enterprise", value: data.priorityQueue.enterprise },
    { name: "Paid", value: data.priorityQueue.paid },
    { name: "Free", value: data.priorityQueue.free },
  ] : [];

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-xs text-muted-foreground">Refreshes every 10s</span>
      </div>

      <KpiRow items={[
        { label: "Active Jobs", value: data?.activeJobs, icon: <Activity className="w-4 h-4 text-orange-400" />, sub: `${data?.gpuJobs ?? 0} GPU · ${data?.cpuJobs ?? 0} CPU` },
        { label: "Queue Depth", value: data?.queueDepth, icon: <Layers className="w-4 h-4 text-yellow-400" />, sub: "Pending renders" },
        { label: "Utilization", value: data ? `${data.utilization}%` : null, icon: <Gauge className="w-4 h-4 text-blue-400" /> },
        { label: "Compute Hours", value: data ? `${data.estimatedComputeHours}h` : null, icon: <Cpu className="w-4 h-4 text-purple-400" />, sub: "Last 30 days" },
      ]} />

      <KpiRow items={[
        { label: "Completed Today", value: data?.completedToday, icon: <CheckCircle2 className="w-4 h-4 text-emerald-400" /> },
        { label: "Failed Today", value: data?.failedToday, icon: <AlertTriangle className="w-4 h-4 text-red-400" /> },
        { label: "Avg Render Time", value: data?.avgRenderSeconds != null ? `${data.avgRenderSeconds}s` : null, icon: <Clock className="w-4 h-4 text-cyan-400" /> },
        { label: "GPU Workers", value: data?.workerTypeDistribution.gpu, icon: <CircuitBoard className="w-4 h-4 text-primary" />, sub: "All-time GPU renders" },
      ]} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ChartCard title="Worker Type Distribution" icon={<Cpu className="w-3.5 h-3.5 text-primary" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={workerPie} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" nameKey="name"
                label={({ name, percent }: { name: string; percent: number }) => `${(name as string).replace(" Workers", "")} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                <Cell fill="#eab308" />
                <Cell fill="#3b82f6" />
              </Pie>
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
              <Legend iconType="circle" wrapperStyle={{ fontSize: 11, color: "#ffffff60" }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Queue by Priority" icon={<Zap className="w-3.5 h-3.5 text-amber-400" />} isLoading={isLoading}>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={queuePie} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" nameKey="name"
                label={({ name, percent }: { name: string; percent: number }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                <Cell fill="#a855f7" />
                <Cell fill="#3b82f6" />
                <Cell fill="#6b7280" />
              </Pie>
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
              <Legend iconType="circle" wrapperStyle={{ fontSize: 11, color: "#ffffff60" }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <ChartCard title="30-Day Render Throughput" icon={<TrendingUp className="w-3.5 h-3.5 text-emerald-400" />} isLoading={isLoading}>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={data?.dailyThroughput ?? []} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
            <defs>
              <linearGradient id="gpuGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" />
            <XAxis dataKey="date" tick={{ fontSize: 9, fill: "#ffffff40" }} tickFormatter={(v: string) => v.slice(5)} interval={6} />
            <YAxis tick={{ fontSize: 9, fill: "#ffffff40" }} allowDecimals={false} />
            <Tooltip contentStyle={{ background: "#111", border: "1px solid #ffffff15", borderRadius: 8 }} />
            <Area type="monotone" dataKey="count" stroke="#a855f7" fill="url(#gpuGrad)" strokeWidth={2} name="Jobs Completed" />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Analytics Tab (super_admin only) — master container with live overview + sub-tabs
// ---------------------------------------------------------------------------
function AnalyticsTab() {
  const { data: realtime, isLoading: rtLoading, dataUpdatedAt } = useGetRealtimeAnalytics(
    { query: { queryKey: getGetRealtimeAnalyticsQueryKey(), refetchInterval: 5000 } }
  );
  const lastUpdated = dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString() : null;

  return (
    <div className="space-y-5">
      {/* Live KPI strip */}
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-xs text-muted-foreground">Live platform overview · refreshes every 5s</span>
        {lastUpdated && <span className="text-xs text-white/25">· {lastUpdated}</span>}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2">
        {[
          { label: "Users", value: realtime?.totalUsers, color: "text-primary" },
          { label: "Active", value: realtime?.activeUsers, color: "text-emerald-400" },
          { label: "Videos", value: realtime?.totalVideos, color: "text-blue-400" },
          { label: "Today", value: realtime?.videosToday, color: "text-cyan-400" },
          { label: "Processing", value: realtime?.activeRenderJobs, color: "text-orange-400" },
          { label: "Completed", value: realtime?.completedJobs, color: "text-emerald-400" },
          { label: "Failed", value: realtime?.failedJobs, color: "text-red-400" },
          { label: "Storage", value: realtime ? `${realtime.totalStorageGb}GB` : "—", color: "text-purple-400" },
        ].map((item) => (
          <div key={item.label} className="bg-background/50 border border-white/5 rounded-lg px-3 py-2 text-center">
            {rtLoading ? <Skeleton className="h-5 w-full" /> : <div className={`text-lg font-bold font-display ${item.color}`}>{item.value ?? "—"}</div>}
            <div className="text-[10px] text-white/30 uppercase tracking-wide">{item.label}</div>
          </div>
        ))}
      </div>

      {/* Sub-tabs */}
      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid grid-cols-4 w-full max-w-lg bg-background/50 border border-white/10">
          <TabsTrigger value="users" className="text-xs gap-1.5"><Users className="w-3 h-3" />Users</TabsTrigger>
          <TabsTrigger value="revenue" className="text-xs gap-1.5"><DollarSign className="w-3 h-3" />Revenue</TabsTrigger>
          <TabsTrigger value="videos" className="text-xs gap-1.5"><Film className="w-3 h-3" />Videos</TabsTrigger>
          <TabsTrigger value="gpu" className="text-xs gap-1.5"><Cpu className="w-3 h-3" />GPU</TabsTrigger>
        </TabsList>
        <TabsContent value="users" className="mt-5"><AnalyticsUsersTab /></TabsContent>
        <TabsContent value="revenue" className="mt-5"><AnalyticsRevenueTab /></TabsContent>
        <TabsContent value="videos" className="mt-5"><AnalyticsVideosTab /></TabsContent>
        <TabsContent value="gpu" className="mt-5"><AnalyticsGpuTab /></TabsContent>
      </Tabs>
    </div>
  );
}

type AccentColor = "primary" | "green" | "yellow" | "blue" | "cyan" | "indigo" | "orange" | "red" | "purple" | "pink";

const ACCENT_CLASS: Record<AccentColor, string> = {
  primary: "text-primary",
  green: "text-emerald-400",
  yellow: "text-yellow-400",
  blue: "text-blue-400",
  cyan: "text-cyan-400",
  indigo: "text-indigo-400",
  orange: "text-orange-400",
  red: "text-red-400",
  purple: "text-purple-400",
  pink: "text-pink-400",
};

function MetricCard({ icon, label, value, isLoading, accent = "primary" }: {
  icon: React.ReactNode;
  label: string;
  value?: number | string;
  isLoading: boolean;
  accent?: AccentColor;
}) {
  return (
    <Card className="bg-card border-white/5">
      <CardContent className="pt-4 pb-4">
        <div className="flex items-center gap-2 text-white/50 text-xs mb-2">
          {icon}
          {label}
        </div>
        {isLoading ? (
          <Skeleton className="h-8 w-16" />
        ) : (
          <div className={`text-2xl font-display font-bold ${ACCENT_CLASS[accent]}`}>
            {value ?? 0}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// System Tab (super_admin only) — Maintenance Mode
// ---------------------------------------------------------------------------
function SystemTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useGetPlatformSettings({
    query: { queryKey: getGetPlatformSettingsQueryKey(), staleTime: 10000 }
  });
  const updateSettings = useUpdatePlatformSettings();

  const [message, setMessage] = useState<string | null>(null);
  const displayMessage = message !== null ? message : (settings?.maintenanceMessage ?? "");

  const handleToggle = async (enabled: boolean) => {
    try {
      await updateSettings.mutateAsync({
        data: { maintenanceMode: enabled, maintenanceMessage: displayMessage },
      });
      queryClient.invalidateQueries({ queryKey: getGetPlatformSettingsQueryKey() });
      toast({ title: enabled ? "Maintenance mode ENABLED" : "Maintenance mode disabled" });
    } catch {
      toast({ title: "Failed to update maintenance mode", variant: "destructive" });
    }
  };

  const handleSaveMessage = async () => {
    if (message === null) return;
    try {
      await updateSettings.mutateAsync({
        data: { maintenanceMessage: message },
      });
      queryClient.invalidateQueries({ queryKey: getGetPlatformSettingsQueryKey() });
      toast({ title: "Maintenance message saved" });
      setMessage(null);
    } catch {
      toast({ title: "Failed to save message", variant: "destructive" });
    }
  };

  const isMaintenanceOn = settings?.maintenanceMode ?? false;

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Danger zone info */}
      <div className="flex items-start gap-3 p-4 bg-red-500/5 border border-red-500/20 rounded-xl">
        <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
        <div>
          <div className="text-sm font-semibold text-red-300">Super Admin System Controls</div>
          <div className="text-xs text-white/40 mt-0.5">
            These settings affect all users on the platform. Use with care.
          </div>
        </div>
      </div>

      {/* Character Identity Global Toggle */}
      <Card className="bg-card border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <span className="text-lg">🎭</span>
                Character Identity Feature
              </CardTitle>
              <CardDescription className="mt-1">
                Globally enable or disable the Character Identity (face + voice personalization) feature for all users.
                Individual user access is still controlled by per-user privileges.
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              {isLoading ? (
                <Skeleton className="w-12 h-6" />
              ) : (
                <>
                  <Label
                    htmlFor="char-identity-toggle"
                    className={(settings as any)?.characterIdentityEnabled !== false ? "text-emerald-400 font-semibold" : "text-muted-foreground"}
                  >
                    {(settings as any)?.characterIdentityEnabled !== false ? "ON" : "OFF"}
                  </Label>
                  <Switch
                    id="char-identity-toggle"
                    checked={(settings as any)?.characterIdentityEnabled !== false}
                    onCheckedChange={async (enabled) => {
                      try {
                        await updateSettings.mutateAsync({ data: { characterIdentityEnabled: enabled } as any });
                        queryClient.invalidateQueries({ queryKey: getGetPlatformSettingsQueryKey() });
                        toast({ title: enabled ? "Character Identity enabled globally" : "Character Identity disabled globally" });
                      } catch {
                        toast({ title: "Failed to update setting", variant: "destructive" });
                      }
                    }}
                    disabled={updateSettings.isPending}
                  />
                </>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Maintenance Mode Card */}
      <Card className={`bg-card border-${isMaintenanceOn ? "red" : "white"}/10 transition-colors`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Server className="w-5 h-5 text-muted-foreground" />
                Maintenance Mode
              </CardTitle>
              <CardDescription className="mt-1">
                When enabled, all non-super-admin users will see a maintenance screen.
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              {isLoading ? (
                <Skeleton className="w-12 h-6" />
              ) : (
                <>
                  <Label htmlFor="maintenance-toggle" className={isMaintenanceOn ? "text-red-400 font-semibold" : "text-muted-foreground"}>
                    {isMaintenanceOn ? "ON" : "OFF"}
                  </Label>
                  <Switch
                    id="maintenance-toggle"
                    checked={isMaintenanceOn}
                    onCheckedChange={handleToggle}
                    disabled={updateSettings.isPending}
                    className="data-[state=checked]:bg-red-500"
                  />
                </>
              )}
            </div>
          </div>
        </CardHeader>
        {isMaintenanceOn && (
          <CardContent>
            <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg mb-4">
              <Wifi className="w-4 h-4 text-red-400" />
              <span className="text-sm text-red-300 font-medium">Maintenance mode is currently ACTIVE. Users are seeing the maintenance screen.</span>
            </div>
          </CardContent>
        )}

        {/* Maintenance Message */}
        <CardContent className={isMaintenanceOn ? "pt-0" : ""}>
          <label className="text-xs text-muted-foreground mb-2 block">Maintenance Message</label>
          {isLoading ? (
            <Skeleton className="h-20 w-full" />
          ) : (
            <>
              <Textarea
                value={displayMessage}
                onChange={e => setMessage(e.target.value)}
                rows={3}
                placeholder="The system is currently under maintenance. Please check back soon."
                className="bg-background/50 border-white/10 resize-none"
              />
              {message !== null && (
                <div className="flex gap-2 mt-2">
                  <Button size="sm" onClick={handleSaveMessage} disabled={updateSettings.isPending}>
                    {updateSettings.isPending && <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />}
                    Save Message
                  </Button>
                  <Button size="sm" variant="outline" className="border-white/10" onClick={() => setMessage(null)}>
                    Discard
                  </Button>
                </div>
              )}
            </>
          )}
          {settings?.updatedAt && (
            <p className="text-xs text-white/25 mt-2 flex items-center gap-1">
              <Clock className="w-3 h-3" /> Last updated {new Date(settings.updatedAt).toLocaleString()}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Language Management panel (admin)
// ---------------------------------------------------------------------------
function LanguageManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: languages, isLoading } = useAdminListLanguages();
  const updateLang = useAdminUpdateLanguage();

  const [editingPrice, setEditingPrice] = useState<Record<string, string>>({});

  const handleToggle = async (id: string, enabled: boolean) => {
    try {
      await updateLang.mutateAsync({ id, data: { enabled: !enabled } });
      toast({ title: `Language ${!enabled ? "enabled" : "disabled"} successfully` });
      queryClient.invalidateQueries({ queryKey: getAdminListLanguagesQueryKey() });
    } catch {
      toast({ title: "Failed to update language", variant: "destructive" });
    }
  };

  const handlePriceSave = async (id: string, currentPrice: number) => {
    const raw = editingPrice[id];
    if (raw === undefined) return;
    const price = parseFloat(raw);
    if (isNaN(price) || price < 0) {
      toast({ title: "Invalid price", variant: "destructive" });
      return;
    }
    try {
      await updateLang.mutateAsync({ id, data: { priceUsd: price } });
      toast({ title: "Price updated" });
      queryClient.invalidateQueries({ queryKey: getAdminListLanguagesQueryKey() });
      setEditingPrice(prev => { const n = { ...prev }; delete n[id]; return n; });
    } catch {
      toast({ title: "Failed to update price", variant: "destructive" });
    }
  };

  const indian = (languages ?? []).filter(l => l.region === "indian");
  const global_ = (languages ?? []).filter(l => l.region === "global");

  const renderGroup = (title: string, icon: React.ReactNode, langs: typeof languages) => (
    <Card className="bg-card border-white/5">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          {icon}{title}
          <Badge variant="outline" className="ml-auto text-xs">{langs?.length ?? 0} languages</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-white/5">
                <TableHead className="w-8"></TableHead>
                <TableHead>Language</TableHead>
                <TableHead>Native Script</TableHead>
                <TableHead>Dialects</TableHead>
                <TableHead>Price (USD)</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {langs?.map(lang => (
                <TableRow key={lang.id} className={`border-white/5 ${!lang.enabled ? "opacity-40" : ""}`}>
                  <TableCell className="text-lg">{lang.flag}</TableCell>
                  <TableCell>
                    <div className="font-medium text-sm">{lang.name}</div>
                    {lang.isDefault && (
                      <Badge className="bg-amber-500/10 text-amber-400 border-0 text-xs mt-0.5">Default · Free</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-white/50 text-sm">{lang.nativeName}</TableCell>
                  <TableCell className="text-white/60 text-sm">{lang.dialects}</TableCell>
                  <TableCell>
                    {lang.isDefault ? (
                      <span className="text-amber-400 font-medium text-sm">Free</span>
                    ) : editingPrice[lang.id] !== undefined ? (
                      <div className="flex items-center gap-2">
                        <div className="flex items-center bg-background border border-white/10 rounded-lg px-2">
                          <DollarSign className="w-3 h-3 text-white/30" />
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={editingPrice[lang.id]}
                            onChange={e => setEditingPrice(prev => ({ ...prev, [lang.id]: e.target.value }))}
                            className="w-16 bg-transparent text-sm py-1 outline-none"
                          />
                        </div>
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-emerald-400"
                          onClick={() => handlePriceSave(lang.id, lang.priceUsd)}>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-white/30"
                          onClick={() => setEditingPrice(prev => { const n = { ...prev }; delete n[lang.id]; return n; })}>
                          ✕
                        </Button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setEditingPrice(prev => ({ ...prev, [lang.id]: lang.priceUsd.toString() }))}
                        className="flex items-center gap-1 text-sm text-white/70 hover:text-white transition-colors group"
                      >
                        <DollarSign className="w-3.5 h-3.5 text-white/30 group-hover:text-white/60" />
                        {lang.priceUsd.toFixed(2)}
                        <span className="text-xs text-white/20 group-hover:text-white/40 ml-1">(edit)</span>
                      </button>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge className={lang.enabled
                      ? "bg-emerald-500/10 text-emerald-400 border-0 text-xs"
                      : "bg-white/5 text-white/30 border-0 text-xs"}>
                      {lang.enabled ? "Enabled" : "Disabled"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleToggle(lang.id, lang.enabled)}
                      disabled={updateLang.isPending}
                      className={`h-8 px-3 text-xs ${lang.enabled ? "text-red-400 hover:text-red-300" : "text-emerald-400 hover:text-emerald-300"}`}
                    >
                      {lang.enabled
                        ? <><ToggleRight className="w-3.5 h-3.5 mr-1" />Disable</>
                        : <><ToggleLeft className="w-3.5 h-3.5 mr-1" />Enable</>}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3 p-4 bg-amber-500/5 border border-amber-500/15 rounded-xl">
        <Languages className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <div className="text-sm font-semibold text-amber-300">Language Monetization Control</div>
          <div className="text-xs text-white/40 mt-0.5">
            Hindi is the default free language. All other languages require per-purchase unlock. Set prices and enable/disable availability below.
          </div>
        </div>
      </div>
      {renderGroup("Indian Languages", <span className="text-base">🇮🇳</span>, indian)}
      {renderGroup("Global Languages", <Globe className="w-4 h-4 text-blue-400" />, global_)}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Ad Management panel (admin)
// ---------------------------------------------------------------------------

const STATUS_COLORS: Record<string, string> = {
  active: "bg-green-500/20 text-green-400",
  scheduled: "bg-blue-500/20 text-blue-400",
  paused: "bg-yellow-500/20 text-yellow-400",
  draft: "bg-white/10 text-white/50",
  expired: "bg-red-500/20 text-red-400",
};

function AdManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const isSuperAdmin = user?.role === "super_admin";

  const { data: ads, isLoading } = useAdminListAds();
  const { data: platformSettings } = useGetPlatformSettings();
  const updateSettings = useUpdatePlatformSettings();

  const createAd = useAdminCreateAd();
  const updateAd = useAdminUpdateAd();
  const deleteAd = useAdminDeleteAd();

  const [analyticsAdId, setAnalyticsAdId] = useState<string | null>(null);
  const { data: analytics } = useAdminGetAdAnalytics(analyticsAdId ?? "", {
    query: { queryKey: getAdminListAdsQueryKey(), enabled: !!analyticsAdId },
  });

  const emptyForm: {
    title: string; description: string; type: AdType; mediaUrl: string;
    targetUrl: string; ctaText: string; placement: AdPlacement; status: AdStatus;
    scheduledAt: string | null; expiresAt: string | null;
  } = {
    title: "", description: "", type: "image", mediaUrl: "", targetUrl: "",
    ctaText: "Learn More", placement: "gallery", status: "draft",
    scheduledAt: null, expiresAt: null,
  };

  const [formOpen, setFormOpen] = useState(false);
  const [editingAd, setEditingAd] = useState<Ad | null>(null);
  const [form, setForm] = useState(emptyForm);

  const openCreate = () => { setEditingAd(null); setForm(emptyForm); setFormOpen(true); };
  const openEdit = (ad: Ad) => {
    setEditingAd(ad);
    setForm({
      title: ad.title, description: ad.description ?? "", type: ad.type,
      mediaUrl: ad.mediaUrl, targetUrl: ad.targetUrl, ctaText: ad.ctaText,
      placement: ad.placement, status: ad.status,
      scheduledAt: ad.scheduledAt ? ad.scheduledAt.slice(0, 16) : null,
      expiresAt: ad.expiresAt ? ad.expiresAt.slice(0, 16) : null,
    });
    setFormOpen(true);
  };

  const handleSave = async () => {
    try {
      const payload = { ...form, scheduledAt: form.scheduledAt || null, expiresAt: form.expiresAt || null };
      if (editingAd) {
        await updateAd.mutateAsync({ id: editingAd.id, data: payload });
        toast({ title: "Ad updated" });
      } else {
        await createAd.mutateAsync({ data: payload });
        toast({ title: "Ad created" });
      }
      queryClient.invalidateQueries({ queryKey: getAdminListAdsQueryKey() });
      setFormOpen(false);
    } catch { toast({ title: "Failed to save ad", variant: "destructive" }); }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteAd.mutateAsync({ id });
      toast({ title: "Ad deleted" });
      queryClient.invalidateQueries({ queryKey: getAdminListAdsQueryKey() });
    } catch { toast({ title: "Failed to delete ad", variant: "destructive" }); }
  };

  const handleToggleAds = async (enabled: boolean) => {
    try {
      await updateSettings.mutateAsync({ data: { adsEnabled: enabled } });
      queryClient.invalidateQueries({ queryKey: getGetPlatformSettingsQueryKey() });
      toast({
        title: enabled ? "Ad system enabled" : "Ad system disabled",
        description: enabled
          ? "Ads will now be served to eligible free users."
          : "Ads are now hidden for all users.",
      });
    } catch {
      toast({ title: "Failed to update ad system", variant: "destructive" });
    }
  };

  const adsEnabled = platformSettings?.adsEnabled ?? false;

  return (
    <div className="space-y-4">

      {/* Global Toggle — super_admin only */}
      {isSuperAdmin && (
        <Card className={`border ${adsEnabled ? "bg-emerald-950/30 border-emerald-500/30" : "bg-white/5 border-white/10"} transition-colors`}>
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${adsEnabled ? "bg-emerald-500/20" : "bg-white/10"}`}>
                  <Megaphone className={`w-4 h-4 ${adsEnabled ? "text-emerald-400" : "text-white/40"}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-white">Global Ad System</span>
                    <Badge className={adsEnabled ? "bg-emerald-500/20 text-emerald-400 border-0 text-xs" : "bg-white/10 text-white/40 border-0 text-xs"}>
                      {adsEnabled ? "ON" : "OFF"}
                    </Badge>
                  </div>
                  <p className="text-xs text-white/40 mt-0.5">
                    {adsEnabled
                      ? "Ads are live. Free users see eligible ads. Paid users are always exempt."
                      : "Ads are disabled globally. No user sees any ad regardless of status."}
                  </p>
                </div>
              </div>
              <Switch
                checked={adsEnabled}
                onCheckedChange={handleToggleAds}
                disabled={updateSettings.isPending}
                className="data-[state=checked]:bg-emerald-500"
              />
            </div>
            {adsEnabled && (
              <div className="mt-3 pt-3 border-t border-white/10 grid grid-cols-3 gap-3 text-xs text-white/50">
                <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> Free users: can see ads</div>
                <div className="flex items-center gap-1.5"><Shield className="w-3 h-3 text-amber-400" /> Paid/VIP: always ad-free</div>
                <div className="flex items-center gap-1.5"><Shield className="w-3 h-3 text-blue-400" /> Admins: always ad-free</div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-white/5 border-white/10"><CardContent className="pt-4 pb-4"><div className="flex items-center gap-2 text-white/50 text-xs mb-1"><Eye className="w-3.5 h-3.5" /> Total Impressions</div><div className="text-2xl font-bold text-white">{ads?.reduce((s, a) => s + a.impressions, 0) ?? 0}</div></CardContent></Card>
        <Card className="bg-white/5 border-white/10"><CardContent className="pt-4 pb-4"><div className="flex items-center gap-2 text-white/50 text-xs mb-1"><MousePointer className="w-3.5 h-3.5" /> Total Clicks</div><div className="text-2xl font-bold text-white">{ads?.reduce((s, a) => s + a.clicks, 0) ?? 0}</div></CardContent></Card>
        <Card className="bg-white/5 border-white/10"><CardContent className="pt-4 pb-4"><div className="flex items-center gap-2 text-white/50 text-xs mb-1"><Megaphone className="w-3.5 h-3.5" /> Active Ads</div><div className="text-2xl font-bold text-white">{ads?.filter((a) => a.status === "active").length ?? 0}</div></CardContent></Card>
      </div>

      <Card className="bg-card border-white/5">
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <div>
            <CardTitle className="flex items-center gap-2"><Megaphone className="w-4 h-4 text-purple-400" /> Ad Management</CardTitle>
            <CardDescription>Create and manage promotional ads. Ads only show to free users when the global system is ON.</CardDescription>
          </div>
          <Button onClick={openCreate} className="bg-purple-600 hover:bg-purple-500 text-white" size="sm">
            <Plus className="w-4 h-4 mr-1.5" /> New Ad
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 bg-white/5" />)}</div>
          ) : !ads || ads.length === 0 ? (
            <div className="text-center py-12 text-white/40"><Megaphone className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No ads yet.</p></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-white/10">
                  <TableHead className="text-white/50">Title</TableHead>
                  <TableHead className="text-white/50">Type</TableHead>
                  <TableHead className="text-white/50">Placement</TableHead>
                  <TableHead className="text-white/50">Status</TableHead>
                  <TableHead className="text-white/50 text-right">Impr.</TableHead>
                  <TableHead className="text-white/50 text-right">Clicks</TableHead>
                  <TableHead className="text-white/50 text-right">CTR</TableHead>
                  <TableHead className="text-white/50"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ads.map((ad) => {
                  const ctr = ad.impressions > 0 ? ((ad.clicks / ad.impressions) * 100).toFixed(1) : "0.0";
                  return (
                    <TableRow key={ad.id} className="border-white/5 hover:bg-white/5">
                      <TableCell>
                        <div className="font-medium text-white text-sm">{ad.title}</div>
                        <a href={ad.targetUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-purple-400 hover:text-purple-300 flex items-center gap-0.5 mt-0.5">
                          {ad.targetUrl.slice(0, 30)}... <ExternalLink className="w-3 h-3" />
                        </a>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="text-xs border-white/10 text-white/60 capitalize">{ad.type}</Badge></TableCell>
                      <TableCell><Badge variant="outline" className="text-xs border-white/10 text-white/60 capitalize">{ad.placement}</Badge></TableCell>
                      <TableCell><Badge className={`text-xs ${STATUS_COLORS[ad.status] ?? "bg-white/10 text-white/50"}`}>{ad.status}</Badge></TableCell>
                      <TableCell className="text-right text-sm text-white/70">{ad.impressions.toLocaleString()}</TableCell>
                      <TableCell className="text-right text-sm text-white/70">{ad.clicks.toLocaleString()}</TableCell>
                      <TableCell className="text-right text-sm text-white/70">{ctr}%</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="w-7 h-7 text-white/40 hover:text-white" onClick={() => setAnalyticsAdId(ad.id)}><BarChart2 className="w-3.5 h-3.5" /></Button>
                          <Button variant="ghost" size="icon" className="w-7 h-7 text-white/40 hover:text-white" onClick={() => openEdit(ad)}><Edit2 className="w-3.5 h-3.5" /></Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="w-7 h-7 text-red-400/50 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-background border-white/10">
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete ad?</AlertDialogTitle>
                                <AlertDialogDescription>This will permanently delete "{ad.title}" and all analytics data.</AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDelete(ad.id)} className="bg-red-600 hover:bg-red-500">Delete</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {analyticsAdId && analytics && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-white text-base flex items-center gap-2"><BarChart2 className="w-4 h-4 text-purple-400" /> Analytics: {analytics.title}</CardTitle>
            <Button variant="ghost" size="icon" className="text-white/40 hover:text-white w-7 h-7" onClick={() => setAnalyticsAdId(null)}><X className="w-4 h-4" /></Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="text-center p-3 rounded-lg bg-white/5"><div className="text-2xl font-bold text-white">{analytics.impressions.toLocaleString()}</div><div className="text-xs text-white/40 mt-1 flex items-center justify-center gap-1"><Eye className="w-3 h-3" /> Impressions</div></div>
              <div className="text-center p-3 rounded-lg bg-white/5"><div className="text-2xl font-bold text-white">{analytics.clicks.toLocaleString()}</div><div className="text-xs text-white/40 mt-1 flex items-center justify-center gap-1"><MousePointer className="w-3 h-3" /> Clicks</div></div>
              <div className="text-center p-3 rounded-lg bg-white/5"><div className="text-2xl font-bold text-white">{(analytics.ctr * 100).toFixed(2)}%</div><div className="text-xs text-white/40 mt-1">Click-through rate</div></div>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="bg-background border-white/10 max-w-lg">
          <DialogHeader><DialogTitle className="text-white">{editingAd ? "Edit Ad" : "Create New Ad"}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><label className="text-xs text-white/50 mb-1 block">Title *</label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="Ad title" /></div>
            <div><label className="text-xs text-white/50 mb-1 block">Description</label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="Short description" /></div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-white/50 mb-1 block">Type *</label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as typeof form.type })}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-background border-white/10">
                    <SelectItem value="image">Image</SelectItem>
                    <SelectItem value="video">Video</SelectItem>
                    <SelectItem value="banner">Banner</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-white/50 mb-1 block">Placement *</label>
                <Select value={form.placement} onValueChange={(v) => setForm({ ...form, placement: v as typeof form.placement })}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-background border-white/10">
                    <SelectItem value="sidebar">Sidebar</SelectItem>
                    <SelectItem value="gallery">Gallery</SelectItem>
                    <SelectItem value="dashboard">Dashboard</SelectItem>
                    <SelectItem value="top_banner">Top Banner</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-white/50 mb-1 block">Status</label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as typeof form.status })}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-background border-white/10">
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="paused">Paused</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><label className="text-xs text-white/50 mb-1 block">Media URL *</label><Input value={form.mediaUrl} onChange={(e) => setForm({ ...form, mediaUrl: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="https://..." /></div>
            <div><label className="text-xs text-white/50 mb-1 block">Target URL *</label><Input value={form.targetUrl} onChange={(e) => setForm({ ...form, targetUrl: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="https://..." /></div>
            <div><label className="text-xs text-white/50 mb-1 block">CTA Text</label><Input value={form.ctaText} onChange={(e) => setForm({ ...form, ctaText: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="Learn More" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-white/50 mb-1 block flex items-center gap-1"><CalendarIcon className="w-3 h-3" /> Scheduled Start</label>
                <Input
                  type="datetime-local"
                  value={form.scheduledAt ?? ""}
                  onChange={(e) => setForm({ ...form, scheduledAt: e.target.value || null, status: e.target.value ? "scheduled" : form.status })}
                  className="bg-white/5 border-white/10 text-white text-xs"
                />
              </div>
              <div>
                <label className="text-xs text-white/50 mb-1 block flex items-center gap-1"><CalendarIcon className="w-3 h-3" /> Expiry Date</label>
                <Input
                  type="datetime-local"
                  value={form.expiresAt ?? ""}
                  onChange={(e) => setForm({ ...form, expiresAt: e.target.value || null })}
                  className="bg-white/5 border-white/10 text-white text-xs"
                />
              </div>
            </div>
            <p className="text-xs text-white/30">Leave dates empty for an immediately active ad with no expiry.</p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setFormOpen(false)} className="text-white/60">Cancel</Button>
            <Button onClick={handleSave} disabled={createAd.isPending || updateAd.isPending} className="bg-purple-600 hover:bg-purple-500 text-white">
              {(createAd.isPending || updateAd.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {editingAd ? "Save Changes" : "Create Ad"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------------------------------------------------------------------------
// API Platform Tab
// ---------------------------------------------------------------------------
function ApiPlatformTab() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [detailTab, setDetailTab] = useState<"keys" | "users" | "logs">("keys");
  const [transferUser, setTransferUser] = useState<{ id: string; name: string; email: string } | null>(null);
  const [renewKeyId, setRenewKeyId] = useState<string | null>(null);
  const [renewDays, setRenewDays] = useState(365);

  const { data: stats, isLoading: statsLoading } = useGetApiPlatformStats({
    query: { queryKey: getGetApiPlatformStatsQueryKey(), refetchInterval: 10000 },
  });
  const { data: clients = [], isLoading: clientsLoading } = useListApiClients({
    query: { queryKey: getListApiClientsQueryKey() },
  });

  const createClient = useCreateApiClient();
  const updateClientStatus = useUpdateApiClientStatus();
  const deleteClient = useDeleteApiClient();
  const createKey = useCreateApiKey();
  const updateKeyStatus = useUpdateApiKeyStatus();
  const deleteKey = useDeleteApiKey();

  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const selectedClient = clients.find((c) => c.id === selectedClientId) ?? null;

  const { data: keys = [], isLoading: keysLoading } = useListApiKeys(selectedClientId ?? "", {
    query: { queryKey: getListApiKeysQueryKey(selectedClientId ?? ""), enabled: !!selectedClientId },
  });

  const [newClientOpen, setNewClientOpen] = useState(false);
  const [clientForm, setClientForm] = useState({ name: "", email: "", company: "", notes: "" });

  const [newKeyOpen, setNewKeyOpen] = useState(false);
  const [keyForm, setKeyForm] = useState({ name: "", validDays: 365, pricingTier: "standard", priceUsd: 99, requestLimitPerDay: 1000 });

  const [revealedKey, setRevealedKey] = useState<string | null>(null);
  const [revealedKeyName, setRevealedKeyName] = useState("");
  const [copied, setCopied] = useState(false);

  const renewKey = useRenewApiKey();
  const updateApiUserStatus = useUpdateApiClientUserStatus();
  const transferApiUser = useTransferApiClientUser();
  const deleteApiUser = useDeleteApiClientUser();

  const { data: apiUsers = [], isLoading: usersLoading } = useListApiClientUsers(selectedClientId ?? "", {
    query: { queryKey: getListApiClientUsersQueryKey(selectedClientId ?? ""), enabled: !!selectedClientId && detailTab === "users" },
  });

  const { data: logs = [], isLoading: logsLoading } = useGetApiClientLogs(selectedClientId ?? "", undefined, {
    query: { queryKey: getGetApiClientLogsQueryKey(selectedClientId ?? ""), enabled: !!selectedClientId && detailTab === "logs", refetchInterval: detailTab === "logs" ? 15000 : false },
  });

  const refetchAll = () => {
    qc.invalidateQueries({ queryKey: getListApiClientsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetApiPlatformStatsQueryKey() });
    if (selectedClientId) {
      qc.invalidateQueries({ queryKey: getListApiKeysQueryKey(selectedClientId) });
      qc.invalidateQueries({ queryKey: getListApiClientUsersQueryKey(selectedClientId) });
      qc.invalidateQueries({ queryKey: getGetApiClientLogsQueryKey(selectedClientId) });
    }
  };

  const handleCreateClient = async () => {
    try {
      await createClient.mutateAsync({ data: { name: clientForm.name, email: clientForm.email, company: clientForm.company || undefined, notes: clientForm.notes || undefined } });
      toast({ title: "API Client created" });
      setNewClientOpen(false);
      setClientForm({ name: "", email: "", company: "", notes: "" });
      refetchAll();
    } catch { toast({ title: "Failed to create client", variant: "destructive" }); }
  };

  const handleClientStatus = async (clientId: string, status: "active" | "blocked" | "suspended") => {
    try {
      await updateClientStatus.mutateAsync({ clientId, data: { status } });
      toast({ title: `Client ${status}` });
      refetchAll();
    } catch { toast({ title: "Update failed", variant: "destructive" }); }
  };

  const handleDeleteClient = async (clientId: string) => {
    try {
      await deleteClient.mutateAsync({ clientId });
      if (selectedClientId === clientId) setSelectedClientId(null);
      toast({ title: "Client deleted" });
      refetchAll();
    } catch { toast({ title: "Delete failed", variant: "destructive" }); }
  };

  const handleCreateKey = async () => {
    if (!selectedClientId) return;
    try {
      const result = await createKey.mutateAsync({ clientId: selectedClientId, data: { name: keyForm.name, validDays: keyForm.validDays, pricingTier: keyForm.pricingTier, priceUsd: keyForm.priceUsd, requestLimitPerDay: keyForm.requestLimitPerDay } });
      setNewKeyOpen(false);
      setKeyForm({ name: "", validDays: 365, pricingTier: "standard", priceUsd: 99, requestLimitPerDay: 1000 });
      setRevealedKey(result.key);
      setRevealedKeyName(result.name);
      setCopied(false);
      refetchAll();
    } catch { toast({ title: "Failed to create key", variant: "destructive" }); }
  };

  const handleKeyStatus = async (keyId: string, status: "active" | "blocked" | "suspended" | "expired") => {
    if (!selectedClientId) return;
    try {
      await updateKeyStatus.mutateAsync({ clientId: selectedClientId, keyId, data: { status } });
      toast({ title: `Key ${status}` });
      refetchAll();
    } catch { toast({ title: "Update failed", variant: "destructive" }); }
  };

  const handleDeleteKey = async (keyId: string) => {
    if (!selectedClientId) return;
    try {
      await deleteKey.mutateAsync({ clientId: selectedClientId, keyId });
      toast({ title: "Key deleted" });
      refetchAll();
    } catch { toast({ title: "Delete failed", variant: "destructive" }); }
  };

  const handleCopyKey = () => {
    if (revealedKey) {
      navigator.clipboard.writeText(revealedKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleRenewKey = async () => {
    if (!selectedClientId || !renewKeyId) return;
    try {
      await renewKey.mutateAsync({ clientId: selectedClientId, keyId: renewKeyId, data: { validDays: renewDays } });
      toast({ title: `Key renewed — extended by ${renewDays} days` });
      setRenewKeyId(null);
      refetchAll();
    } catch { toast({ title: "Renewal failed", variant: "destructive" }); }
  };

  const handleApiUserStatus = async (userId: string, status: "active" | "blocked" | "pending_transfer") => {
    if (!selectedClientId) return;
    try {
      await updateApiUserStatus.mutateAsync({ clientId: selectedClientId, userId, data: { status } });
      toast({ title: `User ${status === "pending_transfer" ? "marked for transfer" : status}` });
      qc.invalidateQueries({ queryKey: getListApiClientUsersQueryKey(selectedClientId) });
      qc.invalidateQueries({ queryKey: getGetApiPlatformStatsQueryKey() });
    } catch { toast({ title: "Update failed", variant: "destructive" }); }
  };

  const handleTransferUser = async () => {
    if (!selectedClientId || !transferUser) return;
    try {
      await transferApiUser.mutateAsync({ clientId: selectedClientId, userId: transferUser.id });
      toast({ title: `${transferUser.name} transferred to main system` });
      setTransferUser(null);
      qc.invalidateQueries({ queryKey: getListApiClientUsersQueryKey(selectedClientId) });
      qc.invalidateQueries({ queryKey: getGetApiPlatformStatsQueryKey() });
    } catch { toast({ title: "Transfer failed", variant: "destructive" }); }
  };

  const handleDeleteApiUser = async (userId: string, name: string) => {
    if (!selectedClientId) return;
    try {
      await deleteApiUser.mutateAsync({ clientId: selectedClientId, userId });
      toast({ title: `${name} deleted` });
      qc.invalidateQueries({ queryKey: getListApiClientUsersQueryKey(selectedClientId) });
      qc.invalidateQueries({ queryKey: getGetApiPlatformStatsQueryKey() });
    } catch { toast({ title: "Delete failed", variant: "destructive" }); }
  };

  const statusColor: Record<string, string> = {
    active: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    blocked: "bg-red-500/20 text-red-400 border-red-500/30",
    suspended: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    expired: "bg-white/10 text-white/50 border-white/20",
  };

  const daysUntilExpiry = (validUntil: string) => {
    const diff = new Date(validUntil).getTime() - Date.now();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return days;
  };

  return (
    <div className="space-y-6">
      {/* Stats — 7 cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3">
        {[
          { label: "Total Clients", value: statsLoading ? "—" : stats?.totalClients ?? 0, icon: <Network className="w-4 h-4 text-blue-400" />, color: "text-blue-400" },
          { label: "Active Keys", value: statsLoading ? "—" : stats?.activeKeys ?? 0, icon: <Key className="w-4 h-4 text-emerald-400" />, color: "text-emerald-400" },
          { label: "Total Requests", value: statsLoading ? "—" : (stats?.totalRequests ?? 0).toLocaleString(), icon: <Code2 className="w-4 h-4 text-purple-400" />, color: "text-purple-400" },
          { label: "Today's Requests", value: statsLoading ? "—" : (stats?.requestsToday ?? 0).toLocaleString(), icon: <Activity className="w-4 h-4 text-cyan-400" />, color: "text-cyan-400" },
          { label: "API Users", value: statsLoading ? "—" : stats?.totalApiUsers ?? 0, icon: <Users className="w-4 h-4 text-pink-400" />, color: "text-pink-400" },
          { label: "Pending Transfers", value: statsLoading ? "—" : stats?.pendingTransfers ?? 0, icon: <UserPlus className="w-4 h-4 text-orange-400" />, color: "text-orange-400" },
          { label: "Revenue (USD)", value: statsLoading ? "—" : `$${(stats?.revenueTotal ?? 0).toLocaleString()}`, icon: <DollarSign className="w-4 h-4 text-yellow-400" />, color: "text-yellow-400" },
        ].map((s) => (
          <Card key={s.label} className="bg-white/5 border-white/10">
            <CardContent className="p-3">
              <div className="flex items-center gap-2 mb-1">
                {s.icon}
                <p className="text-white/40 text-xs truncate">{s.label}</p>
              </div>
              <p className={`font-bold text-lg ${s.color}`}>{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main layout: Clients + Keys */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Clients Panel */}
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white text-base flex items-center gap-2">
                <Network className="w-4 h-4 text-blue-400" /> API Clients
              </CardTitle>
              <Button size="sm" onClick={() => setNewClientOpen(true)} className="bg-blue-600 hover:bg-blue-500 text-white h-7 text-xs">
                <Plus className="w-3 h-3 mr-1" /> New Client
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {clientsLoading ? (
              <div className="p-4 space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-10 w-full bg-white/5" />)}</div>
            ) : clients.length === 0 ? (
              <div className="p-8 text-center text-white/40 text-sm">No API clients yet. Create one to get started.</div>
            ) : (
              <div className="divide-y divide-white/5">
                {clients.map((c) => (
                  <div
                    key={c.id}
                    className={`flex items-center gap-3 p-3 cursor-pointer hover:bg-white/5 transition-colors ${selectedClientId === c.id ? "bg-white/10 border-l-2 border-l-blue-500" : ""}`}
                    onClick={() => setSelectedClientId(c.id === selectedClientId ? null : c.id)}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-white text-sm font-medium truncate">{c.name}</span>
                        <span className={`text-xs px-1.5 py-0.5 rounded border ${statusColor[c.status] ?? "bg-white/10 text-white/50"}`}>{c.status}</span>
                      </div>
                      <div className="text-white/40 text-xs">{c.email}{c.company ? ` · ${c.company}` : ""}</div>
                      <div className="text-white/30 text-xs mt-0.5">{c.keyCount} key{c.keyCount !== 1 ? "s" : ""} · {c.totalRequests.toLocaleString()} requests</div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-white/40 hover:text-white flex-shrink-0">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="bg-background border-white/10" align="end">
                        <DropdownMenuLabel className="text-white/40 text-xs">Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator className="bg-white/10" />
                        {c.status !== "active" && <DropdownMenuItem onClick={() => handleClientStatus(c.id, "active")} className="text-emerald-400 cursor-pointer"><UserCheck className="w-3.5 h-3.5 mr-2" />Activate</DropdownMenuItem>}
                        {c.status === "active" && <DropdownMenuItem onClick={() => handleClientStatus(c.id, "suspended")} className="text-yellow-400 cursor-pointer"><Ban className="w-3.5 h-3.5 mr-2" />Suspend</DropdownMenuItem>}
                        {c.status !== "blocked" && <DropdownMenuItem onClick={() => handleClientStatus(c.id, "blocked")} className="text-red-400 cursor-pointer"><UserX className="w-3.5 h-3.5 mr-2" />Block</DropdownMenuItem>}
                        <DropdownMenuSeparator className="bg-white/10" />
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-400 cursor-pointer"><Trash2 className="w-3.5 h-3.5 mr-2" />Delete Client</DropdownMenuItem>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="bg-background border-white/10">
                            <AlertDialogHeader>
                              <AlertDialogTitle className="text-white">Delete Client?</AlertDialogTitle>
                              <AlertDialogDescription className="text-white/60">This will delete "{c.name}" and all their API keys permanently.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="bg-white/10 text-white border-white/10">Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteClient(c.id)} className="bg-red-600 hover:bg-red-500 text-white">Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Detail Panel — Tabbed: Keys / Users / Logs */}
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="pb-0 pt-3 px-3">
            <div className="flex items-center justify-between">
              <div className="flex gap-1">
                {(["keys", "users", "logs"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setDetailTab(tab)}
                    className={`text-xs px-3 py-1.5 rounded-md font-medium transition-colors ${detailTab === tab ? "bg-white/15 text-white" : "text-white/40 hover:text-white/70"}`}
                  >
                    {tab === "keys" && <><Key className="w-3 h-3 inline mr-1" />Keys</>}
                    {tab === "users" && <><Users className="w-3 h-3 inline mr-1" />Users</>}
                    {tab === "logs" && <><Activity className="w-3 h-3 inline mr-1" />Logs</>}
                  </button>
                ))}
              </div>
              {selectedClient && detailTab === "keys" && (
                <Button size="sm" onClick={() => setNewKeyOpen(true)} className="bg-yellow-600 hover:bg-yellow-500 text-white h-7 text-xs">
                  <Plus className="w-3 h-3 mr-1" /> Generate Key
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0 mt-2">
            {!selectedClient ? (
              <div className="p-8 text-center text-white/40 text-sm flex flex-col items-center gap-2">
                <Network className="w-8 h-8 text-white/20" />
                <span>Select a client to view their keys, users, and request logs</span>
              </div>
            ) : detailTab === "keys" ? (
              keysLoading ? (
                <div className="p-4 space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full bg-white/5" />)}</div>
              ) : keys.length === 0 ? (
                <div className="p-8 text-center text-white/40 text-sm">No keys yet. Generate one above.</div>
              ) : (
                <div className="divide-y divide-white/5">
                  {keys.map((k) => {
                    const days = daysUntilExpiry(k.validUntil);
                    const expiryColor = days < 30 ? "text-red-400" : days < 90 ? "text-yellow-400" : "text-white/40";
                    return (
                      <div key={k.id} className="p-3 flex items-start gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-white text-sm font-medium">{k.name}</span>
                            <span className={`text-xs px-1.5 py-0.5 rounded border ${statusColor[k.status] ?? "bg-white/10 text-white/50"}`}>{k.status}</span>
                            <code className="text-xs text-blue-300 bg-blue-500/10 px-1.5 py-0.5 rounded font-mono">{k.keyPrefix}****</code>
                          </div>
                          <div className="flex items-center gap-3 mt-1 flex-wrap">
                            <span className={`text-xs ${expiryColor}`}>{days > 0 ? `Expires in ${days}d` : "Expired"}</span>
                            <span className="text-white/30 text-xs">{k.pricingTier} · ${k.priceUsd}/yr</span>
                            <span className="text-white/30 text-xs">{k.requestCount.toLocaleString()} reqs · {k.requestLimitPerDay.toLocaleString()}/day</span>
                          </div>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-white/40 hover:text-white flex-shrink-0">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent className="bg-background border-white/10" align="end">
                            <DropdownMenuLabel className="text-white/40 text-xs">Key Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator className="bg-white/10" />
                            {k.status !== "active" && <DropdownMenuItem onClick={() => handleKeyStatus(k.id, "active")} className="text-emerald-400 cursor-pointer"><CheckCircle2 className="w-3.5 h-3.5 mr-2" />Activate</DropdownMenuItem>}
                            {k.status === "active" && <DropdownMenuItem onClick={() => handleKeyStatus(k.id, "suspended")} className="text-yellow-400 cursor-pointer"><Ban className="w-3.5 h-3.5 mr-2" />Suspend</DropdownMenuItem>}
                            {k.status !== "blocked" && <DropdownMenuItem onClick={() => handleKeyStatus(k.id, "blocked")} className="text-red-400 cursor-pointer"><UserX className="w-3.5 h-3.5 mr-2" />Block</DropdownMenuItem>}
                            {k.status === "active" && <DropdownMenuItem onClick={() => handleKeyStatus(k.id, "expired")} className="text-white/40 cursor-pointer"><Clock className="w-3.5 h-3.5 mr-2" />Mark Expired</DropdownMenuItem>}
                            <DropdownMenuItem onClick={() => { setRenewKeyId(k.id); setRenewDays(365); }} className="text-cyan-400 cursor-pointer"><RefreshCw className="w-3.5 h-3.5 mr-2" />Renew</DropdownMenuItem>
                            <DropdownMenuSeparator className="bg-white/10" />
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-400 cursor-pointer"><Trash2 className="w-3.5 h-3.5 mr-2" />Revoke &amp; Delete</DropdownMenuItem>
                              </AlertDialogTrigger>
                              <AlertDialogContent className="bg-background border-white/10">
                                <AlertDialogHeader>
                                  <AlertDialogTitle className="text-white">Revoke Key?</AlertDialogTitle>
                                  <AlertDialogDescription className="text-white/60">This will permanently delete "{k.name}". Any apps using it will immediately lose access.</AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel className="bg-white/10 text-white border-white/10">Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDeleteKey(k.id)} className="bg-red-600 hover:bg-red-500 text-white">Revoke</AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    );
                  })}
                </div>
              )
            ) : detailTab === "users" ? (
              usersLoading ? (
                <div className="p-4 space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-10 w-full bg-white/5" />)}</div>
              ) : apiUsers.length === 0 ? (
                <div className="p-8 text-center text-white/40 text-sm flex flex-col items-center gap-2">
                  <Users className="w-8 h-8 text-white/20" />
                  <span>No users created via this client's API yet</span>
                  <p className="text-white/30 text-xs">Third-party apps use the API key to POST /api/v1/users</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {apiUsers.map((u) => (
                    <div key={u.id} className="p-3 flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-white text-sm font-medium truncate">{u.name}</span>
                          <span className={`text-xs px-1.5 py-0.5 rounded border ${
                            u.status === "active" ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" :
                            u.status === "blocked" ? "bg-red-500/20 text-red-400 border-red-500/30" :
                            u.status === "pending_transfer" ? "bg-orange-500/20 text-orange-400 border-orange-500/30" :
                            "bg-white/10 text-white/40 border-white/20"
                          }`}>{u.status.replace("_", " ")}</span>
                        </div>
                        <div className="text-white/40 text-xs">{u.email}{u.externalId ? ` · ext: ${u.externalId}` : ""}</div>
                        <div className="text-white/30 text-xs">{new Date(u.createdAt).toLocaleDateString()}</div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-white/40 hover:text-white flex-shrink-0">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="bg-background border-white/10" align="end">
                          <DropdownMenuLabel className="text-white/40 text-xs">User Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator className="bg-white/10" />
                          {u.status !== "active" && u.status !== "transferred" && <DropdownMenuItem onClick={() => handleApiUserStatus(u.id, "active")} className="text-emerald-400 cursor-pointer"><UserCheck className="w-3.5 h-3.5 mr-2" />Activate</DropdownMenuItem>}
                          {u.status === "active" && <DropdownMenuItem onClick={() => handleApiUserStatus(u.id, "blocked")} className="text-red-400 cursor-pointer"><Ban className="w-3.5 h-3.5 mr-2" />Block</DropdownMenuItem>}
                          {u.status !== "transferred" && (
                            <DropdownMenuItem onClick={() => setTransferUser({ id: u.id, name: u.name, email: u.email })} className="text-cyan-400 cursor-pointer">
                              <UserPlus className="w-3.5 h-3.5 mr-2" />Transfer to Main System
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator className="bg-white/10" />
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-400 cursor-pointer"><Trash2 className="w-3.5 h-3.5 mr-2" />Delete</DropdownMenuItem>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-background border-white/10">
                              <AlertDialogHeader>
                                <AlertDialogTitle className="text-white">Delete User?</AlertDialogTitle>
                                <AlertDialogDescription className="text-white/60">Remove "{u.name}" ({u.email}) from this API client?</AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel className="bg-white/10 text-white border-white/10">Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteApiUser(u.id, u.name)} className="bg-red-600 hover:bg-red-500 text-white">Delete</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  ))}
                </div>
              )
            ) : (
              logsLoading ? (
                <div className="p-4 space-y-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-8 w-full bg-white/5" />)}</div>
              ) : logs.length === 0 ? (
                <div className="p-8 text-center text-white/40 text-sm flex flex-col items-center gap-2">
                  <Activity className="w-8 h-8 text-white/20" />
                  <span>No request logs yet</span>
                  <p className="text-white/30 text-xs">Logs appear here when third-party apps call /api/v1/* endpoints</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-white/10">
                        <th className="text-left p-2 text-white/40 font-normal">Time</th>
                        <th className="text-left p-2 text-white/40 font-normal">Method</th>
                        <th className="text-left p-2 text-white/40 font-normal">Endpoint</th>
                        <th className="text-left p-2 text-white/40 font-normal">Status</th>
                        <th className="text-left p-2 text-white/40 font-normal">IP</th>
                        <th className="text-left p-2 text-white/40 font-normal">Key</th>
                        <th className="text-right p-2 text-white/40 font-normal">ms</th>
                      </tr>
                    </thead>
                    <tbody>
                      {logs.map((l) => (
                        <tr key={l.id} className="border-b border-white/5 hover:bg-white/5">
                          <td className="p-2 text-white/50">{new Date(l.createdAt).toLocaleTimeString()}</td>
                          <td className="p-2"><span className={`font-mono ${l.method === "GET" ? "text-blue-400" : l.method === "POST" ? "text-emerald-400" : l.method === "DELETE" ? "text-red-400" : "text-white/60"}`}>{l.method}</span></td>
                          <td className="p-2 text-white/70 font-mono">{l.endpoint}</td>
                          <td className="p-2"><span className={`${l.statusCode < 300 ? "text-emerald-400" : l.statusCode < 400 ? "text-yellow-400" : "text-red-400"}`}>{l.statusCode}</span></td>
                          <td className="p-2 text-white/40 font-mono">{l.ip || "—"}</td>
                          <td className="p-2 text-blue-300/70 font-mono truncate max-w-20">{l.keyName}</td>
                          <td className="p-2 text-white/40 text-right">{l.responseTimeMs ?? "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )
            )}
          </CardContent>
        </Card>
      </div>

      {/* Client Revenue Table */}
      {stats && stats.clientStats.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" /> Revenue by Client
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="border-white/10 hover:bg-transparent">
                  <TableHead className="text-white/50">Client</TableHead>
                  <TableHead className="text-white/50">Company</TableHead>
                  <TableHead className="text-white/50">Status</TableHead>
                  <TableHead className="text-white/50 text-right">Keys</TableHead>
                  <TableHead className="text-white/50 text-right">Requests</TableHead>
                  <TableHead className="text-white/50 text-right">Revenue</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stats.clientStats.map((c) => (
                  <TableRow key={c.id} className="border-white/10 hover:bg-white/5 cursor-pointer" onClick={() => setSelectedClientId(c.id)}>
                    <TableCell className="text-white text-sm">{c.name}<div className="text-white/40 text-xs">{c.email}</div></TableCell>
                    <TableCell className="text-white/60 text-sm">{c.company ?? "—"}</TableCell>
                    <TableCell><span className={`text-xs px-1.5 py-0.5 rounded border ${statusColor[c.status] ?? "bg-white/10 text-white/50"}`}>{c.status}</span></TableCell>
                    <TableCell className="text-white/60 text-right text-sm">{c.keyCount}</TableCell>
                    <TableCell className="text-white/60 text-right text-sm">{c.totalRequests.toLocaleString()}</TableCell>
                    <TableCell className="text-right"><span className="text-emerald-400 font-semibold text-sm">${c.revenueUsd.toLocaleString()}</span></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Create Client Dialog */}
      <Dialog open={newClientOpen} onOpenChange={setNewClientOpen}>
        <DialogContent className="bg-background border-white/10 text-white max-w-md">
          <DialogHeader><DialogTitle className="text-white">New API Client</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><label className="text-xs text-white/50 mb-1 block">Client Name *</label><Input value={clientForm.name} onChange={(e) => setClientForm({ ...clientForm, name: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="Acme Corp" /></div>
            <div><label className="text-xs text-white/50 mb-1 block">Email *</label><Input value={clientForm.email} onChange={(e) => setClientForm({ ...clientForm, email: e.target.value })} className="bg-white/5 border-white/10 text-white" type="email" placeholder="api@acme.com" /></div>
            <div><label className="text-xs text-white/50 mb-1 block">Company</label><Input value={clientForm.company} onChange={(e) => setClientForm({ ...clientForm, company: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="Acme Inc." /></div>
            <div><label className="text-xs text-white/50 mb-1 block">Notes</label><Textarea value={clientForm.notes} onChange={(e) => setClientForm({ ...clientForm, notes: e.target.value })} className="bg-white/5 border-white/10 text-white resize-none" rows={2} placeholder="Internal notes about this client" /></div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setNewClientOpen(false)} className="text-white/60">Cancel</Button>
            <Button onClick={handleCreateClient} disabled={createClient.isPending || !clientForm.name || !clientForm.email} className="bg-blue-600 hover:bg-blue-500 text-white">
              {createClient.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Create Client
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Key Dialog */}
      <Dialog open={newKeyOpen} onOpenChange={setNewKeyOpen}>
        <DialogContent className="bg-background border-white/10 text-white max-w-md">
          <DialogHeader><DialogTitle className="text-white">Generate API Key — {selectedClient?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><label className="text-xs text-white/50 mb-1 block">Key Name *</label><Input value={keyForm.name} onChange={(e) => setKeyForm({ ...keyForm, name: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="Production Key" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-white/50 mb-1 block">Validity (days)</label><Input type="number" value={keyForm.validDays} onChange={(e) => setKeyForm({ ...keyForm, validDays: parseInt(e.target.value) || 365 })} className="bg-white/5 border-white/10 text-white" /></div>
              <div><label className="text-xs text-white/50 mb-1 block">Price (USD/yr)</label><Input type="number" value={keyForm.priceUsd} onChange={(e) => setKeyForm({ ...keyForm, priceUsd: parseFloat(e.target.value) || 99 })} className="bg-white/5 border-white/10 text-white" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-white/50 mb-1 block">Pricing Tier</label><Input value={keyForm.pricingTier} onChange={(e) => setKeyForm({ ...keyForm, pricingTier: e.target.value })} className="bg-white/5 border-white/10 text-white" placeholder="standard" /></div>
              <div><label className="text-xs text-white/50 mb-1 block">Req. Limit / Day</label><Input type="number" value={keyForm.requestLimitPerDay} onChange={(e) => setKeyForm({ ...keyForm, requestLimitPerDay: parseInt(e.target.value) || 1000 })} className="bg-white/5 border-white/10 text-white" /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setNewKeyOpen(false)} className="text-white/60">Cancel</Button>
            <Button onClick={handleCreateKey} disabled={createKey.isPending || !keyForm.name} className="bg-yellow-600 hover:bg-yellow-500 text-white">
              {createKey.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}<Key className="w-3.5 h-3.5 mr-1.5" />Generate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Key Reveal Modal — shown once after generation */}
      <Dialog open={!!revealedKey} onOpenChange={(open) => { if (!open) setRevealedKey(null); }}>
        <DialogContent className="bg-background border-white/10 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Key className="w-4 h-4 text-yellow-400" /> API Key Generated — {revealedKeyName}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-red-300 text-sm">Copy this key now — it will <strong>never be shown again</strong>. Store it securely and share it only with the client.</p>
            </div>
            <div className="bg-black/40 rounded-lg p-3 border border-white/10">
              <code className="text-blue-300 text-sm font-mono break-all">{revealedKey}</code>
            </div>
            <Button onClick={handleCopyKey} className="w-full bg-white/10 hover:bg-white/20 text-white border border-white/10">
              {copied ? <><CheckCheck className="w-4 h-4 mr-2 text-emerald-400" />Copied!</> : <><Copy className="w-4 h-4 mr-2" />Copy to Clipboard</>}
            </Button>
          </div>
          <DialogFooter>
            <Button onClick={() => setRevealedKey(null)} className="bg-yellow-600 hover:bg-yellow-500 text-white">I've saved it — Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Renew Key Dialog */}
      <Dialog open={!!renewKeyId} onOpenChange={(open) => { if (!open) setRenewKeyId(null); }}>
        <DialogContent className="bg-background border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-cyan-400" /> Renew API Key
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-white/60 text-sm">Extend this key's validity from its current expiry date.</p>
            <div>
              <label className="text-xs text-white/50 mb-1 block">Extend by (days)</label>
              <Input
                type="number"
                value={renewDays}
                onChange={(e) => setRenewDays(parseInt(e.target.value) || 365)}
                className="bg-white/5 border-white/10 text-white"
                min={1}
                max={3650}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRenewKeyId(null)} className="text-white/60">Cancel</Button>
            <Button onClick={handleRenewKey} disabled={renewKey.isPending} className="bg-cyan-600 hover:bg-cyan-500 text-white">
              {renewKey.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              <RefreshCw className="w-3.5 h-3.5 mr-1.5" />Renew {renewDays}d
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transfer User Dialog */}
      <AlertDialog open={!!transferUser} onOpenChange={(open) => { if (!open) setTransferUser(null); }}>
        <AlertDialogContent className="bg-background border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-cyan-400" /> Transfer User to Main System
            </AlertDialogTitle>
            <AlertDialogDescription className="text-white/60">
              This will create a main platform account for <strong className="text-white">{transferUser?.name}</strong> ({transferUser?.email}).
              If an account with this email already exists, their API records will be linked to it.
              The user will then be able to log in directly to GEMS Video AI.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/10 text-white border-white/10">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleTransferUser}
              disabled={transferApiUser.isPending}
              className="bg-cyan-600 hover:bg-cyan-500 text-white"
            >
              {transferApiUser.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Transfer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Pronunciation Tab — Global Language Dictionary + Voice Correction Review
// ---------------------------------------------------------------------------

const COMMON_LANGUAGES = [
  { code: "en-US", label: "English (US)" },
  { code: "en-GB", label: "English (UK)" },
  { code: "en-IN", label: "English (India)" },
  { code: "hi-IN", label: "Hindi (India)" },
  { code: "ta-IN", label: "Tamil (India)" },
  { code: "te-IN", label: "Telugu (India)" },
  { code: "bn-IN", label: "Bengali (India)" },
  { code: "mr-IN", label: "Marathi (India)" },
  { code: "es-ES", label: "Spanish (Spain)" },
  { code: "es-MX", label: "Spanish (Mexico)" },
  { code: "fr-FR", label: "French (France)" },
  { code: "de-DE", label: "German" },
  { code: "ja-JP", label: "Japanese" },
  { code: "ko-KR", label: "Korean" },
  { code: "zh-CN", label: "Chinese (Mandarin)" },
  { code: "ar-SA", label: "Arabic" },
  { code: "pt-BR", label: "Portuguese (Brazil)" },
  { code: "ru-RU", label: "Russian" },
  { code: "it-IT", label: "Italian" },
  { code: "tr-TR", label: "Turkish" },
];

function PronunciationTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [filterLang, setFilterLang] = useState<string>("__all__");
  const [searchWord, setSearchWord] = useState<string>("");
  const [createOpen, setCreateOpen] = useState(false);
  const [editEntry, setEditEntry] = useState<{ id: string; phonetic: string; context: string; region: string; confidence: number } | null>(null);
  const [reviewFilter, setReviewFilter] = useState<string>("pending");

  const dictParams = {
    ...(filterLang !== "__all__" ? { language: filterLang } : {}),
    ...(searchWord.trim() ? { word: searchWord.trim() } : {}),
    limit: 100,
  };
  const { data: stats, isLoading: statsLoading } = useGetPronunciationStats({
    query: { queryKey: getGetPronunciationStatsQueryKey(), refetchInterval: 30000 },
  });
  const { data: entries, isLoading: entriesLoading } = useListDictionaryEntries(dictParams, {
    query: { queryKey: getListDictionaryEntriesQueryKey(dictParams) },
  });
  const reviewParams = reviewFilter === "all" ? undefined : { status: reviewFilter as "pending" | "approved" | "applied" | "rejected" };
  const { data: corrections, isLoading: corrLoading } = useListAllVoiceCorrections(reviewParams, {
    query: { queryKey: getListAllVoiceCorrectionsQueryKey(reviewParams) },
  });

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: getListDictionaryEntriesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListAllVoiceCorrectionsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetPronunciationStatsQueryKey() });
  };

  const createMutation = useCreateDictionaryEntry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Dictionary entry added" });
        setCreateOpen(false);
        invalidateAll();
      },
      onError: (e) => toast({ title: "Failed to create entry", description: String(e), variant: "destructive" }),
    },
  });
  const updateMutation = useUpdateDictionaryEntry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Entry updated" });
        setEditEntry(null);
        invalidateAll();
      },
      onError: (e) => toast({ title: "Failed to update", description: String(e), variant: "destructive" }),
    },
  });
  const deleteMutation = useDeleteDictionaryEntry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Entry deleted" });
        invalidateAll();
      },
      onError: (e) => toast({ title: "Failed to delete", description: String(e), variant: "destructive" }),
    },
  });
  const reviewMutation = useReviewVoiceCorrection({
    mutation: {
      onSuccess: (_data, vars) => {
        const verb = vars.data.status === "approved" ? "approved" : vars.data.status === "applied" ? "applied" : "rejected";
        toast({ title: `Correction ${verb}` });
        invalidateAll();
      },
      onError: (e) => toast({ title: "Review failed", description: String(e), variant: "destructive" }),
    },
  });

  return (
    <div className="space-y-6">
      {/* Hero */}
      <Card className="bg-gradient-to-br from-purple-500/10 via-background to-background border-purple-500/20">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="h-12 w-12 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
              <AudioLines className="w-6 h-6 text-purple-300" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold">Global Pronunciation System</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Curate per-language phonetic entries, review user voice corrections, and ensure 100% natural human pronunciation across regions.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-6">
        {[
          { icon: Globe, label: "Total Entries", value: stats?.totalEntries ?? 0, color: "text-blue-400" },
          { icon: Languages, label: "Languages", value: stats?.languagesCovered ?? 0, color: "text-emerald-400" },
          { icon: Network, label: "Regions", value: stats?.regionsCovered ?? 0, color: "text-yellow-400" },
          { icon: Mic2, label: "User Voices", value: stats?.userContributedEntries ?? 0, color: "text-pink-400" },
          { icon: Clock, label: "Pending Review", value: stats?.pendingCorrections ?? 0, color: "text-orange-400" },
          { icon: CheckCircle2, label: "Applied", value: stats?.appliedCorrections ?? 0, color: "text-purple-400" },
        ].map((s) => (
          <Card key={s.label}>
            <CardContent className="pt-4 pb-4">
              <div className="flex items-center justify-between">
                <s.icon className={`w-5 h-5 ${s.color}`} />
                {statsLoading ? <Skeleton className="h-6 w-10" /> : <span className="text-2xl font-bold">{s.value}</span>}
              </div>
              <p className="text-xs text-muted-foreground mt-2">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Top Languages */}
      {stats && stats.topLanguages.length > 0 && (
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm font-medium">Coverage by Language</CardTitle></CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {stats.topLanguages.map((l) => (
                <Badge key={l.languageCode} className="bg-white/5 text-white border-0 font-mono text-xs">
                  {l.languageCode} <span className="text-muted-foreground ml-1.5">· {l.count}</span>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dictionary panel */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2"><Volume2 className="w-4 h-4" />Pronunciation Dictionary</CardTitle>
            <CardDescription>Per-language phonetic entries with regional dialects</CardDescription>
          </div>
          <Button onClick={() => setCreateOpen(true)} className="bg-yellow-500 hover:bg-yellow-400 text-black"><Plus className="w-4 h-4 mr-2" />Add Entry</Button>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3 mb-4">
            <div className="w-56">
              <Select value={filterLang} onValueChange={setFilterLang}>
                <SelectTrigger><SelectValue placeholder="Filter language" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">All languages</SelectItem>
                  {COMMON_LANGUAGES.map((l) => <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Input
              placeholder="Search word..."
              value={searchWord}
              onChange={(e) => setSearchWord(e.target.value)}
              className="w-64"
            />
          </div>

          {entriesLoading ? (
            <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-10 w-full" />)}</div>
          ) : !entries || entries.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Volume2 className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No entries yet. Add your first pronunciation.</p>
            </div>
          ) : (
            <div className="border border-white/10 rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Word</TableHead>
                    <TableHead>Phonetic (IPA)</TableHead>
                    <TableHead>Language</TableHead>
                    <TableHead>Region</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Conf.</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {entries.map((e) => (
                    <TableRow key={e.id}>
                      <TableCell className="font-medium">{e.word}</TableCell>
                      <TableCell className="font-mono text-purple-300 text-sm">{e.phonetic}</TableCell>
                      <TableCell className="text-xs text-muted-foreground font-mono">{e.languageCode}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{e.region ?? "—"}</TableCell>
                      <TableCell>
                        <Badge className={
                          e.source === "user_contributed" ? "bg-pink-500/15 text-pink-300 border-0" :
                          e.source === "ai_seed" ? "bg-blue-500/15 text-blue-300 border-0" :
                          "bg-emerald-500/15 text-emerald-300 border-0"
                        }>{e.source.replace("_", " ")}</Badge>
                      </TableCell>
                      <TableCell><span className="text-sm">{e.confidence}%</span></TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreVertical className="w-4 h-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setEditEntry({
                              id: e.id,
                              phonetic: e.phonetic,
                              context: e.context ?? "",
                              region: e.region ?? "",
                              confidence: e.confidence,
                            })}><Edit2 className="w-4 h-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => deleteMutation.mutate({ id: e.id })} className="text-red-400 focus:text-red-400">
                              <Trash2 className="w-4 h-4 mr-2" />Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Voice Correction Review */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2"><Mic2 className="w-4 h-4" />Voice Correction Queue</CardTitle>
            <CardDescription>User-uploaded pronunciations to denoise, blend, and apply</CardDescription>
          </div>
          <div className="w-44">
            <Select value={reviewFilter} onValueChange={setReviewFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="applied">Applied</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="all">All</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {corrLoading ? (
            <div className="space-y-2">{[1,2].map(i => <Skeleton key={i} className="h-10 w-full" />)}</div>
          ) : !corrections || corrections.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Mic2 className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No {reviewFilter === "all" ? "" : reviewFilter} corrections.</p>
            </div>
          ) : (
            <div className="border border-white/10 rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Word</TableHead>
                    <TableHead>Language</TableHead>
                    <TableHead>Audio</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Submitted</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {corrections.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="text-sm">
                        <div className="font-medium">{c.userName ?? "—"}</div>
                        <div className="text-xs text-muted-foreground">{c.userEmail ?? ""}</div>
                      </TableCell>
                      <TableCell className="font-medium">{c.word}</TableCell>
                      <TableCell className="text-xs text-muted-foreground font-mono">{c.languageCode}</TableCell>
                      <TableCell>
                        <a href={c.audioUrl} target="_blank" rel="noreferrer" className="text-blue-400 hover:underline text-xs flex items-center gap-1">
                          <Volume2 className="w-3 h-3" />Listen
                        </a>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          c.status === "applied" ? "bg-purple-500/15 text-purple-300 border-0" :
                          c.status === "approved" ? "bg-emerald-500/15 text-emerald-300 border-0" :
                          c.status === "rejected" ? "bg-red-500/15 text-red-300 border-0" :
                          "bg-orange-500/15 text-orange-300 border-0"
                        }>{c.status}</Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{new Date(c.createdAt).toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        {c.status === "pending" || c.status === "approved" ? (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreVertical className="w-4 h-4" /></Button></DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              {c.status === "pending" && (
                                <DropdownMenuItem onClick={() => reviewMutation.mutate({ id: c.id, data: { status: "approved" } })}>
                                  <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-400" />Approve
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem onClick={() => reviewMutation.mutate({ id: c.id, data: { status: "applied" } })}>
                                <CheckCheck className="w-4 h-4 mr-2 text-purple-400" />Apply to Dictionary
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => reviewMutation.mutate({ id: c.id, data: { status: "rejected" } })} className="text-red-400 focus:text-red-400">
                                <X className="w-4 h-4 mr-2" />Reject
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Entry Dialog */}
      <CreateDictionaryEntryDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onSubmit={(data) => createMutation.mutate({ data })}
        loading={createMutation.isPending}
      />

      {/* Edit Entry Dialog */}
      {editEntry && (
        <EditDictionaryEntryDialog
          entry={editEntry}
          onClose={() => setEditEntry(null)}
          onSubmit={(data) => updateMutation.mutate({ id: editEntry.id, data })}
          loading={updateMutation.isPending}
        />
      )}
    </div>
  );
}

function CreateDictionaryEntryDialog({
  open, onOpenChange, onSubmit, loading,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSubmit: (data: { languageCode: string; word: string; phonetic: string; context?: string; region?: string; confidence?: number }) => void;
  loading: boolean;
}) {
  const [languageCode, setLanguageCode] = useState("en-US");
  const [word, setWord] = useState("");
  const [phonetic, setPhonetic] = useState("");
  const [context, setContext] = useState("");
  const [region, setRegion] = useState("");
  const [confidence, setConfidence] = useState(100);

  const handleSubmit = () => {
    if (!word || !phonetic || !languageCode) return;
    onSubmit({
      languageCode, word, phonetic,
      context: context || undefined,
      region: region || undefined,
      confidence,
    });
    setWord(""); setPhonetic(""); setContext(""); setRegion("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>Add Pronunciation Entry</DialogTitle></DialogHeader>
        <div className="space-y-3 py-2">
          <div>
            <Label>Language *</Label>
            <Select value={languageCode} onValueChange={setLanguageCode}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {COMMON_LANGUAGES.map(l => <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Word / Phrase *</Label>
            <Input value={word} onChange={(e) => setWord(e.target.value)} placeholder="e.g. Worcestershire" />
          </div>
          <div>
            <Label>Phonetic (IPA) *</Label>
            <Input value={phonetic} onChange={(e) => setPhonetic(e.target.value)} placeholder="e.g. ˈwʊs.tər.ʃər" className="font-mono" />
          </div>
          <div>
            <Label>Region / Dialect (optional)</Label>
            <Input value={region} onChange={(e) => setRegion(e.target.value)} placeholder="e.g. IN-DL, US-NY" />
          </div>
          <div>
            <Label>Context / Meaning (optional)</Label>
            <Textarea value={context} onChange={(e) => setContext(e.target.value)} placeholder="When to use this pronunciation..." rows={2} />
          </div>
          <div>
            <Label>Confidence ({confidence}%)</Label>
            <Input type="number" min={0} max={100} value={confidence} onChange={(e) => setConfidence(Number(e.target.value))} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={loading || !word || !phonetic} className="bg-yellow-500 hover:bg-yellow-400 text-black">
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}Add Entry
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function EditDictionaryEntryDialog({
  entry, onClose, onSubmit, loading,
}: {
  entry: { id: string; phonetic: string; context: string; region: string; confidence: number };
  onClose: () => void;
  onSubmit: (data: { phonetic?: string; context?: string; region?: string; confidence?: number }) => void;
  loading: boolean;
}) {
  const [phonetic, setPhonetic] = useState(entry.phonetic);
  const [context, setContext] = useState(entry.context);
  const [region, setRegion] = useState(entry.region);
  const [confidence, setConfidence] = useState(entry.confidence);

  return (
    <Dialog open={true} onOpenChange={(v) => !v && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Edit Pronunciation Entry</DialogTitle></DialogHeader>
        <div className="space-y-3 py-2">
          <div>
            <Label>Phonetic (IPA)</Label>
            <Input value={phonetic} onChange={(e) => setPhonetic(e.target.value)} className="font-mono" />
          </div>
          <div>
            <Label>Region / Dialect</Label>
            <Input value={region} onChange={(e) => setRegion(e.target.value)} />
          </div>
          <div>
            <Label>Context</Label>
            <Textarea value={context} onChange={(e) => setContext(e.target.value)} rows={2} />
          </div>
          <div>
            <Label>Confidence ({confidence}%)</Label>
            <Input type="number" min={0} max={100} value={confidence} onChange={(e) => setConfidence(Number(e.target.value))} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => onSubmit({ phonetic, context, region, confidence })} disabled={loading} className="bg-yellow-500 hover:bg-yellow-400 text-black">
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ===========================================================================
// OFFERS TAB
// ===========================================================================
function OffersTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive" | "expired">("all");
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState<any>(null);

  const { data: offers, isLoading } = useListOffers(
    { status: statusFilter },
    { query: { queryKey: getListOffersQueryKey({ status: statusFilter }) } }
  );
  const { data: stats } = useGetOffersStats({
    query: { queryKey: getGetOffersStatsQueryKey() },
  });

  const createMutation = useCreateOffer({
    mutation: {
      onSuccess: () => {
        toast({ title: "Offer created", description: "Your offer is live." });
        queryClient.invalidateQueries({ queryKey: getListOffersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetOffersStatsQueryKey() });
        setShowCreate(false);
      },
      onError: (e: any) => toast({ title: "Failed to create offer", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });
  const updateMutation = useUpdateOffer({
    mutation: {
      onSuccess: () => {
        toast({ title: "Offer updated" });
        queryClient.invalidateQueries({ queryKey: getListOffersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetOffersStatsQueryKey() });
        setEditing(null);
      },
      onError: (e: any) => toast({ title: "Failed to update", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });
  const deleteMutation = useDeleteOffer({
    mutation: {
      onSuccess: () => {
        toast({ title: "Offer deleted" });
        queryClient.invalidateQueries({ queryKey: getListOffersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetOffersStatsQueryKey() });
      },
      onError: (e: any) => toast({ title: "Failed to delete", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });

  const offerList = (offers as any[]) ?? [];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <StatBlock icon={<Tag className="w-4 h-4" />} label="Total Offers" value={stats?.totalOffers ?? 0} />
        <StatBlock icon={<CheckCircle2 className="w-4 h-4 text-emerald-400" />} label="Active" value={stats?.activeOffers ?? 0} />
        <StatBlock icon={<Clock className="w-4 h-4 text-yellow-400" />} label="Expired" value={stats?.expiredOffers ?? 0} />
        <StatBlock icon={<Gift className="w-4 h-4 text-pink-400" />} label="Total Redemptions" value={stats?.totalRedemptions ?? 0} />
      </div>

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <Label className="text-xs text-zinc-400">Status</Label>
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
            <SelectTrigger className="w-[160px] h-9 bg-background/50"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="expired">Expired</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={() => setShowCreate(true)} className="bg-yellow-500 hover:bg-yellow-400 text-black">
          <Plus className="w-4 h-4 mr-2" />New Offer
        </Button>
      </div>

      <Card className="bg-background/40 border-white/10">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {[1, 2, 3].map((i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : offerList.length === 0 ? (
            <div className="p-10 text-center text-zinc-400">
              <Tag className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p>No offers yet.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-white/10">
                  <TableHead>Name</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>Discount</TableHead>
                  <TableHead>Validity</TableHead>
                  <TableHead>Used / Max</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {offerList.map((o: any) => (
                  <TableRow key={o.id} className="border-white/5">
                    <TableCell className="font-medium">
                      <div>{o.name}</div>
                      {o.description && <div className="text-xs text-zinc-500 mt-0.5">{o.description}</div>}
                    </TableCell>
                    <TableCell>
                      {o.code ? (
                        <code className="px-2 py-1 rounded bg-yellow-500/10 text-yellow-400 text-xs font-mono">{o.code}</code>
                      ) : (
                        <span className="text-xs text-zinc-500">— auto-apply —</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-blue-500/15 text-blue-400 border-0">
                        {o.discountType === "percentage" ? `${o.discountValue}%` : `${o.discountValue}`} off
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-zinc-400">
                      {new Date(o.startsAt).toLocaleDateString()} → {new Date(o.endsAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-xs">
                      {o.usedCount}{o.maxUses !== null ? ` / ${o.maxUses}` : " / ∞"}
                    </TableCell>
                    <TableCell>
                      {!o.isActive ? <Badge className="bg-zinc-500/20 text-zinc-300 border-0">Disabled</Badge>
                        : o.isExpired ? <Badge className="bg-red-500/15 text-red-400 border-0">Expired</Badge>
                        : o.isExhausted ? <Badge className="bg-orange-500/15 text-orange-400 border-0">Exhausted</Badge>
                        : <Badge className="bg-emerald-500/15 text-emerald-400 border-0">Live</Badge>}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button size="sm" variant="ghost" onClick={() => updateMutation.mutate({ id: o.id, data: { isActive: !o.isActive } })}>
                          {o.isActive ? <ToggleRight className="w-4 h-4 text-emerald-400" /> : <ToggleLeft className="w-4 h-4 text-zinc-400" />}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditing(o)}>
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete offer "{o.name}"?</AlertDialogTitle>
                              <AlertDialogDescription>This permanently removes the offer and its redemption history.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteMutation.mutate({ id: o.id })} className="bg-red-500 hover:bg-red-600">Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {(stats?.topOffers?.length ?? 0) > 0 && (
        <Card className="bg-background/40 border-white/10">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4" />Top Performing Offers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {stats!.topOffers.map((t: any) => (
                <div key={t.id} className="flex items-center justify-between p-2 rounded bg-white/5">
                  <div className="flex items-center gap-2">
                    {t.code && <code className="text-xs text-yellow-400 font-mono">{t.code}</code>}
                    <span className="text-sm">{t.name}</span>
                  </div>
                  <Badge className="bg-pink-500/15 text-pink-400 border-0">{t.redemptions} redemptions</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {(showCreate || editing) && (
        <OfferEditor
          initial={editing}
          onClose={() => { setShowCreate(false); setEditing(null); }}
          onSubmit={(data) => {
            if (editing) updateMutation.mutate({ id: editing.id, data });
            else createMutation.mutate({ data });
          }}
          loading={createMutation.isPending || updateMutation.isPending}
        />
      )}
    </div>
  );
}

function OfferEditor({ initial, onClose, onSubmit, loading }: { initial: any; onClose: () => void; onSubmit: (d: any) => void; loading: boolean }) {
  const [name, setName] = useState(initial?.name ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [code, setCode] = useState(initial?.code ?? "");
  const [discountType, setDiscountType] = useState<"percentage" | "fixed">(initial?.discountType ?? "percentage");
  const [discountValue, setDiscountValue] = useState<number>(initial?.discountValue ?? 10);
  const [applicablePlans, setApplicablePlans] = useState<string>((initial?.applicablePlans ?? []).join(", "));
  const toLocal = (iso: string) => {
    const d = new Date(iso);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const [startsAt, setStartsAt] = useState(initial?.startsAt ? toLocal(initial.startsAt) : toLocal(new Date().toISOString()));
  const [endsAt, setEndsAt] = useState(initial?.endsAt ? toLocal(initial.endsAt) : toLocal(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()));
  const [maxUses, setMaxUses] = useState<string>(initial?.maxUses != null ? String(initial.maxUses) : "");
  const [isActive, setIsActive] = useState(initial?.isActive ?? true);

  const handleSubmit = () => {
    const payload: any = {
      name: name.trim(),
      description: description.trim() || null,
      code: code.trim() ? code.trim().toUpperCase() : null,
      discountType,
      discountValue: Number(discountValue),
      applicablePlans: applicablePlans.split(",").map((p) => p.trim()).filter(Boolean),
      startsAt: new Date(startsAt).toISOString(),
      endsAt: new Date(endsAt).toISOString(),
      maxUses: maxUses.trim() ? Number(maxUses) : null,
      isActive,
    };
    onSubmit(payload);
  };

  return (
    <Dialog open onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-yellow-400" />{initial ? "Edit Offer" : "Create Offer"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
          <div>
            <Label>Name *</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Summer Sale" />
          </div>
          <div>
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="Optional internal note shown to admins" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Coupon Code <span className="text-xs text-zinc-500">(blank = auto-apply)</span></Label>
              <Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="SUMMER25" />
            </div>
            <div>
              <Label>Max Uses <span className="text-xs text-zinc-500">(blank = unlimited)</span></Label>
              <Input type="number" min={1} value={maxUses} onChange={(e) => setMaxUses(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Discount Type</Label>
              <Select value={discountType} onValueChange={(v) => setDiscountType(v as any)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="percentage">Percentage (%)</SelectItem>
                  <SelectItem value="fixed">Fixed Amount</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Discount Value {discountType === "percentage" ? "(0-100)" : "(cents/currency)"}</Label>
              <Input type="number" min={0} max={discountType === "percentage" ? 100 : undefined} value={discountValue} onChange={(e) => setDiscountValue(Number(e.target.value))} />
            </div>
          </div>
          <div>
            <Label>Applicable Plans <span className="text-xs text-zinc-500">(comma-separated, blank = all)</span></Label>
            <Input value={applicablePlans} onChange={(e) => setApplicablePlans(e.target.value)} placeholder="starter, pro, enterprise" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Starts At *</Label>
              <Input type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
            </div>
            <div>
              <Label>Ends At *</Label>
              <Input type="datetime-local" value={endsAt} onChange={(e) => setEndsAt(e.target.value)} />
            </div>
          </div>
          <div className="flex items-center justify-between p-3 rounded bg-white/5">
            <div>
              <Label className="cursor-pointer">Active</Label>
              <p className="text-xs text-zinc-500 mt-0.5">When disabled, code cannot be redeemed.</p>
            </div>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={loading || !name.trim()} className="bg-yellow-500 hover:bg-yellow-400 text-black">
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
            {initial ? "Save Changes" : "Create Offer"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ===========================================================================
// SPECIAL ACCESS / VIP TAB
// ===========================================================================
function SpecialAccessTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const [showGrant, setShowGrant] = useState(false);
  const [editing, setEditing] = useState<any>(null);

  const { data: entries, isLoading } = useListSpecialAccess(
    { status: statusFilter },
    { query: { queryKey: getListSpecialAccessQueryKey({ status: statusFilter }) } }
  );
  const { data: stats } = useGetSpecialAccessStats({ query: { queryKey: getGetSpecialAccessStatsQueryKey() } });

  const grantMutation = useGrantSpecialAccess({
    mutation: {
      onSuccess: () => {
        toast({ title: "Special access granted" });
        queryClient.invalidateQueries({ queryKey: getListSpecialAccessQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSpecialAccessStatsQueryKey() });
        setShowGrant(false);
      },
      onError: (e: any) => toast({ title: "Failed to grant", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });
  const updateMutation = useUpdateSpecialAccess({
    mutation: {
      onSuccess: () => {
        toast({ title: "Privileges updated" });
        queryClient.invalidateQueries({ queryKey: getListSpecialAccessQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSpecialAccessStatsQueryKey() });
        setEditing(null);
      },
      onError: (e: any) => toast({ title: "Failed to update", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });
  const revokeMutation = useRevokeSpecialAccess({
    mutation: {
      onSuccess: () => {
        toast({ title: "Special access revoked" });
        queryClient.invalidateQueries({ queryKey: getListSpecialAccessQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSpecialAccessStatsQueryKey() });
      },
      onError: (e: any) => toast({ title: "Failed to revoke", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });

  const list = (entries as any[]) ?? [];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        <StatBlock icon={<Crown className="w-4 h-4 text-yellow-400" />} label="Total VIPs" value={stats?.totalUsersWithAccess ?? 0} />
        <StatBlock icon={<CheckCircle2 className="w-4 h-4 text-emerald-400" />} label="Active" value={stats?.activeUsers ?? 0} />
        <StatBlock icon={<UserX className="w-4 h-4 text-zinc-400" />} label="Inactive" value={stats?.inactiveUsers ?? 0} />
        <StatBlock icon={<Activity className="w-4 h-4 text-blue-400" />} label="Usage Actions" value={stats?.totalUsageActions ?? 0} />
        <StatBlock
          icon={<DollarSign className="w-4 h-4 text-emerald-400" />}
          label="Revenue Impact"
          value={`$${((stats?.estimatedRevenueImpactCents ?? 0) / 100).toFixed(2)}`}
        />
      </div>

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <Label className="text-xs text-zinc-400">Status</Label>
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
            <SelectTrigger className="w-[160px] h-9 bg-background/50"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={() => setShowGrant(true)} className="bg-yellow-500 hover:bg-yellow-400 text-black">
          <Crown className="w-4 h-4 mr-2" />Grant VIP Access
        </Button>
      </div>

      <Card className="bg-background/40 border-white/10">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {[1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : list.length === 0 ? (
            <div className="p-10 text-center text-zinc-400">
              <Crown className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p>No VIP users yet. Grant special access to unlock benefits for selected accounts.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-white/10">
                  <TableHead>User</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Privileges</TableHead>
                  <TableHead>Usage</TableHead>
                  <TableHead>Expires</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {list.map((e: any) => (
                  <TableRow key={e.id} className="border-white/5">
                    <TableCell>
                      <div className="font-medium text-sm">{e.userName ?? "(unknown)"}</div>
                      <div className="text-xs text-zinc-500">{e.userEmail ?? e.userId.slice(0, 8)}</div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-purple-500/15 text-purple-300 border-0 capitalize">{e.reason}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {e.canGenerateVideos && <Badge className="bg-violet-500/15 text-violet-400 border-0 text-[10px]">Can Generate</Badge>}
                        {e.canCinemaMode && <Badge className="bg-amber-500/15 text-amber-400 border-0 text-[10px]">Cinema 🎬</Badge>}
                        {e.canUseCharacterIdentity && <Badge className="bg-pink-500/15 text-pink-400 border-0 text-[10px]">Character ID</Badge>}
                        {e.freeVideoGeneration && <Badge className="bg-emerald-500/15 text-emerald-400 border-0 text-[10px]">Free Gen</Badge>}
                        {e.unlimitedUsage && <Badge className="bg-blue-500/15 text-blue-400 border-0 text-[10px]">Unlimited</Badge>}
                        {e.allLanguagesAccess && <Badge className="bg-cyan-500/15 text-cyan-400 border-0 text-[10px]">All Languages</Badge>}
                        {e.premiumFeaturesUnlock && <Badge className="bg-yellow-500/15 text-yellow-400 border-0 text-[10px]">Premium</Badge>}
                      </div>
                    </TableCell>
                    <TableCell className="text-xs">
                      <div>{e.usageCount} actions</div>
                      <div className="text-emerald-400">${(e.estimatedRevenueImpactCents / 100).toFixed(2)}</div>
                    </TableCell>
                    <TableCell className="text-xs text-zinc-400">
                      {e.expiresAt ? new Date(e.expiresAt).toLocaleDateString() : "Never"}
                    </TableCell>
                    <TableCell>
                      {e.isActive ? <Badge className="bg-emerald-500/15 text-emerald-400 border-0">Active</Badge>
                        : <Badge className="bg-zinc-500/20 text-zinc-300 border-0">Disabled</Badge>}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button size="sm" variant="ghost" onClick={() => updateMutation.mutate({ id: e.id, data: { isActive: !e.isActive } })}>
                          {e.isActive ? <ToggleRight className="w-4 h-4 text-emerald-400" /> : <ToggleLeft className="w-4 h-4 text-zinc-400" />}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditing(e)}>
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Revoke VIP access for {e.userName ?? e.userEmail}?</AlertDialogTitle>
                              <AlertDialogDescription>This permanently removes special privileges and tracking history.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => revokeMutation.mutate({ id: e.id })} className="bg-red-500 hover:bg-red-600">Revoke</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {(stats?.byReason?.length ?? 0) > 0 && (
          <Card className="bg-background/40 border-white/10">
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Layers className="w-4 h-4" />By Category</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {stats!.byReason.map((r: any) => (
                  <div key={r.reason} className="flex items-center justify-between p-2 rounded bg-white/5">
                    <span className="text-sm capitalize">{r.reason}</span>
                    <Badge className="bg-purple-500/15 text-purple-300 border-0">{r.count}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
        {(stats?.topUsers?.length ?? 0) > 0 && (
          <Card className="bg-background/40 border-white/10">
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4" />Top VIP Users</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {stats!.topUsers.map((u: any) => (
                  <div key={u.userId} className="flex items-center justify-between p-2 rounded bg-white/5">
                    <div>
                      <div className="text-sm">{u.userName ?? "(unknown)"}</div>
                      <div className="text-xs text-zinc-500">{u.userEmail ?? u.userId.slice(0, 8)}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs">{u.usageCount} actions</div>
                      <div className="text-xs text-emerald-400">${(u.estimatedValueCents / 100).toFixed(2)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {(showGrant || editing) && (
        <SpecialAccessEditor
          initial={editing}
          onClose={() => { setShowGrant(false); setEditing(null); }}
          onSubmit={(data) => {
            if (editing) updateMutation.mutate({ id: editing.id, data });
            else grantMutation.mutate({ data });
          }}
          loading={grantMutation.isPending || updateMutation.isPending}
        />
      )}
    </div>
  );
}

function SpecialAccessEditor({ initial, onClose, onSubmit, loading }: { initial: any; onClose: () => void; onSubmit: (d: any) => void; loading: boolean }) {
  const isEdit = !!initial;
  const [userSearch, setUserSearch] = useState("");
  const [userId, setUserId] = useState<string>(initial?.userId ?? "");
  const [canGenerateVideos, setCanGenerateVideos] = useState(initial?.canGenerateVideos ?? false);
  const [canCinemaMode, setCanCinemaMode] = useState(initial?.canCinemaMode ?? false);
  const [canUseCharacterIdentity, setCanUseCharacterIdentity] = useState(initial?.canUseCharacterIdentity ?? false);
  const [freeVideoGeneration, setFreeVideoGeneration] = useState(initial?.freeVideoGeneration ?? true);
  const [unlimitedUsage, setUnlimitedUsage] = useState(initial?.unlimitedUsage ?? false);
  const [allLanguagesAccess, setAllLanguagesAccess] = useState(initial?.allLanguagesAccess ?? false);
  const [premiumFeaturesUnlock, setPremiumFeaturesUnlock] = useState(initial?.premiumFeaturesUnlock ?? false);
  const [reason, setReason] = useState<string>(initial?.reason ?? "vip");
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const toLocal = (iso: string) => {
    const d = new Date(iso);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const [expiresAt, setExpiresAt] = useState(initial?.expiresAt ? toLocal(initial.expiresAt) : "");
  const [isActive, setIsActive] = useState(initial?.isActive ?? true);

  const { data: usersData } = useAdminListUsers(
    { page: 1, limit: 100 },
    { query: { queryKey: getAdminListUsersQueryKey({ page: 1, limit: 100 }), enabled: !isEdit } }
  );
  const filtered = ((usersData as any)?.users ?? []).filter((u: User) => {
    if (!userSearch.trim()) return true;
    const s = userSearch.toLowerCase();
    return u.name?.toLowerCase().includes(s) || u.email?.toLowerCase().includes(s);
  });
  const selectedUser = ((usersData as any)?.users ?? []).find((u: User) => u.id === userId);

  const handleSubmit = () => {
    const payload: any = {
      canGenerateVideos,
      canCinemaMode,
      canUseCharacterIdentity,
      freeVideoGeneration,
      unlimitedUsage,
      allLanguagesAccess,
      premiumFeaturesUnlock,
      reason,
      notes: notes.trim() || null,
      expiresAt: expiresAt ? new Date(expiresAt).toISOString() : null,
    };
    if (!isEdit) payload.userId = userId;
    else payload.isActive = isActive;
    onSubmit(payload);
  };

  return (
    <Dialog open onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-400" />{isEdit ? "Edit VIP Privileges" : "Grant VIP Access"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 max-h-[65vh] overflow-y-auto pr-2">
          {!isEdit ? (
            <div>
              <Label>User *</Label>
              <Input placeholder="Search by name or email..." value={userSearch} onChange={(e) => setUserSearch(e.target.value)} className="mb-2" />
              <div className="max-h-48 overflow-y-auto rounded border border-white/10 bg-background/50">
                {filtered.length === 0 ? (
                  <div className="p-3 text-xs text-zinc-500 text-center">No users found</div>
                ) : (
                  filtered.slice(0, 20).map((u: User) => (
                    <button
                      key={u.id}
                      type="button"
                      onClick={() => setUserId(u.id)}
                      className={`w-full text-left px-3 py-2 hover:bg-white/5 border-b border-white/5 last:border-0 ${userId === u.id ? "bg-yellow-500/10" : ""}`}
                    >
                      <div className="text-sm">{u.name}</div>
                      <div className="text-xs text-zinc-500">{u.email}</div>
                    </button>
                  ))
                )}
              </div>
            </div>
          ) : (
            <div className="p-3 rounded bg-white/5">
              <div className="text-xs text-zinc-400">Editing</div>
              <div className="text-sm font-medium">{initial.userName ?? "(unknown)"}</div>
              <div className="text-xs text-zinc-500">{initial.userEmail ?? initial.userId}</div>
            </div>
          )}

          <div className="space-y-2">
            <Label>Privileges</Label>
            <div className="space-y-2 p-3 rounded bg-white/5">
              <PrivilegeToggle label="Video Generation Access" desc="Allow this user to generate videos (required permission)" checked={canGenerateVideos} onChange={setCanGenerateVideos} />
              <PrivilegeToggle label="Cinema Mode (4K–8K)" desc="Unlock cinema-grade output: 21:9 anamorphic, 4K/8K resolution, DCP + ProRes export" checked={canCinemaMode} onChange={setCanCinemaMode} />
              <PrivilegeToggle label="Character Identity" desc="Allow this user to use Character Identity feature (face + voice personalization in videos)" checked={canUseCharacterIdentity} onChange={setCanUseCharacterIdentity} />
              <div className="border-t border-white/5 my-1" />
              <PrivilegeToggle label="Free Video Generation" desc="Bypass plan credit usage on every render" checked={freeVideoGeneration} onChange={setFreeVideoGeneration} />
              <PrivilegeToggle label="Unlimited Usage" desc="No daily/monthly caps on any feature" checked={unlimitedUsage} onChange={setUnlimitedUsage} />
              <PrivilegeToggle label="All Languages Access" desc="Unlock every supported language regardless of plan" checked={allLanguagesAccess} onChange={setAllLanguagesAccess} />
              <PrivilegeToggle label="Premium Features Unlock" desc="Unlock all premium-tier features" checked={premiumFeaturesUnlock} onChange={setPremiumFeaturesUnlock} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Reason</Label>
              <Select value={reason} onValueChange={setReason}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="vip">VIP</SelectItem>
                  <SelectItem value="influencer">Influencer</SelectItem>
                  <SelectItem value="testing">Testing / QA</SelectItem>
                  <SelectItem value="promotion">Promotion</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Expires At <span className="text-xs text-zinc-500">(blank = never)</span></Label>
              <Input type="datetime-local" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} />
            </div>
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Internal admin notes..." />
          </div>

          {isEdit && (
            <div className="flex items-center justify-between p-3 rounded bg-white/5">
              <div>
                <Label>Active</Label>
                <p className="text-xs text-zinc-500 mt-0.5">When disabled, privileges are paused (history kept).</p>
              </div>
              <Switch checked={isActive} onCheckedChange={setIsActive} />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={loading || (!isEdit && !userId)} className="bg-yellow-500 hover:bg-yellow-400 text-black">
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Crown className="w-4 h-4 mr-2" />}
            {isEdit ? "Save Changes" : "Grant Access"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PrivilegeToggle({ label, desc, checked, onChange }: { label: string; desc: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex-1">
        <div className="text-sm">{label}</div>
        <div className="text-xs text-zinc-500">{desc}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

function StatBlock({ icon, label, value }: { icon: React.ReactNode; label: string; value: number | string }) {
  return (
    <Card className="bg-background/40 border-white/10">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-xs text-zinc-400 mb-1">{icon}{label}</div>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );
}

// =====================================================================
// SOUND LIBRARY TAB - Cinematic copyright-free sound library + stats
// =====================================================================
function SoundLibraryTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const { data: library, isLoading } = useAdminListSoundLibrary({
    query: { queryKey: getAdminListSoundLibraryQueryKey() },
  });
  const { data: stats } = useAdminGetSoundDesignStats({
    query: { queryKey: getAdminGetSoundDesignStatsQueryKey() },
  });

  const createMutation = useAdminCreateSoundLibraryEntry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Sound added", description: "New cinematic sound added to library." });
        queryClient.invalidateQueries({ queryKey: getAdminListSoundLibraryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getAdminGetSoundDesignStatsQueryKey() });
        setShowCreate(false);
      },
      onError: (e: any) => toast({ title: "Failed to add sound", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });
  const updateMutation = useAdminUpdateSoundLibraryEntry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Sound updated" });
        queryClient.invalidateQueries({ queryKey: getAdminListSoundLibraryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getAdminGetSoundDesignStatsQueryKey() });
        setEditing(null);
      },
      onError: (e: any) => toast({ title: "Failed to update", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });
  const deleteMutation = useAdminDeleteSoundLibraryEntry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Sound deleted" });
        queryClient.invalidateQueries({ queryKey: getAdminListSoundLibraryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getAdminGetSoundDesignStatsQueryKey() });
      },
      onError: (e: any) => toast({ title: "Failed to delete", description: e?.response?.data?.error || e.message, variant: "destructive" }),
    },
  });

  const allSounds = (library as any[]) ?? [];
  const filtered = searchTerm.trim().length > 0
    ? allSounds.filter((s: any) =>
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (Array.isArray(s.tags) && s.tags.some((t: string) => t.toLowerCase().includes(searchTerm.toLowerCase()))),
      )
    : allSounds;
  const s: any = stats ?? {};

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <StatBlock icon={<AudioLines className="w-4 h-4" />} label="Library" value={s.totalLibraryEntries ?? 0} />
        <StatBlock icon={<CheckCircle2 className="w-4 h-4 text-emerald-400" />} label="Active" value={s.activeLibraryEntries ?? 0} />
        <StatBlock icon={<Activity className="w-4 h-4 text-blue-400" />} label="Analyses" value={s.totalAnalyses ?? 0} />
        <StatBlock icon={<BarChart3 className="w-4 h-4" />} label="Decisions" value={s.totalDecisions ?? 0} />
        <StatBlock icon={<CheckCheck className="w-4 h-4 text-emerald-400" />} label="Kept" value={s.totalKept ?? 0} />
        <StatBlock icon={<Volume2 className="w-4 h-4 text-yellow-400" />} label="Replaced" value={s.totalReplaced ?? 0} />
        <StatBlock icon={<Plus className="w-4 h-4 text-pink-400" />} label="Added" value={s.totalAdded ?? 0} />
      </div>

      {Array.isArray(s.byCategory) && s.byCategory.length > 0 && (
        <Card className="bg-background/40 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Library by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {s.byCategory.map((c: any) => (
                <Badge key={c.category} variant="outline" className="text-xs">
                  {c.category} · <span className="ml-1 text-zinc-400">{c.count}</span>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <Input
          placeholder="Search by name, category, or tag..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm bg-background/50"
        />
        <Button onClick={() => setShowCreate(true)} className="bg-yellow-500 hover:bg-yellow-400 text-black">
          <Plus className="w-4 h-4 mr-2" />Add Sound
        </Button>
      </div>

      <Card className="bg-background/40 border-white/10">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {[1, 2, 3].map((i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-zinc-400">
              <AudioLines className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p>{allSounds.length === 0 ? "No sounds in library yet. Add one to get started." : "No sounds match your search."}</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-white/10">
                  <TableHead>Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead>Intensity</TableHead>
                  <TableHead>License</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((sound: any) => (
                  <TableRow key={sound.id} className="border-white/5">
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Volume2 className="w-3.5 h-3.5 text-zinc-400" />
                        <div>
                          <div>{sound.name}</div>
                          {sound.description && <div className="text-xs text-zinc-500 mt-0.5 max-w-xs truncate">{sound.description}</div>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell><Badge variant="outline" className="text-xs">{sound.category}</Badge></TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1 max-w-xs">
                        {(sound.tags ?? []).slice(0, 3).map((t: string) => (
                          <Badge key={t} variant="secondary" className="text-[10px] py-0">{t}</Badge>
                        ))}
                        {(sound.tags ?? []).length > 3 && <span className="text-[10px] text-zinc-500">+{sound.tags.length - 3}</span>}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        sound.intensity === "high" ? "text-red-300 border-red-500/40" :
                        sound.intensity === "medium" ? "text-yellow-300 border-yellow-500/40" :
                        "text-blue-300 border-blue-500/40"
                      }>{sound.intensity}</Badge>
                    </TableCell>
                    <TableCell className="text-xs text-zinc-400">{sound.license}</TableCell>
                    <TableCell>
                      <button
                        onClick={() => updateMutation.mutate({ id: sound.id, data: { isActive: !sound.isActive } })}
                        className="inline-flex items-center gap-1 text-xs"
                        data-testid={`toggle-sound-${sound.id}`}
                      >
                        {sound.isActive ? (
                          <><ToggleRight className="w-5 h-5 text-emerald-400" /><span className="text-emerald-400">Active</span></>
                        ) : (
                          <><ToggleLeft className="w-5 h-5 text-zinc-500" /><span className="text-zinc-500">Inactive</span></>
                        )}
                      </button>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        {sound.audioUrl && (
                          <a href={sound.audioUrl} target="_blank" rel="noreferrer" className="text-zinc-400 hover:text-white p-1.5">
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => setEditing(sound)}>
                          <Edit2 className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            if (confirm(`Delete sound "${sound.name}"?`)) deleteMutation.mutate({ id: sound.id });
                          }}
                          className="text-red-400 hover:text-red-300"
                          data-testid={`delete-sound-${sound.id}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {Array.isArray(s.topReplacedSounds) && s.topReplacedSounds.length > 0 && (
        <Card className="bg-background/40 border-white/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="w-4 h-4" />Top Replacement Sounds</CardTitle>
            <CardDescription>Sounds most often selected by AI to replace user prompts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {s.topReplacedSounds.map((t: any, i: number) => (
              <div key={i} className="flex items-center justify-between text-sm border-b border-white/5 pb-2 last:border-0">
                <span>{t.soundName ?? "(deleted)"}</span>
                <Badge variant="outline">{t.usageCount} uses</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {(showCreate || editing) && (
        <SoundEntryDialog
          entry={editing}
          onClose={() => { setShowCreate(false); setEditing(null); }}
          onSave={(data) => {
            if (editing) updateMutation.mutate({ id: editing.id, data });
            else createMutation.mutate({ data });
          }}
          saving={createMutation.isPending || updateMutation.isPending}
        />
      )}
    </div>
  );
}

function SoundEntryDialog({ entry, onClose, onSave, saving }: { entry: any; onClose: () => void; onSave: (data: any) => void; saving: boolean }) {
  const [name, setName] = useState(entry?.name ?? "");
  const [category, setCategory] = useState(entry?.category ?? "");
  const [description, setDescription] = useState(entry?.description ?? "");
  const [tagsStr, setTagsStr] = useState<string>((entry?.tags ?? []).join(", "));
  const [emotionsStr, setEmotionsStr] = useState<string>((entry?.emotions ?? []).join(", "));
  const [environmentsStr, setEnvironmentsStr] = useState<string>((entry?.environments ?? []).join(", "));
  const [intensity, setIntensity] = useState(entry?.intensity ?? "medium");
  const [audioUrl, setAudioUrl] = useState(entry?.audioUrl ?? "");
  const [previewUrl, setPreviewUrl] = useState(entry?.previewUrl ?? "");
  const [durationMs, setDurationMs] = useState(entry?.durationMs ?? 0);
  const [license, setLicense] = useState(entry?.license ?? "CC0");
  const [attribution, setAttribution] = useState(entry?.attribution ?? "");
  const [isActive, setIsActive] = useState(entry?.isActive ?? true);

  const handleSave = () => {
    onSave({
      name: name.trim(),
      category: category.trim(),
      description: description.trim() || undefined,
      tags: tagsStr.split(",").map((t) => t.trim()).filter(Boolean),
      emotions: emotionsStr.split(",").map((t) => t.trim()).filter(Boolean),
      environments: environmentsStr.split(",").map((t) => t.trim()).filter(Boolean),
      intensity,
      audioUrl: audioUrl.trim(),
      previewUrl: previewUrl.trim() || undefined,
      durationMs: Number(durationMs) || 0,
      license: license.trim() || "CC0",
      attribution: attribution.trim() || undefined,
      isActive,
    });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="bg-background border-white/10 max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{entry ? "Edit Sound" : "Add Sound to Library"}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3 py-2">
          <div className="space-y-1.5 col-span-2">
            <Label className="text-xs">Name *</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Cinematic Thunder Roll" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Category *</Label>
            <Input value={category} onChange={(e) => setCategory(e.target.value)} placeholder="thunder" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Intensity</Label>
            <Select value={intensity} onValueChange={setIntensity}>
              <SelectTrigger className="bg-background/50"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label className="text-xs">Description</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Deep low-frequency thunder with rolling tail" />
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label className="text-xs">Tags (comma-separated)</Label>
            <Input value={tagsStr} onChange={(e) => setTagsStr(e.target.value)} placeholder="thunder, storm, rumble, deep" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Emotions (comma-separated)</Label>
            <Input value={emotionsStr} onChange={(e) => setEmotionsStr(e.target.value)} placeholder="tense, ominous, fearful" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Environments (comma-separated)</Label>
            <Input value={environmentsStr} onChange={(e) => setEnvironmentsStr(e.target.value)} placeholder="outdoor, storm, horror" />
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label className="text-xs">Audio URL *</Label>
            <Input value={audioUrl} onChange={(e) => setAudioUrl(e.target.value)} placeholder="https://cdn.example.com/sounds/thunder.mp3" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Preview URL (optional)</Label>
            <Input value={previewUrl} onChange={(e) => setPreviewUrl(e.target.value)} placeholder="https://..." />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Duration (ms)</Label>
            <Input type="number" value={durationMs} onChange={(e) => setDurationMs(Number(e.target.value))} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">License</Label>
            <Input value={license} onChange={(e) => setLicense(e.target.value)} placeholder="CC0" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Attribution (optional)</Label>
            <Input value={attribution} onChange={(e) => setAttribution(e.target.value)} placeholder="Freesound user XYZ" />
          </div>
          <div className="col-span-2 flex items-center gap-2">
            <input id="sound-active" type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} className="accent-yellow-500" />
            <Label htmlFor="sound-active" className="text-sm">Active (available for AI matching)</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button
            onClick={handleSave}
            disabled={saving || !name.trim() || !category.trim() || !audioUrl.trim()}
            className="bg-yellow-500 hover:bg-yellow-400 text-black"
            data-testid="save-sound-btn"
          >
            {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
            {entry ? "Save Changes" : "Add Sound"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------------------------------------------------------------------------
// Audit Logs Tab
// ---------------------------------------------------------------------------
const ACTION_LABELS: Record<string, string> = {
  "user.created":         "Created User",
  "user.deleted":         "Deleted User",
  "user.status.changed":  "Changed Status",
  "user.role.changed":    "Changed Role",
  "permissions.updated":  "Updated Permissions",
  "video.deleted":        "Deleted Video",
};

const ACTION_COLORS: Record<string, string> = {
  "user.created":         "text-emerald-400",
  "user.deleted":         "text-red-400",
  "user.status.changed":  "text-yellow-400",
  "user.role.changed":    "text-blue-400",
  "permissions.updated":  "text-purple-400",
  "video.deleted":        "text-orange-400",
};

function AuditLogsTab() {
  const [page, setPage] = useState(1);
  const [expandedRow, setExpandedRow] = useState<string | null>(null);

  const { data, isLoading } = useGetAdminAuditLogs({ page, limit: 50 });

  const roleCls = (role: string) =>
    role === "super_admin"
      ? "bg-yellow-500/15 text-yellow-400 border-0"
      : role === "admin"
      ? "bg-blue-500/15 text-blue-400 border-0"
      : "bg-white/10 text-white/60 border-0";

  return (
    <Card className="bg-card border-white/5">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="w-5 h-5 text-yellow-400" />
          Admin Audit Log
        </CardTitle>
        <CardDescription>
          Every admin action is permanently logged. Cannot be altered or deleted.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="h-10 w-full" />)}
          </div>
        ) : !data?.logs.length ? (
          <div className="text-center text-muted-foreground py-12 text-sm">
            No audit events recorded yet.
          </div>
        ) : (
          <div className="rounded-md border border-white/10 overflow-hidden">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/10 hover:bg-transparent">
                  <TableHead>Actor</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead>IP</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead className="whitespace-nowrap">When</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.logs.map(log => (
                  <React.Fragment key={log.id}>
                    <TableRow className="border-white/10">
                      <TableCell>
                        <div className="text-sm font-medium">{log.actorName}</div>
                        <div className="text-xs text-muted-foreground">{log.actorEmail}</div>
                        <Badge className={`text-[10px] mt-0.5 ${roleCls(log.actorRole)}`}>
                          {log.actorRole}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className={`text-sm font-medium ${ACTION_COLORS[log.action] ?? "text-white/80"}`}>
                          {ACTION_LABELS[log.action] ?? log.action}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {log.targetType ? (
                          <div>
                            <div className="font-medium text-white/70">{log.targetType}</div>
                            <code className="text-[10px]">{log.targetId?.slice(0, 12)}…</code>
                          </div>
                        ) : "—"}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground font-mono">
                        {log.ipAddress ?? "—"}
                      </TableCell>
                      <TableCell>
                        {log.details && Object.keys(log.details).length > 0 ? (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 px-2 text-xs text-primary hover:bg-primary/10"
                            onClick={() => setExpandedRow(expandedRow === log.id ? null : log.id)}
                          >
                            {expandedRow === log.id ? "Hide" : "View"}
                          </Button>
                        ) : "—"}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString()}
                      </TableCell>
                    </TableRow>
                    {expandedRow === log.id && log.details && (
                      <TableRow className="border-white/10 bg-black/20">
                        <TableCell colSpan={6} className="py-2 px-4">
                          <pre className="text-[11px] text-muted-foreground whitespace-pre-wrap bg-black/40 rounded p-3 max-h-40 overflow-auto">
                            {JSON.stringify(log.details, null, 2)}
                          </pre>
                        </TableCell>
                      </TableRow>
                    )}
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {data && data.totalPages > 1 && (
          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-muted-foreground">
              Page {data.page} of {data.totalPages} · {data.total} total entries
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline" size="sm"
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
                className="border-white/10"
              >
                Previous
              </Button>
              <Button
                variant="outline" size="sm"
                disabled={page >= data.totalPages}
                onClick={() => setPage(p => p + 1)}
                className="border-white/10"
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// VideoPlansAdminTab
// ---------------------------------------------------------------------------
function VideoPlansAdminTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: plans, isLoading } = useAdminListVideoPlans();
  const createPlan = useAdminCreateVideoPlan();
  const updatePlan = useAdminUpdateVideoPlan();
  const deletePlan = useAdminDeleteVideoPlan();
  const grantPlan = useAdminGrantVideoPlan();
  const { data: usersData } = useAdminListUsers({ page: 1, limit: 200 });

  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [grantingPlanId, setGrantingPlanId] = useState<string | null>(null);
  const [grantUserId, setGrantUserId] = useState("");
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: "",
    description: "",
    priceUsd: "0",
    maxLengthSeconds: "30",
    monthlyQuota: "5",
    isDefault: false,
    isActive: true,
    features: "",
  });

  const resetForm = () => {
    setForm({ name: "", description: "", priceUsd: "0", maxLengthSeconds: "30", monthlyQuota: "5", isDefault: false, isActive: true, features: "" });
    setShowCreate(false);
    setEditingId(null);
  };

  const startEdit = (plan: NonNullable<typeof plans>[0]) => {
    setForm({
      name: plan.name,
      description: plan.description ?? "",
      priceUsd: String(plan.priceUsd),
      maxLengthSeconds: String(plan.maxLengthSeconds),
      monthlyQuota: String(plan.monthlyQuota),
      isDefault: plan.isDefault,
      isActive: plan.isActive,
      features: ((plan.features as string[]) ?? []).join("\n"),
    });
    setEditingId(plan.id);
    setShowCreate(true);
  };

  const handleSave = async () => {
    const data = {
      name: form.name.trim(),
      description: form.description.trim() || undefined,
      priceUsd: parseFloat(form.priceUsd) || 0,
      maxLengthSeconds: parseInt(form.maxLengthSeconds) || 30,
      monthlyQuota: parseInt(form.monthlyQuota) || 5,
      isDefault: form.isDefault,
      isActive: form.isActive,
      features: form.features.split("\n").map(f => f.trim()).filter(Boolean),
    };
    if (!data.name) { toast({ title: "Plan name required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (editingId) {
        await updatePlan.mutateAsync({ id: editingId, data });
        toast({ title: "Plan updated" });
      } else {
        await createPlan.mutateAsync({ data });
        toast({ title: "Plan created" });
      }
      queryClient.invalidateQueries({ queryKey: getAdminListVideoPlansQueryKey() });
      resetForm();
    } catch (e: any) {
      toast({ title: "Failed", description: e?.response?.data?.error ?? "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Delete plan "${name}"? Users on this plan will lose access.`)) return;
    try {
      await deletePlan.mutateAsync({ id });
      toast({ title: "Plan deleted" });
      queryClient.invalidateQueries({ queryKey: getAdminListVideoPlansQueryKey() });
    } catch (e: any) {
      toast({ title: "Delete failed", description: e?.response?.data?.error ?? "Try again", variant: "destructive" });
    }
  };

  const handleGrant = async () => {
    if (!grantingPlanId || !grantUserId) return;
    setSaving(true);
    try {
      await grantPlan.mutateAsync({ id: grantingPlanId, data: { userId: grantUserId } });
      toast({ title: "Plan granted to user" });
      setGrantingPlanId(null);
      setGrantUserId("");
    } catch (e: any) {
      toast({ title: "Grant failed", description: e?.response?.data?.error ?? "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Video Plans</h2>
          <p className="text-sm text-white/40">Manage subscription tiers for video generation</p>
        </div>
        <Button size="sm" onClick={() => { resetForm(); setShowCreate(true); }} className="gap-2">
          <Plus className="w-3.5 h-3.5" /> New Plan
        </Button>
      </div>

      {showCreate && (
        <Card className="bg-card border-primary/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{editingId ? "Edit Plan" : "Create New Plan"}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs text-white/60">Plan Name</Label>
                <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Creator" className="bg-background/50 border-white/10" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-white/60">Price (USD/month)</Label>
                <Input type="number" min="0" step="0.01" value={form.priceUsd} onChange={e => setForm(f => ({ ...f, priceUsd: e.target.value }))} className="bg-background/50 border-white/10" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-white/60">Max Video Length (seconds)</Label>
                <Input type="number" min="10" value={form.maxLengthSeconds} onChange={e => setForm(f => ({ ...f, maxLengthSeconds: e.target.value }))} className="bg-background/50 border-white/10" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-white/60">Monthly Quota (videos/month)</Label>
                <Input type="number" min="1" value={form.monthlyQuota} onChange={e => setForm(f => ({ ...f, monthlyQuota: e.target.value }))} className="bg-background/50 border-white/10" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-white/60">Description (optional)</Label>
              <Input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="For content creators..." className="bg-background/50 border-white/10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-white/60">Features (one per line)</Label>
              <Textarea value={form.features} onChange={e => setForm(f => ({ ...f, features: e.target.value }))} placeholder={"Up to 2 min videos\n20 videos/month\nHD quality"} rows={4} className="bg-background/50 border-white/10 resize-none text-sm" />
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Switch checked={form.isDefault} onCheckedChange={v => setForm(f => ({ ...f, isDefault: v }))} />
                <Label className="text-xs text-white/60">Default (free) plan</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={form.isActive} onCheckedChange={v => setForm(f => ({ ...f, isActive: v }))} />
                <Label className="text-xs text-white/60">Active</Label>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" size="sm" onClick={resetForm}>Cancel</Button>
              <Button size="sm" onClick={handleSave} disabled={saving}>{saving ? "Saving..." : (editingId ? "Update Plan" : "Create Plan")}</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Grant Plan Dialog */}
      {grantingPlanId && (
        <Card className="bg-card border-amber-500/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-amber-400 flex items-center gap-2"><Gift className="w-4 h-4" /> Grant Plan to User</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs text-white/60">Select User</Label>
              <Select value={grantUserId} onValueChange={setGrantUserId}>
                <SelectTrigger className="bg-background/50 border-white/10">
                  <SelectValue placeholder="Choose a user..." />
                </SelectTrigger>
                <SelectContent>
                  {(usersData?.users ?? []).map(u => (
                    <SelectItem key={u.id} value={u.id}>{u.name} ({u.email})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" size="sm" onClick={() => { setGrantingPlanId(null); setGrantUserId(""); }}>Cancel</Button>
              <Button size="sm" className="bg-amber-500 hover:bg-amber-400 text-black" onClick={handleGrant} disabled={!grantUserId || saving}>
                {saving ? "Granting..." : "Grant Plan"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
      ) : (
        <div className="grid md:grid-cols-3 gap-4">
          {(plans ?? []).map(plan => (
            <Card key={plan.id} className={`bg-card border-white/5 ${!plan.isActive ? "opacity-50" : ""}`}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
                      {plan.name}
                      {plan.isDefault && <Badge className="bg-amber-500/10 text-amber-400 border-0 text-[10px]">Default</Badge>}
                      {!plan.isActive && <Badge className="bg-white/5 text-white/30 border-0 text-[10px]">Inactive</Badge>}
                    </CardTitle>
                    <div className="text-lg font-bold text-primary mt-0.5">
                      {plan.priceUsd === 0 ? "Free" : `$${plan.priceUsd}/mo`}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => startEdit(plan)}>
                      <Pencil className="w-3 h-3" />
                    </Button>
                    {!plan.isDefault && (
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => handleDelete(plan.id, plan.name)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-2 pt-0">
                <div className="text-xs text-white/50 space-y-1">
                  <div className="flex items-center gap-1"><Clock className="w-3 h-3" /> Max {plan.maxLengthSeconds}s per video</div>
                  <div className="flex items-center gap-1"><Film className="w-3 h-3" /> {plan.monthlyQuota} videos/month</div>
                </div>
                <Button variant="outline" size="sm" className="w-full border-amber-500/20 text-amber-400 hover:bg-amber-500/10 text-xs" onClick={() => setGrantingPlanId(plan.id)}>
                  <Gift className="w-3 h-3 mr-1.5" /> Grant to User
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// CinemaModeAdminTab
// ---------------------------------------------------------------------------
function CinemaModeAdminTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: priceData, isLoading } = useGetCinemaPrice();
  const setPrice = useAdminSetCinemaPrice();
  const [priceInput, setPriceInput] = useState("");
  const [saving, setSaving] = useState(false);

  React.useEffect(() => {
    if (priceData?.priceUsd !== undefined) {
      setPriceInput(String(priceData.priceUsd));
    }
  }, [priceData?.priceUsd]);

  const handleSave = async () => {
    const price = parseFloat(priceInput);
    if (isNaN(price) || price < 0) {
      toast({ title: "Invalid price", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await setPrice.mutateAsync({ data: { priceUsd: price } });
      toast({ title: "Cinema mode price updated" });
      queryClient.invalidateQueries({ queryKey: getGetCinemaPriceQueryKey() });
    } catch (e: any) {
      toast({ title: "Failed to update price", description: e?.response?.data?.error ?? "Try again", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const FEATURES = [
    "4K Ultra HD & 8K resolution",
    "DCP (Digital Cinema Package) export",
    "ProRes 4444 export format",
    "Cinema 2.39:1 widescreen aspect ratio",
    "Advanced Dolby Atmos-ready audio",
    "HDR color grading pipeline",
  ];

  return (
    <div className="space-y-6 max-w-lg">
      <div>
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Clapperboard className="w-5 h-5 text-amber-400" />Cinema Mode Pricing
        </h2>
        <p className="text-sm text-white/40 mt-0.5">Set the one-time purchase price for Cinema Mode (4K–8K)</p>
      </div>

      <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/5 border-amber-500/20">
        <CardContent className="pt-5 space-y-4">
          <div className="space-y-2">
            <Label className="text-xs text-white/60">Purchase Price (USD)</Label>
            {isLoading ? (
              <Skeleton className="h-10 w-full" />
            ) : (
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40 text-sm">$</span>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={priceInput}
                    onChange={e => setPriceInput(e.target.value)}
                    className="pl-7 bg-background/50 border-white/10"
                    placeholder="29.99"
                  />
                </div>
                <Button onClick={handleSave} disabled={saving} className="bg-amber-500 hover:bg-amber-400 text-black font-medium">
                  {saving ? "Saving..." : "Update Price"}
                </Button>
              </div>
            )}
            <p className="text-xs text-white/30">Set to 0 to make Cinema Mode free for all users</p>
          </div>

          <div className="border-t border-white/5 pt-4">
            <h3 className="text-xs font-semibold text-white/50 uppercase tracking-wider mb-3">Cinema Mode Includes</h3>
            <div className="space-y-2">
              {FEATURES.map((f, i) => (
                <div key={i} className="flex items-center gap-2 text-sm text-white/60">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  {f}
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-white/5 pt-4">
            <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/10 rounded-lg p-3">
              <AlertCircle className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <p className="text-xs text-white/50">
                Super admins can manually grant Cinema Mode access to users via the <strong className="text-white/70">VIP Access</strong> tab. 
                Price changes apply to new purchases only.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Support Contact Admin Tab
// ---------------------------------------------------------------------------
function SupportContactAdminTab({ isSuperAdmin }: { isSuperAdmin: boolean }) {
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: settings, isLoading } = useGetPlatformSettings({
    query: { queryKey: getGetPlatformSettingsQueryKey(), staleTime: 10000 },
  });

  const [whatsapp, setWhatsapp] = useState("");
  const [email, setEmail] = useState("");
  const [adminCanEdit, setAdminCanEdit] = useState(false);
  const [saving, setSaving] = useState(false);

  // Sync form state when settings load
  React.useEffect(() => {
    if (settings) {
      setWhatsapp(settings.supportWhatsapp ?? "");
      setEmail(settings.supportEmail ?? "");
      setAdminCanEdit(settings.supportAdminCanEdit ?? false);
    }
  }, [settings]);

  const updateMutation = useUpdatePlatformSettings({
    mutation: {
      onSuccess: () => {
        toast({ title: "Saved", description: "Support contact info updated successfully." });
        qc.invalidateQueries({ queryKey: getGetPlatformSettingsQueryKey() });
        setSaving(false);
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to save support contact info.", variant: "destructive" });
        setSaving(false);
      },
    },
  });

  const handleSave = () => {
    setSaving(true);
    const body: Record<string, unknown> = {
      supportWhatsapp: whatsapp.trim() || null,
      supportEmail: email.trim() || null,
    };
    if (isSuperAdmin) {
      body.supportAdminCanEdit = adminCanEdit;
    }
    updateMutation.mutate({ data: body as any });
  };

  if (isLoading) {
    return <div className="h-48 flex items-center justify-center"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>;
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <Card className="border-white/10 bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <LifeBuoy className="w-4 h-4 text-amber-400" />
            Support Contact Info
          </CardTitle>
          <CardDescription>
            Yeh WhatsApp number aur email users ko Support page pe dikhega.
            {!isSuperAdmin && (
              <span className="block mt-1 text-amber-400/80 text-xs">Super admin ne aapko yeh edit karne ki permission di hai.</span>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* WhatsApp */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80 flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-green-400" />
              WhatsApp Number
            </label>
            <Input
              placeholder="+91 9876543210"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              className="bg-background/50 border-white/10"
            />
            <p className="text-xs text-white/40">Country code ke saath enter karein (e.g. +91 9876543210)</p>
          </div>

          {/* Email */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80 flex items-center gap-2">
              <Mail className="w-4 h-4 text-blue-400" />
              Support Email
            </label>
            <Input
              type="email"
              placeholder="support@gemsai.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-background/50 border-white/10"
            />
          </div>

          {/* Admin permission toggle — super_admin only */}
          {isSuperAdmin && (
            <div className="flex items-center justify-between p-4 rounded-lg bg-white/3 border border-white/5">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white/80">Admin can edit</p>
                  <p className="text-xs text-white/40">Admin role ko bhi support contact edit karne do</p>
                </div>
              </div>
              <button
                onClick={() => setAdminCanEdit(!adminCanEdit)}
                className={`relative w-11 h-6 rounded-full transition-colors ${adminCanEdit ? "bg-amber-500" : "bg-white/10"}`}
              >
                <span className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform ${adminCanEdit ? "translate-x-5" : ""}`} />
              </button>
            </div>
          )}

          <Button
            onClick={handleSave}
            disabled={saving}
            className="w-full bg-primary hover:bg-primary/90"
          >
            {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : <><Check className="w-4 h-4 mr-2" />Save Support Contact</>}
          </Button>
        </CardContent>
      </Card>

      {/* Preview */}
      <Card className="border-white/10 bg-card">
        <CardHeader>
          <CardTitle className="text-sm text-white/60">User ko kaise dikhega</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {whatsapp.trim() ? (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
              <MessageCircle className="w-5 h-5 text-green-400 shrink-0" />
              <div>
                <p className="text-xs text-green-400/80">WhatsApp</p>
                <p className="text-white font-medium text-sm">{whatsapp}</p>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-white/3 border border-white/5 text-white/30 text-sm">
              <MessageCircle className="w-4 h-4" /> WhatsApp set nahi hai
            </div>
          )}
          {email.trim() ? (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <Mail className="w-5 h-5 text-blue-400 shrink-0" />
              <div>
                <p className="text-xs text-blue-400/80">Email</p>
                <p className="text-white font-medium text-sm">{email}</p>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-white/3 border border-white/5 text-white/30 text-sm">
              <Mail className="w-4 h-4" /> Email set nahi hai
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
