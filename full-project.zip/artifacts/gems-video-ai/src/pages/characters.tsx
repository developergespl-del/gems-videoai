import { useState, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListCharacters,
  useCreateCharacter,
  useUpdateCharacter,
  useDeleteCharacter,
  useUploadCharacterFace,
  useUploadCharacterVoice,
  useDeleteCharacterFace,
  getListCharactersQueryKey,
  type Character,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  User,
  Plus,
  Trash2,
  Upload,
  Mic,
  CheckCircle2,
  Clock,
  AlertCircle,
  Camera,
  Volume2,
  Loader2,
  RotateCcw,
  X,
  Sparkles,
  ChevronRight,
} from "lucide-react";

const SLOT_LABELS: Record<string, { label: string; hint: string; icon: string; required?: boolean }> = {
  front: { label: "Front Face", hint: "Look straight at camera", icon: "👁️", required: true },
  left: { label: "Left Profile", hint: "Turn head left 45–90°", icon: "◀️" },
  right: { label: "Right Profile", hint: "Turn head right 45–90°", icon: "▶️" },
  back: { label: "Back / Top", hint: "Rear or top-down view", icon: "🔄" },
  extra1: { label: "Extra Photo 5", hint: "Any additional angle", icon: "📷" },
  extra2: { label: "Extra Photo 6", hint: "Any additional angle", icon: "📷" },
  extra3: { label: "Extra Photo 7", hint: "Any additional angle", icon: "📷" },
};

const ALL_SLOTS = ["front", "left", "right", "back", "extra1", "extra2", "extra3"] as const;
type FaceSlot = (typeof ALL_SLOTS)[number];

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1]!);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function StatusBadge({ status }: { status: string }) {
  if (status === "ready")
    return <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">Ready</Badge>;
  if (status === "processing")
    return <Badge className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">Processing</Badge>;
  return <Badge className="bg-zinc-500/10 text-zinc-400 border-zinc-500/20">Draft</Badge>;
}

function VoiceStatusBadge({ status }: { status: string }) {
  if (status === "ready")
    return (
      <span className="flex items-center gap-1 text-emerald-400 text-xs">
        <CheckCircle2 className="w-3 h-3" /> Voice Ready
      </span>
    );
  if (status === "processing")
    return (
      <span className="flex items-center gap-1 text-yellow-400 text-xs">
        <Loader2 className="w-3 h-3 animate-spin" /> Processing Voice
      </span>
    );
  if (status === "failed")
    return (
      <span className="flex items-center gap-1 text-red-400 text-xs">
        <AlertCircle className="w-3 h-3" /> Voice Failed
      </span>
    );
  return (
    <span className="flex items-center gap-1 text-zinc-500 text-xs">
      <Mic className="w-3 h-3" /> No Voice Sample
    </span>
  );
}

function FaceSlotCard({
  slot,
  url,
  onUpload,
  onRemove,
  uploading,
  totalFilled,
}: {
  slot: string;
  url: string | null;
  onUpload: (slot: string, file: File) => void;
  onRemove: (slot: string) => void;
  uploading: boolean;
  totalFilled: number;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const info = SLOT_LABELS[slot]!;
  const isExtraSlot = slot.startsWith("extra");
  const canAdd = !url && totalFilled < 7;

  return (
    <div className="flex flex-col gap-1.5">
      <div className="text-xs font-medium text-zinc-400 flex items-center gap-1">
        <span>{info.icon}</span>
        {info.label}
        {info.required && <span className="text-red-400">*</span>}
        {isExtraSlot && !url && <span className="text-zinc-600 text-[10px]">(optional)</span>}
      </div>
      <div
        className={`relative aspect-square rounded-lg border-2 border-dashed overflow-hidden transition-colors ${
          url
            ? "border-transparent cursor-default"
            : canAdd
              ? "border-white/10 hover:border-primary/50 cursor-pointer"
              : "border-white/5 opacity-40 cursor-not-allowed"
        }`}
        onClick={() => canAdd && fileRef.current?.click()}
      >
        {url ? (
          <>
            <img src={url} alt={info.label} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/0 hover:bg-black/50 transition-all flex items-center justify-center opacity-0 hover:opacity-100 gap-2">
              <button
                onClick={(e) => { e.stopPropagation(); fileRef.current?.click(); }}
                className="p-1.5 rounded-md bg-white/10 hover:bg-white/20 text-white"
                title="Replace"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onRemove(slot); }}
                className="p-1.5 rounded-md bg-red-500/20 hover:bg-red-500/40 text-red-400"
                title="Remove"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </>
        ) : uploading ? (
          <div className="w-full h-full flex items-center justify-center bg-zinc-900">
            <Loader2 className="w-6 h-6 text-primary animate-spin" />
          </div>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center gap-2 bg-zinc-900/50 text-zinc-500">
            <Camera className="w-5 h-5" />
            <span className="text-[9px] text-center px-2 leading-tight">{info.hint}</span>
          </div>
        )}
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onUpload(slot, file);
          e.target.value = "";
        }}
      />
    </div>
  );
}

function CharacterCard({
  character,
  onOpen,
  onDelete,
}: {
  character: Character;
  onOpen: (c: Character) => void;
  onDelete: (id: string) => void;
}) {
  const faceCount = (character.faceImages ?? []).length || [character.frontFaceUrl, character.leftFaceUrl, character.rightFaceUrl, character.backFaceUrl].filter(Boolean).length;
  return (
    <Card
      className="bg-zinc-900/60 border-white/5 hover:border-primary/30 transition-colors cursor-pointer group"
      onClick={() => onOpen(character)}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          {/* Avatar: front face or placeholder */}
          <div className="w-14 h-14 rounded-lg overflow-hidden bg-zinc-800 border border-white/5 flex-shrink-0">
            {character.frontFaceUrl ? (
              <img src={character.frontFaceUrl} alt={character.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-zinc-600">
                <User className="w-7 h-7" />
              </div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h3 className="font-semibold text-white truncate">{character.name}</h3>
                {character.description && (
                  <p className="text-xs text-zinc-400 mt-0.5 truncate">{character.description}</p>
                )}
              </div>
              <StatusBadge status={character.status} />
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
              <span className="text-[11px] text-zinc-500">
                <Camera className="w-3 h-3 inline mr-0.5" />
                {faceCount}/7 photos
              </span>
              <VoiceStatusBadge status={character.voiceModelStatus} />
              <span className="text-[11px] text-zinc-500 capitalize">{character.ageGroup} · {character.gender}</span>
            </div>
          </div>

          <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-primary transition-colors flex-shrink-0 mt-0.5" />
        </div>
      </CardContent>
    </Card>
  );
}

export function CharactersPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [createOpen, setCreateOpen] = useState(false);
  const [selectedChar, setSelectedChar] = useState<Character | null>(null);
  const [uploadingAngle, setUploadingAngle] = useState<string | null>(null);
  const [uploadingVoice, setUploadingVoice] = useState(false);
  const voiceFileRef = useRef<HTMLInputElement>(null);

  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newAge, setNewAge] = useState("adult");
  const [newGender, setNewGender] = useState("neutral");

  const { data, isLoading } = useListCharacters({
    query: { queryKey: getListCharactersQueryKey() },
  });

  const createMutation = useCreateCharacter({
    mutation: {
      onSuccess: (c) => {
        queryClient.invalidateQueries({ queryKey: getListCharactersQueryKey() });
        setCreateOpen(false);
        setSelectedChar(c);
        setNewName(""); setNewDesc(""); setNewAge("adult"); setNewGender("neutral");
        toast({ title: "Character created", description: "Now upload face images to bring them to life." });
      },
      onError: (e: any) => toast({ title: "Failed", description: e?.message, variant: "destructive" }),
    },
  });

  const deleteMutation = useDeleteCharacter({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCharactersQueryKey() });
        setSelectedChar(null);
        toast({ title: "Character deleted" });
      },
    },
  });

  const uploadFaceMutation = useUploadCharacterFace({
    mutation: {
      onSuccess: (updated) => {
        queryClient.invalidateQueries({ queryKey: getListCharactersQueryKey() });
        setSelectedChar(updated);
        setUploadingAngle(null);
        toast({ title: "Face uploaded successfully" });
      },
      onError: (e: any) => {
        setUploadingAngle(null);
        toast({ title: "Upload failed", description: e?.message, variant: "destructive" });
      },
    },
  });

  const uploadVoiceMutation = useUploadCharacterVoice({
    mutation: {
      onSuccess: (updated) => {
        queryClient.invalidateQueries({ queryKey: getListCharactersQueryKey() });
        setSelectedChar(updated);
        setUploadingVoice(false);
        toast({ title: "Voice sample uploaded", description: "Processing voice model… takes ~5 seconds." });
      },
      onError: (e: any) => {
        setUploadingVoice(false);
        toast({ title: "Upload failed", description: e?.message, variant: "destructive" });
      },
    },
  });

  const removeFaceMutation = useDeleteCharacterFace({
    mutation: {
      onSuccess: (updated) => {
        queryClient.invalidateQueries({ queryKey: getListCharactersQueryKey() });
        setSelectedChar(updated);
      },
    },
  });

  async function handleFaceUpload(slot: string, file: File) {
    if (!selectedChar) return;
    setUploadingAngle(slot);
    const data = await fileToBase64(file);
    uploadFaceMutation.mutate({
      id: selectedChar.id,
      data: { slot: slot as any, data, mimeType: file.type },
    });
  }

  async function handleVoiceUpload(file: File) {
    if (!selectedChar) return;
    setUploadingVoice(true);
    const data = await fileToBase64(file);
    uploadVoiceMutation.mutate({
      id: selectedChar.id,
      data: { data, mimeType: file.type },
    });
  }

  const characters = data?.characters ?? [];

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
            <User className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-display font-bold">Character Studio</h1>
            <p className="text-sm text-zinc-400 mt-0.5">
              Multi-angle face reconstruction + AI voice cloning for 100% realistic output
            </p>
          </div>
        </div>
        <Button
          className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2"
          onClick={() => setCreateOpen(true)}
        >
          <Plus className="w-4 h-4" />
          New Character
        </Button>
      </div>

      {/* Feature pills */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { icon: Camera, label: "Multi-Angle Face", desc: "1–7 photos for best 3D reconstruction" },
          { icon: Volume2, label: "Voice Cloning", desc: "A few words enough to clone the voice" },
          { icon: Sparkles, label: "Auto Lip Sync", desc: "Perfect mouth-word alignment every scene" },
          { icon: CheckCircle2, label: "AI Undetectable", desc: "Zero AI artifacts in final output" },
        ].map((f, i) => (
          <Card key={i} className="bg-zinc-900/40 border-white/5">
            <CardContent className="p-3 flex items-center gap-2">
              <f.icon className="w-4 h-4 text-primary flex-shrink-0" />
              <div>
                <div className="text-xs font-medium">{f.label}</div>
                <div className="text-[10px] text-zinc-500">{f.desc}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Character list */}
      {isLoading ? (
        <div className="grid gap-3">
          {[0, 1, 2].map((i) => (
            <Card key={i} className="bg-zinc-900/40 border-white/5 animate-pulse">
              <CardContent className="p-4 h-20" />
            </Card>
          ))}
        </div>
      ) : characters.length === 0 ? (
        <Card className="bg-zinc-900/40 border-white/5">
          <CardContent className="py-20 flex flex-col items-center gap-4 text-center">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <User className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-1">No characters yet</h3>
              <p className="text-sm text-zinc-400 max-w-xs">
                Create your first character — upload face photos from multiple angles and a short voice sample to achieve 100% real-life output.
              </p>
            </div>
            <Button onClick={() => setCreateOpen(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Create Character
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3">
          {characters.map((c) => (
            <CharacterCard
              key={c.id}
              character={c}
              onOpen={setSelectedChar}
              onDelete={(id) => deleteMutation.mutate({ id })}
            />
          ))}
        </div>
      )}

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-zinc-900 border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle>New Character</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-xs font-medium text-zinc-400 mb-1.5 block">Character Name *</label>
              <Input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Sarah, John, Detective Maya"
                className="bg-zinc-800 border-white/10"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-zinc-400 mb-1.5 block">Description</label>
              <Textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Brief description of this character..."
                className="bg-zinc-800 border-white/10 min-h-[70px]"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-zinc-400 mb-1.5 block">Age Group</label>
                <Select value={newAge} onValueChange={setNewAge}>
                  <SelectTrigger className="bg-zinc-800 border-white/10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-white/10">
                    {["child", "young", "adult", "elderly"].map((v) => (
                      <SelectItem key={v} value={v} className="capitalize">{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-medium text-zinc-400 mb-1.5 block">Gender</label>
                <Select value={newGender} onValueChange={setNewGender}>
                  <SelectTrigger className="bg-zinc-800 border-white/10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-white/10">
                    {["male", "female", "neutral"].map((v) => (
                      <SelectItem key={v} value={v} className="capitalize">{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button
              onClick={() =>
                createMutation.mutate({ data: { name: newName, description: newDesc, ageGroup: newAge as any, gender: newGender as any } })
              }
              disabled={!newName.trim() || createMutation.isPending}
              className="bg-primary text-primary-foreground"
            >
              {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Character detail dialog */}
      {selectedChar && (
        <Dialog open={!!selectedChar} onOpenChange={(open) => !open && setSelectedChar(null)}>
          <DialogContent className="bg-zinc-900 border-white/10 max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <div className="flex items-center justify-between">
                <DialogTitle className="flex items-center gap-2">
                  {selectedChar.name}
                  <StatusBadge status={selectedChar.status} />
                </DialogTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-red-400 hover:text-red-300 hover:bg-red-500/10 -mr-2"
                  onClick={() => {
                    if (confirm(`Delete "${selectedChar.name}"?`))
                      deleteMutation.mutate({ id: selectedChar.id });
                  }}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              {selectedChar.description && (
                <CardDescription>{selectedChar.description}</CardDescription>
              )}
            </DialogHeader>

            {/* Face grid — up to 7 photos */}
            <div>
              <div className="text-sm font-semibold mb-1 flex items-center gap-2">
                <Camera className="w-4 h-4 text-primary" />
                Face Images
                <span className="text-xs text-zinc-500 font-normal">
                  — min 1 required, max 7 · more angles = better 3D reconstruction
                </span>
                <span className="ml-auto text-xs text-primary font-mono">
                  {(selectedChar.faceImages ?? [selectedChar.frontFaceUrl, selectedChar.leftFaceUrl, selectedChar.rightFaceUrl, selectedChar.backFaceUrl].filter(Boolean)).length}/7
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2.5 mb-1">
                {ALL_SLOTS.map((slot) => {
                  const slotToKey: Record<string, keyof Character> = {
                    front: "frontFaceUrl", left: "leftFaceUrl",
                    right: "rightFaceUrl", back: "backFaceUrl",
                    extra1: "extraFace1Url", extra2: "extraFace2Url", extra3: "extraFace3Url",
                  };
                  const urlKey = slotToKey[slot]!;
                  const totalFilled = (selectedChar.faceImages ?? [selectedChar.frontFaceUrl, selectedChar.leftFaceUrl, selectedChar.rightFaceUrl, selectedChar.backFaceUrl].filter(Boolean)).length;
                  return (
                    <FaceSlotCard
                      key={slot}
                      slot={slot}
                      url={(selectedChar[urlKey] as string | null) ?? null}
                      onUpload={handleFaceUpload}
                      onRemove={(s) => removeFaceMutation.mutate({ id: selectedChar.id, slot: s as any })}
                      uploading={uploadingAngle === slot}
                      totalFilled={totalFilled}
                    />
                  );
                })}
              </div>
              {!selectedChar.frontFaceUrl && (
                <p className="mt-1 text-xs text-yellow-400 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Upload at least the front-face photo to activate this character.
                </p>
              )}
            </div>

            {/* Voice section */}
            <div>
              <div className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Mic className="w-4 h-4 text-primary" />
                Voice Sample
                <VoiceStatusBadge status={selectedChar.voiceModelStatus} />
              </div>

              {selectedChar.voiceSampleUrl ? (
                <div className="bg-zinc-800/60 border border-white/5 rounded-lg p-3 space-y-2">
                  <audio
                    controls
                    src={selectedChar.voiceSampleUrl}
                    className="w-full h-8"
                  />
                  <div className="flex items-center gap-2 text-xs text-zinc-400">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Voice sample uploaded
                    {selectedChar.voiceModelStatus === "ready" && " — model ready"}
                    {selectedChar.voiceModelStatus === "processing" && " — building model..."}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-auto text-xs h-6 px-2 text-zinc-400"
                      onClick={() => voiceFileRef.current?.click()}
                      disabled={uploadingVoice}
                    >
                      Replace
                    </Button>
                  </div>
                </div>
              ) : (
                <div
                  className="border-2 border-dashed border-white/10 hover:border-primary/40 rounded-lg p-6 text-center cursor-pointer transition-colors"
                  onClick={() => voiceFileRef.current?.click()}
                >
                  {uploadingVoice ? (
                    <Loader2 className="w-8 h-8 mx-auto mb-2 text-primary animate-spin" />
                  ) : (
                    <Mic className="w-8 h-8 mx-auto mb-2 text-zinc-600" />
                  )}
                  <p className="text-sm font-medium text-zinc-300">Upload a voice sample</p>
                  <p className="text-xs text-zinc-500 mt-1">
                    MP3, WAV, or WebM · Even a few seconds is enough · We'll clone the tone, pitch, and accent
                  </p>
                  <Button size="sm" variant="outline" className="mt-3 border-white/10 gap-2">
                    <Upload className="w-3.5 h-3.5" />
                    Choose Audio File
                  </Button>
                </div>
              )}

              <input
                ref={voiceFileRef}
                type="file"
                accept="audio/mp3,audio/mpeg,audio/wav,audio/webm,audio/ogg"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleVoiceUpload(file);
                  e.target.value = "";
                }}
              />
            </div>

            {/* AI capabilities info */}
            <Card className="bg-primary/5 border-primary/15">
              <CardContent className="p-4">
                <div className="text-xs font-semibold text-primary mb-2 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> AI Realism Engine
                </div>
                <ul className="text-xs text-zinc-400 space-y-1">
                  <li>• Face identity preserved across all scenes — no mismatch, no morphing</li>
                  <li>• Realistic head movement with natural physics (no distortion)</li>
                  <li>• Voice tone, pitch, accent, and breathing patterns cloned precisely</li>
                  <li>• Lip sync matched word-by-word to dialogue</li>
                  <li>• Emotion &amp; age adaptation applied automatically per scene context</li>
                  <li>• Output is indistinguishable from real camera footage</li>
                </ul>
              </CardContent>
            </Card>

            <DialogFooter>
              <Button variant="ghost" onClick={() => setSelectedChar(null)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
