import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import {
  useUpdateUser,
  useListVideos,
  getGetMeQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  User,
  Film,
  Crown,
  Download,
  Share2,
  Copy,
  Check,
  Save,
  Loader2,
  ExternalLink,
  Zap,
  Shield,
  Clock,
  CheckCircle2,
  XCircle,
  Mail,
  Calendar,
  HardDrive,
  Video,
  Play,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const PLAN_INFO = {
  user: {
    label: "Free",
    color: "bg-zinc-700 text-zinc-100",
    icon: <User className="w-4 h-4" />,
    description: "Perfect for exploration and learning",
    priority: "Standard CPU",
    sceneCount: 3,
    renderTime: "~40s",
    queuePriority: "Low",
    upgradeCTA: "Upgrade to Paid",
    features: {
      "Video generation": true,
      "Hindi language": true,
      "3 scenes per video": true,
      "CPU rendering": true,
      "5 languages": false,
      "GPU acceleration": false,
      "Priority queue": false,
      "Enterprise support": false,
    },
  },
  admin: {
    label: "Paid",
    color: "bg-purple-700 text-white",
    icon: <Zap className="w-4 h-4" />,
    description: "Professional studio features",
    priority: "GPU-A100",
    sceneCount: 5,
    renderTime: "~15s",
    queuePriority: "Medium",
    upgradeCTA: "Upgrade to Enterprise",
    features: {
      "Video generation": true,
      "Hindi language": true,
      "3 scenes per video": true,
      "CPU rendering": true,
      "5 languages": true,
      "GPU acceleration": true,
      "Priority queue": true,
      "Enterprise support": false,
    },
  },
  super_admin: {
    label: "Enterprise",
    color: "bg-amber-600 text-white",
    icon: <Crown className="w-4 h-4" />,
    description: "Maximum performance — H100 GPU cluster",
    priority: "GPU-H100",
    sceneCount: 8,
    renderTime: "~8s",
    queuePriority: "Highest",
    upgradeCTA: null,
    features: {
      "Video generation": true,
      "Hindi language": true,
      "3 scenes per video": true,
      "CPU rendering": true,
      "5 languages": true,
      "GPU acceleration": true,
      "Priority queue": true,
      "Enterprise support": true,
    },
  },
};

function formatDuration(seconds?: number) {
  if (!seconds) return "0s";
  if (seconds < 60) return `${Math.round(seconds)}s`;
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  if (m < 60) return s > 0 ? `${m}m ${s}s` : `${m}m`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm > 0 ? `${h}h ${rm}m` : `${h}h`;
}

export default function ProfilePage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const updateUser = useUpdateUser();

  const [name, setName] = useState(user?.name ?? "");
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl ?? "");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleDownload = async (videoId: string, fallbackUrl: string) => {
    try {
      const token = localStorage.getItem("gems_token");
      const resp = await fetch(`/api/videos/${videoId}/download`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!resp.ok) throw new Error("Failed");
      const { url } = await resp.json() as { url: string };
      window.open(url, "_blank");
    } catch {
      window.open(fallbackUrl, "_blank");
    }
  };

  const { data: videosData, isLoading: videosLoading } = useListVideos({
    limit: 100,
    page: 1,
  });

  const plan = PLAN_INFO[(user?.role as keyof typeof PLAN_INFO) ?? "user"] ?? PLAN_INFO.user;
  const videos = videosData?.videos ?? [];
  const completedVideos = videos.filter((v) => v.status === "completed");

  const handleSaveProfile = async () => {
    if (!user) return;
    try {
      await updateUser.mutateAsync({ id: user.id, data: { name, avatarUrl } });
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      toast({ title: "Profile updated", description: "Your changes have been saved." });
    } catch {
      toast({ title: "Failed to save", variant: "destructive" });
    }
  };

  const handleCopyLink = (videoId: string) => {
    const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
    const link = `${window.location.origin}${base}/videos/${videoId}`;
    navigator.clipboard.writeText(link);
    setCopiedId(videoId);
    setTimeout(() => setCopiedId(null), 2000);
    toast({ title: "Link copied!", description: "Share link copied to clipboard." });
  };

  if (!user) return null;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center overflow-hidden border-2 border-white/10 flex-shrink-0">
          {user.avatarUrl ? (
            <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" />
          ) : (
            <span className="text-2xl font-bold text-white">{user.name?.[0]?.toUpperCase()}</span>
          )}
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">{user.name}</h1>
          <p className="text-sm text-white/50 flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5" /> {user.email}
          </p>
          <Badge className={`mt-1 text-xs ${plan.color}`}>
            {plan.icon}
            <span className="ml-1">{plan.label}</span>
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid grid-cols-3 max-w-md bg-white/5 border border-white/10">
          <TabsTrigger value="profile" className="flex items-center gap-1.5">
            <User className="w-3.5 h-3.5" /> Profile
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-1.5">
            <Film className="w-3.5 h-3.5" /> Videos
          </TabsTrigger>
          <TabsTrigger value="subscription" className="flex items-center gap-1.5">
            <Crown className="w-3.5 h-3.5" /> Plan
          </TabsTrigger>
        </TabsList>

        {/* PROFILE TAB */}
        <TabsContent value="profile" className="mt-6">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-4">
              <Card className="bg-white/5 border-white/10">
                <CardHeader>
                  <CardTitle className="text-white">Edit Profile</CardTitle>
                  <CardDescription>Update your display name and avatar.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-20 h-20 rounded-full overflow-hidden bg-white/10 flex items-center justify-center border border-white/10 flex-shrink-0">
                      {avatarUrl ? (
                        <img src={avatarUrl} alt="avatar" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
                      ) : (
                        <span className="text-3xl font-bold text-white">{user.name?.[0]?.toUpperCase()}</span>
                      )}
                    </div>
                    <div className="flex-1">
                      <label className="text-xs text-white/50 mb-1 block">Avatar URL</label>
                      <Input
                        value={avatarUrl}
                        onChange={(e) => setAvatarUrl(e.target.value)}
                        placeholder="https://example.com/photo.jpg"
                        className="bg-white/5 border-white/10 text-white text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Full Name</label>
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Your name"
                      className="bg-white/5 border-white/10 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Email</label>
                    <Input
                      value={user.email}
                      disabled
                      className="bg-white/5 border-white/10 text-white/40 cursor-not-allowed"
                    />
                    <p className="text-xs text-white/30 mt-1">Email cannot be changed.</p>
                  </div>
                  <Button
                    onClick={handleSaveProfile}
                    disabled={updateUser.isPending}
                    className="bg-purple-600 hover:bg-purple-500 text-white"
                  >
                    {updateUser.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4 mr-2" />
                    )}
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Card className="bg-white/5 border-white/10">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-white">Account Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-white/50 flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> Joined</span>
                    <span className="text-white font-medium">{new Date(user.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/50 flex items-center gap-1.5"><Video className="w-3.5 h-3.5" /> Videos</span>
                    <span className="text-white font-medium">{user.videoCount ?? 0}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/50 flex items-center gap-1.5"><HardDrive className="w-3.5 h-3.5" /> Storage</span>
                    <span className="text-white font-medium">{((user.storageUsedMb ?? 0)).toFixed(1)} MB</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/50 flex items-center gap-1.5"><Shield className="w-3.5 h-3.5" /> Role</span>
                    <span className="text-white font-medium capitalize">{user.role.replace("_", " ")}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* VIDEO HISTORY TAB */}
        <TabsContent value="history" className="mt-6">
          <Card className="bg-white/5 border-white/10">
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <div>
                <CardTitle className="text-white">Video History</CardTitle>
                <CardDescription>{videos.length} videos total</CardDescription>
              </div>
              <Link href="/videos/new">
                <Button size="sm" className="bg-purple-600 hover:bg-purple-500 text-white">
                  <Play className="w-3.5 h-3.5 mr-1.5" /> New Video
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {videosLoading ? (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-16 bg-white/5" />
                  ))}
                </div>
              ) : videos.length === 0 ? (
                <div className="text-center py-12 text-white/40">
                  <Film className="w-10 h-10 mx-auto mb-3 opacity-30" />
                  <p>No videos yet. Create your first cinematic production.</p>
                  <Link href="/videos/new">
                    <Button className="mt-4 bg-purple-600 hover:bg-purple-500 text-white" size="sm">Create Video</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-2">
                  {videos.map((video) => (
                    <div key={video.id} className="flex items-center gap-4 p-3 rounded-lg bg-white/5 hover:bg-white/8 transition-colors group">
                      <div className="w-12 h-8 rounded bg-white/10 flex items-center justify-center flex-shrink-0">
                        <Film className="w-4 h-4 text-white/40" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <Link href={`/videos/${video.id}`}>
                          <p className="text-sm font-medium text-white truncate hover:text-purple-300 transition-colors">{video.title}</p>
                        </Link>
                        <div className="flex items-center gap-2 mt-0.5">
                          <Badge
                            variant="outline"
                            className={`text-[10px] px-1.5 py-0 border-0 ${
                              video.status === "completed"
                                ? "bg-green-500/20 text-green-400"
                                : video.status === "processing"
                                ? "bg-yellow-500/20 text-yellow-400"
                                : video.status === "failed"
                                ? "bg-red-500/20 text-red-400"
                                : "bg-white/10 text-white/50"
                            }`}
                          >
                            {video.status}
                          </Badge>
                          {video.durationSeconds && (
                            <span className="text-[10px] text-white/40 flex items-center gap-0.5">
                              <Clock className="w-3 h-3" />
                              {formatDuration(video.durationSeconds)}
                            </span>
                          )}
                          <span className="text-[10px] text-white/30">
                            {new Date(video.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {video.status === "completed" && video.outputUrl && (
                          <button
                            onClick={(e) => { e.stopPropagation(); handleDownload(video.id, video.outputUrl!); }}
                            className="p-1.5 rounded-md hover:bg-white/10 text-white/60 hover:text-white transition-colors"
                            title="Download"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleCopyLink(video.id)}
                          className="p-1.5 rounded-md hover:bg-white/10 text-white/60 hover:text-white transition-colors"
                          title="Copy share link"
                        >
                          {copiedId === video.id ? (
                            <Check className="w-3.5 h-3.5 text-green-400" />
                          ) : (
                            <Share2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <Link href={`/videos/${video.id}`}>
                          <button className="p-1.5 rounded-md hover:bg-white/10 text-white/60 hover:text-white transition-colors" title="View">
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* SUBSCRIPTION TAB */}
        <TabsContent value="subscription" className="mt-6">
          <div className="space-y-6">
            {/* Current Plan */}
            <Card className="bg-gradient-to-br from-white/8 to-white/4 border-white/10">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Badge className={`${plan.color} text-sm px-3 py-1`}>
                        {plan.icon}
                        <span className="ml-1.5">{plan.label} Plan</span>
                      </Badge>
                    </div>
                    <p className="text-white/60 text-sm mt-2">{plan.description}</p>
                    <div className="grid grid-cols-3 gap-4 mt-4">
                      <div className="text-center p-3 rounded-lg bg-white/5">
                        <p className="text-lg font-bold text-white">{plan.sceneCount}</p>
                        <p className="text-xs text-white/40">Scenes / video</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-white/5">
                        <p className="text-lg font-bold text-white">{plan.renderTime}</p>
                        <p className="text-xs text-white/40">Render time</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-white/5">
                        <p className="text-sm font-bold text-white">{plan.priority}</p>
                        <p className="text-xs text-white/40">GPU tier</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Feature Comparison */}
            <Card className="bg-white/5 border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-white text-base">Feature Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-2 text-xs font-medium text-white/40 mb-3 px-2">
                  <span>Feature</span>
                  <span className="text-center">Free</span>
                  <span className="text-center">Paid</span>
                  <span className="text-center">Enterprise</span>
                </div>
                {Object.entries(PLAN_INFO.super_admin.features).map(([feature]) => (
                  <div key={feature} className="grid grid-cols-4 gap-2 py-2.5 border-t border-white/5 items-center px-2">
                    <span className="text-sm text-white/70">{feature}</span>
                    {(["user", "admin", "super_admin"] as const).map((role) => {
                      const has = PLAN_INFO[role].features[feature as keyof typeof PLAN_INFO.user.features];
                      const isCurrent = user.role === role;
                      return (
                        <div key={role} className={`flex justify-center ${isCurrent ? "scale-110" : ""}`}>
                          {has ? (
                            <CheckCircle2 className={`w-4 h-4 ${isCurrent ? "text-green-400" : "text-green-600/50"}`} />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-900/50" />
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Upgrade CTA */}
            {plan.upgradeCTA && (
              <Card className="bg-gradient-to-r from-purple-900/40 to-indigo-900/40 border-purple-500/30">
                <CardContent className="pt-6 flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold">{plan.upgradeCTA}</h3>
                    <p className="text-white/50 text-sm mt-1">
                      {user.role === "user"
                        ? "Get GPU acceleration, 5 scenes per video, and priority rendering."
                        : "Unlock H100 GPU cluster, 8 scenes per video, and enterprise support."}
                    </p>
                  </div>
                  <Button className="bg-purple-600 hover:bg-purple-500 text-white ml-6 flex-shrink-0">
                    <Crown className="w-4 h-4 mr-1.5" />
                    {plan.upgradeCTA}
                  </Button>
                </CardContent>
              </Card>
            )}

            {user.role === "super_admin" && (
              <Card className="bg-gradient-to-r from-amber-900/30 to-yellow-900/20 border-amber-500/30">
                <CardContent className="pt-6 flex items-center gap-4">
                  <Crown className="w-8 h-8 text-amber-400 flex-shrink-0" />
                  <div>
                    <h3 className="text-white font-semibold">You're on the Enterprise plan</h3>
                    <p className="text-white/50 text-sm mt-1">Maximum performance. GPU-H100 cluster. 8 scenes per video. Priority queue.</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
